<?php
   $DBase_INI = "host=127.0.0.1 port=5432 dbname=svm user=accordance password=1qaz2wsx" ;
   $img_reflash=1000 ;
   $img_con=3 ;
?>