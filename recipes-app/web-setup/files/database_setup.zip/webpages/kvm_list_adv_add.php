<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$delid = $_GET['delid'];
$delide = $_GET['delide'];
		$kvm_ip = "";
		$kvm_connect  = "";
		$kvm_scaling  = "";
		$kvm_cursor  = "";
		$kvm_format  = "";
		$kvm_quality  = "";
		$kvm_snaphot  = "";
		$kvm_timeout  = "";
		$kvm_restart  = "";
		$kvm_ocr_enable  = "";
		$kvm_ocr_file  = "";
		$kvm_ocr_interval  = "";
		$kvm_ocr_times  = "";
		$kvm_ocr_x = "";
		$kvm_ocr_y = "";
		$kvm_ocr_w = "";
		$kvm_ocr_h = "";
		$kvm_ocr_word = "";
		$kvm_ocr_color = "";
		$kvm_conn_retry = "";
		$kvm_ocrs_enable = "";
		$kvm_ocrs_key = "";
		$kvm_io_port = "";

$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	//$sql = "select * from kvm_svm_table where kvm_ip='".$delid."' and kvm_port=' ".$delide."' ";
	$sql = "select * from kvm_svm_table where kvm_ip='".$delid."' ";
	//echo $sql;
	$result = pg_exec($testDb,$sql );
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		
		$kvm_ip = trim($info[0]);
		$kvm_connect  = trim($info[1]);
		$kvm_scaling  = trim($info[2]);
		$kvm_cursor  = trim($info[3]);
		$kvm_format  = trim($info[4]);
		$kvm_quality  = trim($info[5]);
		$kvm_snaphot  = trim($info[6]);
		$kvm_timeout  = trim($info[7]);
		$kvm_restart  = trim($info[8]);
		$kvm_ocr_enable  = trim($info[9]);
		$kvm_ocr_file  = trim($info[10]);
		$kvm_ocr_interval  = trim($info[11]);
		$kvm_ocr_times  = trim($info[12]);
		$kvm_ocr_x = trim($info[13]);
		$kvm_ocr_y = trim($info[14]);
		$kvm_ocr_w = trim($info[15]);
		$kvm_ocr_h = trim($info[16]);
		$kvm_ocr_word = trim($info[17]);
		$kvm_ocr_color = trim($info[18]);
		$kvm_conn_retry = trim($info[19]);
		$kvm_ocrs_enable = trim($info[20]);
		$kvm_ocrs_key = trim($info[21]);
		$kvm_io_port = trim($info[22]);
	}
	pg_close($testDb); 
}
?>
<html>
<head>
<meta charset="utf-8">
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
  <form action="kvm_adv_new.php" method="post">
      <table >
      	<tr>
      		<td> <?php echo _('kvm_ip');?> </td>
      		<td> <input type="text" name=kvm_ip value="<?php echo $kvm_ip ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_connect');?> </td>
      		<td> <input type="text" name=kvm_connect value="<?php echo $kvm_connect ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_scaling');?> </td>
      		<td> <input type="text" name=kvm_scaling value="<?php echo $kvm_scaling ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_cursor');?> </td>
      		<td> <input type="text" name=kvm_cursor value="<?php echo $kvm_cursor ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_format');?> </td>
      		<td> <input type="text" name=kvm_format value="<?php echo $kvm_format ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_quality');?> </td>
      		<td> <input type="text" name=kvm_quality value="<?php echo $kvm_quality ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_snaphot');?> </td>
      		<td> <input type="text" name=kvm_snaphot value="<?php echo $kvm_snaphot ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_timeout');?> </td>
      		<td> <input type="text" name=kvm_timeout value="<?php echo $kvm_timeout ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_restart');?> </td>
      		<td> <input type="text" name=kvm_restart value="<?php echo $kvm_restart ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocr_enable');?> </td>
      		<td> <input type="text" name=kvm_ocr_enable value="<?php echo $kvm_ocr_enable ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocr_file');?> </td>
      		<td> <input type="text" name=kvm_ocr_file value="<?php echo $kvm_ocr_file ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocr_interval');?> </td>
      		<td> <input type="text" name=kvm_ocr_interval value="<?php echo $kvm_ocr_interval ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocr_times');?> </td>
      		<td> <input type="text" name=kvm_ocr_times value="<?php echo $kvm_ocr_times ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocr_x');?> </td>
      		<td> <input type="text" name=kvm_ocr_x value="<?php echo $kvm_ocr_x ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocr_y');?> </td>
      		<td> <input type="text" name=kvm_ocr_y value="<?php echo $kvm_ocr_y ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocr_w');?> </td>
      		<td> <input type="text" name=kvm_ocr_w value="<?php echo $kvm_ocr_w ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocr_h');?> </td>
      		<td> <input type="text" name=kvm_ocr_h value="<?php echo $kvm_ocr_h ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocr_word');?> </td>
      		<td> <input type="text" name=kvm_ocr_word value="<?php echo $kvm_ocr_word ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocr_color');?> </td>
      		<td> <input type="text" name=kvm_ocr_color value="<?php echo $kvm_ocr_color ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_conn_retry');?> </td>
      		<td> <input type="text" name=kvm_conn_retry value="<?php echo $kvm_conn_retry ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocrs_enable');?> </td>
      		<td> <input type="text" name=kvm_ocrs_enable value="<?php echo $kvm_ocrs_enable ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_ocrs_key');?> </td>
      		<td> <input type="text" name=kvm_ocrs_key value="<?php echo $kvm_ocrs_key ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_io_port');?> </td>
      		<td> <input type="text" name=kvm_io_port value="<?php echo $kvm_io_port ?>"> </td>
      	</tr>
       <tr>
      		<td> <input type="submit" value="<?php echo _('Submit');?>" > </td>
      	</tr> 	
      </table>
  </form>
  </body>
</html>