<?php
include_once("web_conf.php");
//require_once('syslog.php');
		$mc_vender = $_POST['mc_vender'];
		$mc_model = $_POST['mc_model'];
		$mc_ver = $_POST['mc_ver'];
		$alarm_id = $_POST['alarm_id'];
		$alarm_name = $_POST['alarm_name'];
		$spt_file = $_POST['spt_file'];
		$spt_sece_ini  = $_POST['spt_sece_ini'];
		$temp_file = $_POST['temp_file'];

$testDb=pg_connect($DBase_INI); 

if($testDb == FALSE)
{
	echo "connect error";
}
else
{
    $sql = "select * from alarm_spt_m where  mc_vender='$mc_vender' and mc_model='$mc_model' and mc_ver='$mc_ver' and alarm_id='$alarm_id'";
 		//echo $sql;
 		
		$result1 = pg_exec($testDb, $sql);
    $numrows1 = pg_num_rows($result1);
    
		if( $numrows1 > 0)
		{
			$sql = "update alarm_spt_m set  alarm_name='$alarm_name' , spt_file='$spt_file' , spt_sece_ini='$spt_sece_ini' , temp_file='$temp_file' where mc_vender='$mc_vender' and mc_model='$mc_model' and mc_ver='$mc_ver' and alarm_id='$alarm_id' ";
			//echo $sql;
			echo "update";
		}
		else
		{
			$sql = "insert into alarm_spt_m (mc_vender, mc_model, mc_ver, alarm_id, alarm_name, spt_file, spt_sece_ini, temp_file) values ('$mc_vender', '$mc_model', '$mc_ver', '$alarm_id', '$alarm_name', '$spt_file', '$spt_sece_ini', '$temp_file')";
				echo "insert";
	}
	//echo $sql;
	$result = pg_exec($testDb, $sql);
	echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	pg_close($testDb); 
}

?>