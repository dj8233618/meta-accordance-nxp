<html>
<head>
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<frameset framespacing="0" border="0" rows="*" frameborder="0">
  <frameset cols="150,*">
	<frame name="contents" target="main" src="left2.php" scrolling="no" noresize>
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user_id = $_GET['user_id'];
//  echo "  <frame name=\"contents\" target=\"main\" src=\"left2.php?&user_id=$user_id\" scrolling=\"no\" noresize>";
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from web_set");
	$numrows = pg_num_rows($result);
	if( $numrows )
	{
		echo "SUCCESS!!";
		$info=pg_fetch_array($result);
		$web_ip = trim($info[1]);
		$web_port = trim($info[2]);
		$web_path = trim($info[3]);
		$web_w = trim($info[4]);
		$web_h = trim($info[5]);
	}
	pg_close($testDb); 
	echo "<frame name=\"main\" src=\"page16_a.php?web_ip=$web_ip&web_port=$web_port&web_path=$web_path&page_w=$web_w&page_h=$web_h\" scrolling=\"auto\" target=\"_self\">"; 
}
?>    
  </frameset>
  <noframes>
  <body>
  <p>This webpage uses the frame , but your browser does not support . </p>
  </body>
  </noframes>
</frameset>
</html>
