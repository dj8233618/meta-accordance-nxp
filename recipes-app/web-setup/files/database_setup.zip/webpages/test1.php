<?php 
	phpInfo(); 
?>