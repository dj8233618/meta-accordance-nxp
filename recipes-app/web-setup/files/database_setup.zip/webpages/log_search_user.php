<?php 
include_once("languages/languages.php"); //�ޤJ�y���]�w���
session_start();
$FacList = $_SESSION['FacList'];
$ConList = $_SESSION['ConList'];
$FacChoose = $_SESSION['FacChoose'];

$factory = $_POST['factory'];
?>
<html>
<head>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">

<?php 
for($i=0; $i < count($FacList); $i++)
{
    if($factory == $FacList[$i])    // �P�_��F�ĴX�� factory, All=0
        $FacChoose[0] = $i+1; 
}
if($factory =="All")
    $FacChoose[0] = 0; 
?>
</head>
  <body>
  <?php 
  //var_dump($FacList);
  //var_dump($ConList);
  //var_dump($FacChoose);
  ?>
	<form name="input" action="log_search_userIP.php" method="post">  
		<select id="factory" name="factory" onchange="">
            <option value ='<?=$factory?>'><?=$factory?> </option>
        </select>
        <br>
        <br>
        <?php echo _('Please choose user and setting time');?>
        <br>
        <select id="user" name="user" onchange="">
        <option value ="All"> All </option>
            <?php 
                $count = 0;
                $record = array();
                while($count<count($ConList))
                {
                    $count++;
                    if ($count!= $FacChoose[0] && $FacChoose[0] > 0)
                        continue;
                    $j = $count-1;
                    $DBase_INI = "host= $ConList[$j] port=5432 dbname=svm user=accordance password=1qaz2wsx";
                    $sql = "select user_id from rx_u_log";
                    $testDb=pg_connect($DBase_INI);
                    if($testDb==false)
                    {
                        echo "<script>alert('$ConList[$j] �s�u����')</script>";
                        echo ("<script>document.location.href=\"log_search_factory.php\";</script>");
                        break;
                        //�T�O���w�V��A����N�X���|�Q����
                        exit;
                    }
                    $resultCustomized=pg_exec($testDb,$sql);
                    $arrCustomized = pg_fetch_all($resultCustomized);
                    $length= sizeof($arrCustomized);
                    
                    $user = array();
                    for($i=0 ; $i<$length ; $i++)
                    {
                        $user[$arrCustomized[$i]["user_id"]]= $arrCustomized[$i]["user_id"];
                    }
                    
                    $userKey = array_keys($user);  
                    sort($user);
                    $userSize = sizeof($userKey);
                    for($j=0 ; $j<$userSize ; $j++)
                    {
                        if(!in_array($userKey[$j], $record))
                        {
                           array_push($record,$userKey[$j]);
                	       echo "<option value ='$userKey[$j]'>$userKey[$j]</option>";
                        }
                    }
                }
            ?>
        </select>
        <br>
        <?php 
            session_start();
            $_SESSION['FacChoose'] = $FacChoose;
            
            $date1 = date("Y-m-d");
        ?>
        <label for="start"><?php echo _('Start:');?></label>
		<input type="date" id="start_date" name="start_date" value = <?=$date1?>>
		<label for="end"><?php echo _('End:');?></label>
		<input type="date" id="end_date" name="end_date" value = <?=$date1?>>
		<br>
		<br>
        <input type="submit" value="<?php echo _('OK');?>">
	</form>
  </body>
</html>
