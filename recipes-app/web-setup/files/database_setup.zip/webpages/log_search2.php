<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
session_start();
$FacList = $_SESSION['FacList'];
$ConList = $_SESSION['ConList'];
$FacChoose = $_SESSION['FacChoose'];
$factory = $_SESSION['factory'];
$user = $_SESSION['user'];
$start_date = $_SESSION['start_date'];
$end_date = $_SESSION['end_date'];
$userIP = $_SESSION['userIP'];

$ControlIP = $_POST['ControlIP'];
?>
<html>
<head>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">

<?php 
include_once("web_conf.php");

echo (_('Factory:').$factory);
echo ("<br>");
echo (_('User').$user);
echo ("<br>");
echo (_('Start:').$start_date);
echo ("<br>");
echo (_('End:').$end_date);
echo ("<br>");
echo (_('UserPC:').$userIP);
echo ("<br>");
echo (_('Connected IP:').$ControlIP);
echo ("<br>");
echo ("<br>");
?>
</head>
<body> 
<?php echo _('Please choose Connected IP');?>
<form name="input" action="log_search2.php" method="post">
		<select id="ControlIP" name="ControlIP" onchange="">
			<option value ="All"> All </option>
            <?php 
                $count = 0;
                $record = array();
                while($count<count($ConList))
                {
                    $count++;
                    if ($count!= $FacChoose[0] && $FacChoose[0] > 0)
                        continue;
                    $j = $count-1;
                    $DBase_INI = "host= $ConList[$j] port=5432 dbname=svm user=accordance password=1qaz2wsx";
                    $sql = "select view_ip from rx_u_log";
                    if($user != "All" && $userIP =="All")
                        $sql = "select view_ip from rx_u_log where user_id = '$user'";
                    if($user == "All" && $userIP !="All")
                        $sql = "select view_ip from rx_u_log where rx_ip = '$userIP'";
                    if($user != "All" && $userIP != "All")
                        $sql = "select view_ip from rx_u_log where user_id = '$user' and rx_ip = '$userIP'";
                    $testDb=pg_connect($DBase_INI);
                    $resultCustomized=pg_exec($testDb,$sql);
                    $arrCustomized = pg_fetch_all($resultCustomized);
                    $length= sizeof($arrCustomized);
                
                    $view_ip = array();
                    for($i=0 ; $i<$length ; $i++)
                    {
                        $view_ip[$arrCustomized[$i]["view_ip"]]= $arrCustomized[$i]["view_ip"];
                    }
                
                    $view_ipKey = array_keys($view_ip);
                    sort($view_ip);
                    $view_ipSize = sizeof($view_ipKey);
                    for($j=0 ; $j<$view_ipSize ; $j++)
                    {              
                        if(trim($view_ipKey[$j])=="login")
                            $view_ipKey[$j] = $userIP;
                        if(trim($view_ipKey[$j])=="logout")
                            $view_ipKey[$j] = $userIP;
                        if(strpos($view_ipKey[$j],"p")!=false)
                            $view_ipKey[$j] = substr($view_ipKey[$j], 0 ,stripos($view_ipKey[$j],"p"));
                        if(strpos($view_ipKey[$j],"-")!=false)
                            $view_ipKey[$j] = substr($view_ipKey[$j], 0 ,stripos($view_ipKey[$j],"-"));
                                        
                                        
                        if(!in_array(trim($view_ipKey[$j]), $record) && trim($view_ipKey[$j]) !="")
                        {
                            if($view_ipKey[$j]=="All")
                                continue;
                                array_push($record,trim($view_ipKey[$j]));
                            echo "<option value ='$view_ipKey[$j]'>$view_ipKey[$j]</option>";
                        }
                    }
                }
            ?>
		</select>
<input type="submit" value="<?php echo _('OK');?>">
</form>
        <?php 
        echo ("<a href=\"log_search_factory.php\">")?> <?php echo _('Reset');?> <?php echo "</a>";?>
        <table border=1 cellpadding=4>
        <tr><td><?php echo _('User');?></td><td><?php echo _('UserPC');?></td><td><?php echo _('Time');?></td><td><?php echo _('Connected IP');?></td><td><?php echo _('Action');?></td><td><?php echo _('IP verify');?></td><td><?php echo _('Connected Name');?></td><td><?php echo _('Factory');?></td></tr>
        <?php 
        $count = 0;
        while($count<count($ConList))
            {
                $count++;
                if ($count!= $FacChoose[0] && $FacChoose[0] > 0)
                    continue;
                
                $j = $count-1;
                $DBase_INI = "host= $ConList[$j] port=5432 dbname=svm user=accordance password=1qaz2wsx";
                $testDb=pg_connect($DBase_INI); 
            
                if($testDb == FALSE)
                {
            	    echo "connect error";
                }
                else
                {
                    $sql = "select rx_u_log.*, kvm_table.kvm_name,rcvm_table.rcvm_name from rx_u_log left join rcvm_table on rx_u_log.rx_ip = rcvm_table.rcvm_ip left join kvm_table on rx_u_log.rx_ip = kvm_table.kvm_ip where (to_timestamp(changtime,'yyyy/MM/dd hh24:mi:ss')) between (to_timestamp('$start_date','yyyy/MM/dd hh24:mi:ss')) and (to_timestamp('$end_date','yyyy/MM/dd hh24:mi:ss'))";
                    if($user == "All" && $userIP == "All")
                        $sql = $sql;
                    if($user != "All" && $userIP == "All")
                        $sql = $sql." and user_id = '$user'";
                    if($user == "All" && $userIP != "All")
                        $sql = $sql." and rx_ip = '$userIP'";
                    if($user != "All" && $userIP != "All")
                        $sql = $sql." and user_id = '$user' and rx_ip = '$userIP'";
                    if($ControlIP != "All")
                        $sql = $sql."and rx_ip ='$ControlIP'or view_ip like('$ControlIP%')";
                        
                    $result = pg_exec($testDb, $sql);
                
                /*    $result = pg_exec($testDb, "select rx_u_log.*, kvm_table.kvm_name,rcvm_table.rcvm_name "
                        + "from rx_u_log "
                        + "left join rcvm_table "
                        + "on rx_u_log.rx_ip = rcvm_table.rcvm_ip "
                        + "left join kvm_table "
                        + "on rx_u_log.rx_ip = kvm_table.kvm_ip "
                        + "where (to_timestamp(changtime,'yyyy/MM/dd hh24:mi:ss')) "
                        + "between (to_timestamp('$start_date','yyyy/MM/dd hh24:mi:ss')) "
                        + "and (to_timestamp('$end_date','yyyy/MM/dd hh24:mi:ss')) ")
                        + "and user_id ='$user'";
                */
                    
                    $numrows = pg_num_rows($result);
                    echo "$numrows";
                    $skip = false;
        
                    for($i=0;$i<$numrows;$i++)
                    {
                        $info=pg_fetch_array($result);
                        if ($skip == true)
                        {
                            $skip = false;
                            continue;
                        }
                        $test0= trim($info[0]);
                        $test1= trim($info[1]);
                        $test2= trim($info[2]);
                        $test3= trim($info[3]);
                        $test4= trim($info[4]);
                        $test5= trim($info[5]);
                        $test6= trim($info[6]);
                        $count_2 = $count-1;
                        if ($test2 == "login")
                        {
                            $test3 = _('login');
                            $test2 = "RCVM";
                            $skip = true;  
                            echo "<tr><td>$test4</td><td>$test0</td><td>$test1</td><td>$test0</td><td>$test3</td><td>$test2</td><td>$test6</td><td>$FacList[$count_2]</td>";
                        }
                        if ($test2 == "logout")
                        {
                            $test3 = _('logout');
                            $test2 = "RCVM";
                            echo "<tr><td>$test4</td><td>$test0</td><td>$test1</td><td>$test0</td><td>$test3</td><td>$test2</td><td>$test6</td><td>$FacList[$count_2]</td>";
                        }
                        if (strpos($test2,"change_kvm")!=false)
                        {
                            $new_test2 = substr($test2, 0 ,stripos($test2,"p"));
                            $test3 = "change_kvm";
                            $test2 = "KVM";
                            
														$sq2 = "select kvm_name from kvm_table where kvm_ip ='$new_test2'";
														$result2 = pg_exec($testDb, $sq2);
														$numrows2 = pg_num_rows($result2);
														for($i=0;$i<$numrows2;$i++)
														{
																$info=pg_fetch_array($result2);
																$test5= trim($info[0]);
														} 
														  
                            echo "<tr><td>$test4</td><td>$test0</td><td>$test1</td><td>$new_test2</td><td>$test3</td><td>$test2</td><td>$test5</td><td>$FacList[$count_2]</td>";
                        }
                        if (strpos($test2,"ctrol_end")!=false)
                        {
                            $new_test2 = substr($test2, 0 ,stripos($test2,"p"));
                            $test3 = _('Ctrl_End');
                            $test2 = "KVM";
                            
														$sq2 = "select kvm_name from kvm_table where kvm_ip ='$new_test2'";
														$result2 = pg_exec($testDb, $sq2);
														$numrows2 = pg_num_rows($result2);
														for($i=0;$i<$numrows2;$i++)
														{
																$info=pg_fetch_array($result2);
																$test5= trim($info[0]);
														}
														   
                            echo "<tr><td>$test4</td><td>$test0</td><td>$test1</td><td>$new_test2</td><td>$test3</td><td>$test2</td><td>$test5</td><td>$FacList[$count_2]</td>";
                        }
                        if ($test3=="13")
                        {
                            $new_test2 = substr($test2, 0 ,stripos($test2,"p"));
                            $test3 = "Ctrl_Timeout";
                            $test2 = "KVM";
                            echo "<tr><td>$test4</td><td>$test0</td><td>$test1</td><td>$new_test2</td><td>$test3</td><td>$test2</td><td>$test5</td><td>$FacList[$count_2]</td>";
                        }
                        if ($test3=="14")
                        {
                            $new_test2 = substr($test2, 0 ,stripos($test2,"p"));
                            $test3 = "RCM_Connect";
                            $test2 = "KVM";
                            echo "<tr><td>$test4</td><td>$test0</td><td>$test1</td><td>$new_test2</td><td>$test3</td><td>$test2</td><td>$test5</td><td>$FacList[$count_2]</td>";
                        }
                        if ($test3=="15")
                        {
                            $new_test2 = substr($test2, 0 ,stripos($test2,"p"));
                            $test3 = "RCM_Disconnect";
                            $test2 = "KVM";
                            echo "<tr><td>$test4</td><td>$test0</td><td>$test1</td><td>$new_test2</td><td>$test3</td><td>$test2</td><td>$test5</td><td>$FacList[$count_2]</td>";
                        }
                        if (strpos($test2,"p")!=false)
                        {
                            $new_test2 = substr($test2, 0 ,stripos($test2,"p"));
                            $test3 = _('Ctrl');
                            $test2 = "KVM";
                            
														$sq2 = "select kvm_name from kvm_table where kvm_ip ='$new_test2'";
														$result2 = pg_exec($testDb, $sq2);
														$numrows2 = pg_num_rows($result2);
														for($i=0;$i<$numrows2;$i++)
														{
																$info=pg_fetch_array($result2);
																$test5= trim($info[0]);
														} 
														  
                            echo "<tr><td>$test4</td><td>$test0</td><td>$test1</td><td>$new_test2</td><td>$test3</td><td>$test2</td><td>$test5</td><td>$FacList[$count_2]</td>";
                        }
                        if (strpos($test2,"-")!=false)
                        {
                            $new_test2 = substr($test2, 0 ,stripos($test2,"-"));
                            $test3 = _('Initialize');
                            $test2 = "KVM";
                            echo "<tr><td>$test4</td><td>$test0</td><td>$test1</td><td>$new_test2</td><td>$test3</td><td>$test2</td><td>$test5</td><td>$FacList[$count_2]</td>";
                        }
                        echo "</tr>";
                    }
                    pg_close($testDb);
                }
            }
            echo "</table>";
        ?>
  
        <?php 
        session_start();
            $_SESSION['factory'] = $factory;
            $_SESSION['user'] = $user;
            $_SESSION['start_date'] = $start_date;
            $_SESSION['end_date'] = $end_date;
            $_SESSION['userIP'] = $userIP;
        ?>
</body>
</html>
















