<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>

  	<?php echo _('Factory Choose');?>
	<form name="input" action="log_search_msmq_kvm.php" method="post">  
		<select id="factory" name="factory" onchange="">
		<option value ="All"> All </option>
            <?php 

            // Connection
            $ConList = array();
            // Factory
            $FacList= array();
            // Factory Choos List
            $FacChoose = array();
            
            // ���J db_txt �ëإ� Connection Pool List
            $file_path = "db_list.txt";
            if(file_exists($file_path))
            {
                $file_arr = file($file_path);
                for($i=0;$i<count($file_arr);$i++) //�v��Ū���ɮפ��e
                {
                    $seperate = explode(";", $file_arr[$i]);
                    array_push($FacList,$seperate[0]);
                    array_push($ConList,$seperate[1]);
                    array_push($FacChoose,$i+1);
                    echo("<option value ='$seperate[0]'>$seperate[0]</option>");
                }
            }
            ?>
        </select>
        <?php 
            session_start();
            $_SESSION['FacList'] = $FacList;
            $_SESSION['ConList'] = $ConList;
            $_SESSION['FacChoose'] = $FacChoose;
        ?>

        <input type="submit" value="<?php echo _('OK');?>">
	</form>
  </body>
</html>
