<html>
<head>
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_del_kvm.php" method="get">  
		<table>
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from ocr_table order by kvm_ip asc ");
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$kvm_ip = trim($info[0]);
		$t1 = trim($info[1]);
		echo "<tr><td><a href=\"set_del_kvmv.php?delid=$t1\" >delete</a></td><td>$kvm_ip</td>";
		for ($j = 1; $j < 20; $j++) 
		//if( strcmp( $user, "admin") )
		{
			$value1 = trim($info[$j]);
			echo "<td>$value1<td>";
		}
		echo "</tr>";
	}
	pg_close($testDb); 
	//echo "<frame name=\"main\" src=\"page16_a.php?web_ip=$web_ip&web_port=$web_port&web_path=$web_path&page_w=$web_w&page_h=$web_h\" scrolling=\"auto\" target=\"_self\">"; 
}
?> 
		</table> 
	</form>
  </body>
</html>
