<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<?php echo _('Reset database setting');?>
<br>
<a href="db_set.php" target="main" ><?php echo _('Main database setting');?></a><br>
<br>
<br>
</body>
</html>