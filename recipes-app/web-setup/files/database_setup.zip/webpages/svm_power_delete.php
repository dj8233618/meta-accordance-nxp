<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
	<body>
<?php
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    
    $result = pg_exec($testDb, "select * from kvm_table where rcvm_ip !='' order by rcvm_ip asc ");
	if ($result) 
	{
		//$numrows = pg_num_rows($result);
		$numrows = pg_num_rows($result);
		echo "<table>";
		for($i=0;$i<$numrows;$i++)
		{
			$info=pg_fetch_array($result);
			$rcvm_ip = trim($info[8]);
			$kvm_ip = trim($info[1]);
			
			
			echo "<tr><td>SVM =$rcvm_ip </td><td> KVM =$kvm_ip </td><td>";
			
			if( strcmp( $rcvm_ip, "admin") )
			{
				echo "<a href=\"set_svm_machine_delete.php?A=$rcvm_ip&B=$kvm_ip\" >"?><?php echo _('delete');?> <?php "</a>";
			}
			echo"<br>";
			echo "</td></tr>";
			
		}
		echo "</table>";
	}
    pg_close($testDb);
}

?>
	</body>
</html>