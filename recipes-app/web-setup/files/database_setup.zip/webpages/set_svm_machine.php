<?php
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    
    $rcvm_ip = $_POST["svm"];
    $kvm = $_POST["kvm"];
    $length =sizeof($kvm);
    
    for($i=0;$i<$length;$i++)
    {
        $sql = "update kvm_table set rcvm_ip ='$rcvm_ip' where kvm_ip='$kvm[$i]'";
        $result = pg_exec($testDb, $sql);
    }
    echo "connect success";
    
    echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
    pg_close($testDb);
}

?>