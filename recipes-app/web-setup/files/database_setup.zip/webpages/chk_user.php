<?php
include_once("web_conf.php");
//require_once('syslog.php');
$user = $_GET['id'];
$password = $_GET['pw'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from user_m where user_id = '$user' and user_pwd = '$password' ");
	$numrows = pg_num_rows($result);
	if( $numrows )
	{
		//echo "SUCCESS!!";
		$info=pg_fetch_array($result);
		$file = trim($info[4]);
		echo $file ;
	}
	else
	{
		echo "0";
	}
	pg_close($testDb); 
}

?>