<?php
//$ip =$_GET['ip'];
$ip ="10.0.5.52";
//$myPath =$_GET['path'];
$myPath ="C:\\inetpub\\wwwroot\\";

include_once("web_conf.php");

$testDb = pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}

if($testDb!= FALSE )
{
    //$set="rcvm_ip";
    $table="kvm_table";
    $field="kvm_ip";
    $sql="select "."*"." from ".$table." where ".$field."='".$ip."'"; 
    $result=pg_exec($testDb,$sql);
    $arrResult = pg_fetch_all($result);
    
    $filename = $arrResult[0][rcvm_ip];
    $filename = trim($filename)."p".$arrResult[0][kvm_port]."\\";
    var_dump($filename);
    
    if( $filename )
    
    {
        if ( $myPath)
        {
            
            $myFile = $myPath.$filename;
        }
        else
        {
            
            $myFile = "\\".$filename;
        }
    }
    else
    {
        if ( $myPath)
        {
            $myFile = $myPath."\black.jpg";
        }
        else
        {
            $myFile = "\black.jpg";
        }
    }
    $myFile1 = trim($myFile)."black.jpg";
    var_dump($myFile1);
    
//     $filesnames = scandir($myFile1);
//     //$www = 'http://www.downloadfile2.com/'; 
//     rsort($filesnames);
//     foreach ($filesnames as $name) {
//         $aurl= "<img width='320' height='240'  alt = '".$name."'>"; 
//         echo $aurl . "<br/>"; 
//         break;
//     }

//     echo $myFile1."<br>----";
//     echo filesize($myFile1)."<br>";
//     echo realpath($myFile1)."<br>";
//     echo filesize(realpath($myFile1))."<br>";
    $mm_type="image/jpeg";
    
//     header("Cache-Control: public, must-revalidate");
//     header("Pragma: hack"); // WTF? oh well, it works...
//     header("Content-Type: ".$mm_type);
//     header("file-name: ".$myFile1);
//     header("Content-Length: ".(filesize($myFile1)) );
//     readfile(realpath($myFile1));
}
?>