<?php
include_once("web_conf.php");
//require_once('syslog.php');
$kvm_ip = $_GET['delid'];
$kvm_port = $_GET['delide'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$sql = "delete from tx_table where kvm_ip='".$kvm_ip."p".$kvm_port."' ";
	//echo $sql;
	$result = pg_exec($testDb, $sql);
	echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	pg_close($testDb); 
}

?>