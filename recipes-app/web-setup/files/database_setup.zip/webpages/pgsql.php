<?php
//-------------------------------------------------------------------- 
//filename:class.php 
//summary: access�ƾڮw�ާ@�� 
//   �ϥνd�ҡG 
//$databasepath="database.mdb"; 
//$dbusername=""; 
//$dbpassword=""; 
//include_once("class.php"); 
//$access=new access($databasepath,$dbusername,$dbpassword); 
//<p style="padding:6px;background:#FFF;">
//-------------------------------------------------------------------- 
	//include_once("web_conf.php");
	$databasepath="svm.mdb"; 
	$dbusername=""; 
	$dbpassword=""; 
	$table="tx_table";
	$table_m="tx_m_table";
	$ocr_table="ocr_table";
	$field="kvm_ip";
	$set="tx_ip";
	$set_io="tx_dul";
	$machine_s="machine_State";
	class access 
	{ 
		var $databasepath,$constr,$dbusername,$dbpassword,$link; 
		function access($databasepath,$dbusername,$dbpassword) 
		{ 
			$this->databasepath=$databasepath; 
			$this->username=$dbusername; 
			$this->password=$dbpassword; 
			//$this->connect(); 
		} 
		function connectdb()
		{
		    include("web_conf.php");
		    $testDb=pg_connect($DBase_INI);
		    
		    if($testDb == FALSE)
		    {
		        echo "connect error";
		    }
		    else
		    {
		        //echo "connect success <br>";
		        return $testDb;
		    }
		}
		function connect() 
		{ 
			include_once("web_conf.php");
			//echo "$DBase_INI------";
			$this->link = pg_connect($DBase_INI); 
			if($this->link == FALSE)
			{
				//echo $this->constr;
				echo "link  error";
			}
			else
			{
				//echo "link  OK";
			}
			//$err =@odbc_exec($this->link,$sql);
			//if($err == FALSE)
			//{
			//	echo $sql;
			//	echo "link  error";
			//}
			return $this->link; 
			//if($this->link) echo "���ߧA,�ƾڮw�s�����\!"; 
			//else echo "�ƾڮw�s������!"; 
		} 
		
		function query($sql) 
		{ 
			if($this->link)
			{
			   return pg_exec($this->link,$sql); 
			}
			else
			{
				//echo "----";
			}
		} 
		
		function first_array($sql) 
		{ 
			return pg_fetch_array($this->query($sql)); 
		} 
		
		function fetch_row($query) 
		{ 
			return pg_num_rows($query); 
		} 
		
		function total_num($sql)//���o�O���`�� 
		{ 
			return pg_num_rows($this->query($sql)); 
		} 
		
		function close()//�����ƾڮw�s����� 
		{  
			if($this->link)
			{
				pg_close($this->link); 
			}
		} 
		
		function insert($table,$field,$myIP)//���J�O����� 
		{ 
			$sql="insert into ".$table." (".$field.",tx_ip) values ('".$myIP."','screenshot.jpg')"; 
			//echo $sql;
			$this->query($sql); 
		} 
		
		function insert_m($table,$field,$myIP,$mychannel)//���J�O����� 
		{ 
			$sql="insert into ".$table." (".$field.",tx_ip,tx_channel) values ('".$myIP."','screenshot.jpg','".$mychannel."')"; 
			//echo $sql;
			$this->query($sql); 
		} 
		
		function ocr_insert($ocr_table,$mytable,$myvalue,$myIP)//���J�O����� 
		{ 
			$today = Date("Y/m/d H:i:s");
			$sql="insert into ".$ocr_table." (kvm_ip,starttime,t".$mytable.") values ('".$myIP."','".$today."','".$myvalue."')"; 
			//echo $sql;
			$this->query($sql); 
		} 
		
		function machine_insert($machine_s,$myIP,$myvalue)//���J�O����� 
		{ 
			$today = Date("Y/m/d H:i:s");
			$sql="insert into ".$machine_s." (kvm_ip,starttime,sstatus) values ('".$myIP."','".$today."','".$myvalue."')"; 
			//echo $sql;
			$this->query($sql); 
		} 
		
		function insert_io($table,$field,$myIP)//���J�O����� 
		{ 
			$sql="insert into ".$table." (".$field.",tx_dul) values ('".$myIP."','1')"; 
			//echo $sql;
			$this->query($sql); 
		} 

		function getio_one($table,$field)//���o�����O���ԲӫH�� 
		{ 
			$sql="select * from ".$table." where tx_dul='1'"; 
			//echo $sql;
			$query=$this->query($sql);
			$numrows = $this->fetch_row($query);
			if($numrows) 
			{ 
				$info=pg_fetch_array($query,0);
				return $info[0];
			} 
			return $numrows; 
		} 
		
		function getmachine_one($table,$field,$myIP)//���o�����O���ԲӫH�� 
		{ 
			$sql="select * from ".$table." where ".$field."='".$myIP."' "; 
			//echo $sql;
			$query=$this->query($sql);
			$numrows = $this->fetch_row($query);
			if($numrows) 
			{ 
				$info=pg_fetch_array($query,0);
				return $info[2];
			}
			else
			{
			} 
			return $numrows; 
		} 

		function getmachine_two($table,$field,$myIP,$field2,$myIP2)//���o�����O���ԲӫH�� 
		{ 
			$sql="select * from ".$table." where ".$field."='".$myIP."' and ".$field2."='".$myIP2."'"; 
			//echo $sql;
			$query=$this->query($sql);
			$numrows = $this->fetch_row($query);
			if($numrows) 
			{ 
				$info=pg_fetch_array($query,0);
				return $info[2];
			}
			else
			{
			} 
			return $numrows; 
		} 


		function getmachine_old($table,$myvalue)//���o�����O���ԲӫH�� 
		{ 
			$sql="select * from ".$table." where sstatus='".$myvalue."' order by starttime asc ";
			 //     select * from machine_State where sstatus='2' order by starttime asc ; 
			//echo $sql;
			$query=$this->query($sql);
			$numrows = $this->fetch_row($query);
			if($numrows) 
			{ 
				$info=pg_fetch_array($query,0);
				return $info[0];
			}
			else
			{
			} 
			return $numrows; 
		} 
		
		function getinfo_one($table,$field,$id,$set)//���o�����O���ԲӫH�� 
		{ 
// 		    $databasepath="svm.mdb";
// 		    $dbusername="accordance";
// 		    $dbpassword="1qaz2wsx";
// 		    $table="kvm_table";
// 		    $table_m="tx_m_table";
// 		    $ocr_table="ocr_table";
// 		    $field="kvm_ip";
// 		    $set="rcvm_ip";
// 		    $set_io="tx_dul";
// 		    $machine_s="machine_State";
			$sql="select ".$set." from ".$table." where ".$field."='".$id."'"; 
			//echo $sql;
			
			$query=$this->query($sql);
			$numrows = $this->fetch_row($query);
			if($numrows) 
			{ 
				$info=pg_fetch_array($query,0);
			//echo $info[0];
				return $info[0];
			} 
			return $numrows; 
		} 
		
		function getinfo_one_m($table,$field,$id,$set,$mychannel)//���o�����O���ԲӫH�� 
		{ 
			$sql="select ".$set." from ".$table." where ".$field."='".$id."' and tx_channel='".$mychannel."' "; 
			//echo $sql;
			$query=$this->query($sql);
			$numrows = $this->fetch_row($query);
			if($numrows) 
			{ 
				$info=pg_fetch_array($query,0);
			//echo $info[0];
				return $info[0];
			} 
			return $numrows; 
		} 
		
		function ocr_getinfo_one($ocr_table,$mytable,$myvalue)//���o�����O���ԲӫH�� 
		{ 
			$sql="select ".$mytable." from ".$ocr_table." where t".$mytable."='".$myvalue."'"; 
			//echo $sql;
			$query=$this->query($sql);
			$numrows = $this->fetch_row($query);
			if($numrows) 
			{ 
				$info=pg_fetch_array($query,0);
				return $info[0];
			} 
			return $numrows; 
		} 
		
		function getinfo($table,$field,$id,$cbnum)//���o�����O���ԲӫH�� 
		{ 
			$sql="select * from ".$table." where ".$field."=".$id.""; 
			$query=$this->query($sql); 
			if($this->fetch_row($query)) 
			{ 
				for ($i=1;$i<$cbnum;$i++) 
				{ 
					$info[$i]=odbc_result($query,$i); 
				} 
			} 
			return $info; 
		} 
		
		function getinfo_m($table,$field,$id,$cbnum,$mychannel)//���o�����O���ԲӫH�� 
		{ 
			$sql="select * from ".$table." where ".$field."=".$id." and tx_channel='".$mychannel."'"; 
			$query=$this->query($sql); 
			if($this->fetch_row($query)) 
			{ 
				for ($i=1;$i<$cbnum;$i++) 
				{ 
					$info[$i]=odbc_result($query,$i); 
				} 
			} 
			return $info; 
		} 
		
		function getlist($table,$field,$cbnum,$condition,$sort="order by id desc")//���o�O���C��   
		{ 
			$sql="select * from ".$table." ".$condition." ".$sort; 
			$query=$this->query($sql); 
			$i=0; 
			while ($this->fetch_row($query))
			{ 
				$recordlist[$i]=getinfo($table,$field,odbc_result($query,1),$cbnum); 
				$i++; 
			} 
			return $recordlist; 
		} 
		
		function getfieldlist($table,$field,$fieldnum,$condition="",$sort="")//���o�O���C�� 
		{ 
			$sql="select ".$field." from ".$table." ".$condition." ".$sort; 
			$query=$this->query($sql); 
			$i=0; 
			while ($this->fetch_row($query))
			{ 
				for ($j=0;$j<$fieldnum;$j++) 
				{ 
					$info[$j]=odbc_result($query,$j+1); 
				}   
				$rdlist[$i]=$info; 
				$i++; 
			} 
			return $rdlist; 
		} 
		
		function updateinfo($table,$field,$myIP,$set,$myFile)//��s�O�� 
		{ 
			$sql="update ".$table." set ".$set."='".$myFile."' where ".$field."='".$myIP."'"; 
			//echo $sql;
			$this->query($sql); 
		} 

		function updateinfo_m($table,$field,$myIP,$set,$myFile,$mychannel)//��s�O�� 
		{ 
			$sql="update ".$table." set ".$set."='".$myFile."' where ".$field."='".$myIP."' and tx_channel='".$mychannel."' "; 
			echo $sql;
			$this->query($sql); 
		} 

		function ocr_updateinfo($ocr_table,$mytable,$myvalue,$myIP,$mytkey)//��s�O�� 
		{ 
			$today = Date("Y/m/d H:i:s");
			$sql="update ".$ocr_table." set lasttime='".$today."' , t".$mytable."='".$myvalue."' where t1='".$mytkey."'"; 
			//echo $sql;
			$this->query($sql); 
		} 
		
		function updateinfo_machine($machine_s,$myIP,$myvalue)//���J�O����� 
		{ 
			$today = Date("Y/m/d H:i:s");
			$sql="update ".$machine_s." set starttime='".$today."' , sstatus='".$myvalue."' where kvm_ip='".$myIP."'";
			//echo $sql;
			$this->query($sql); 
		} 

		function updateinfo_io($table,$field,$myIP,$set_io,$myFile)//��s�O�� 
		{ 
			$sql="update ".$table." set ".$set_io."='".$myFile."' where ".$field."='".$myIP."'"; 
			$this->query($sql); 
		} 
		
		function deleteinfo($table,$field,$id)//�R���O�� 
		{ 
			$sql="delete from ".$table." where ".$field."=".$id; 
			$this->query($sql); 
		} 
		
		function deleterecord($table,$condition)//�R�����w���󪺰O�� 
		{ 
			$sql="delete from ".$table." where ".$condition; 
			$this->query($sql); 
		} 
		
		function getcondrecord($table,$condition="")// ���o���w���󪺰O���� 
		{ 
			$sql="select count(*) as num from ".$table." ".$condition; 
			$query=$this->query($sql); 
			$this->fetch_row($query); 
			$num=odbc_result($query,1); 
			return $num;           
		} 
	} 
?>
