<?php
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    $rcvm_id = $_POST["rcvm_id"];
    $rcvm_ip = $_POST["rcvm_ip"];
    $rcvm_port = $_POST["rcvm_port"];
    $rcvm_pwd = $_POST["rcvm_pwd"];
    $rcvm_power = $_POST["rcvm_power"];
    $rcvm_name = $_POST["rcvm_name"];
    $rcvm_local = $_POST["rcvm_local"];
    $rcvm_mac = $_POST["rcvm_mac"];
    $rcvm_path= $_POST["rcvm_path"];
    
    $sql = "select * from rcvm_table where rcvm_name='$rcvm_name' ";
 		//echo $sql;
 		
		$result1 = pg_exec($testDb, $sql);
    $numrows1 = pg_num_rows($result1);
    
		if( $numrows1 > 0)
		{
			$sql = "update rcvm_table set rcvm_id='$rcvm_id' , rcvm_pwd='$rcvm_pwd' , rcvm_power='$rcvm_power' , rcvm_local='$rcvm_local' , rcvm_mac='$rcvm_mac' , rcvm_path='$rcvm_path' ,rcvm_ip='$rcvm_ip' , rcvm_port='$rcvm_port' where rcvm_name='$rcvm_name' ";
			//echo $sql;
			echo "update";
		}
		else
		{
    //var_dump($rcvm_ip);
    //var_dump($rcvm_port);
    
    $sql = "insert into rcvm_table (rcvm_id,rcvm_ip,rcvm_port,rcvm_pwd,rcvm_power,rcvm_name,rcvm_local,rcvm_mac,rcvm_path)
            select '$rcvm_id','$rcvm_ip','$rcvm_port','$rcvm_pwd','$rcvm_power','$rcvm_name','$rcvm_local','$rcvm_mac','$rcvm_path'
            where not exists (select * from rcvm_table where rcvm_id='$rcvm_id' and rcvm_ip='$rcvm_ip' and rcvm_port='$rcvm_port'
            and rcvm_pwd='$rcvm_pwd' and rcvm_power='$rcvm_power' and rcvm_name='$rcvm_name' and rcvm_local='$rcvm_local' and rcvm_mac='$rcvm_mac' and rcvm_path='$rcvm_path')";
			echo "insert";
    }
    $result = pg_exec($testDb, $sql);
    
    //var_dump($sql);
    echo "connect success";
    //echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
    pg_close($testDb);
}

?>