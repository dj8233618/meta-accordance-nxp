ALTER database svm;
-- Table: alide_table

-- DROP TABLE alide_table;
CREATE TABLE alarm_spt_log
(
	kvm_name character(32),
	kvm_ip character(32),
	kvm_port integer,
	rcm_ip character(32),
	rcm_channel integer,
	alarm_active character(12),
	alarm_id character(50),
	alarm_time character(25),
	spt_file character(250),
	user_id character(50)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE alarm_spt_log
  OWNER TO accordance;


CREATE TABLE alarm_table
(
  "Index" integer,
  "Job No" character(50),
  csv character(50)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE alarm_table
  OWNER TO accordance;

CREATE TABLE alide_table
(
  alid character(50),
  class character(25),
  alarm_text character(255)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE alide_table
  OWNER TO accordance;

CREATE TABLE tx_point_log
(
  view_ip character(50),
  changtime character(25),
  mytable character(50),
  myvalue character(255),
  panon_id character(50)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tx_point_log
  OWNER TO accordance;

CREATE TABLE tx_table
(
  kvm_ip character(50),
  tx_ip character(50),
  tx_dul integer,
  tx_addr character(50),
  tx_enble integer,
  tx_active integer,
  CONSTRAINT tx_table_kvm_ip_key UNIQUE (kvm_ip)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tx_table
  OWNER TO accordance;

CREATE TABLE tx_m_table
(
  kvm_ip character(50),
  tx_ip character(50),
  tx_dul integer,
  tx_addr character(50),
  tx_channel character(50),
  tx_enble integer,
  tx_active integer
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tx_m_table
  OWNER TO accordance;

CREATE TABLE rx_tx_point_log
(
  rx_ip character(50),
  rx_name character(50),
  message character(255),
  op_name character(255),
  op_id character(255),
  chip_id character(255),
  defect_code character(255),
  ldl_status character(255),
  eqp_id character(255),
  x character(255),
  y character(255),
  create_dttm character(255)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE rx_tx_point_log
  OWNER TO accordance;

CREATE TABLE rx_table
(
  rx_ip character(50),
  rx_port character(50),
  rx_id character(50),
  rx_pwd character(50),
  rx_3ver integer,
  rx_dul integer,
  view_ip character(50),
  pc_mac character(50),
  user_id character(50),
  lot_id character(50),
  glass_id character(50),
  panel_id character(50),
  auto_sort integer,
  changtime character(25),
  msmq_ip character(50),
  msmq_queue character(50)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE rx_table
  OWNER TO accordance;

CREATE TABLE rx_u_log
(
  rx_ip character(50),
  changtime character(25),
  view_ip character(50),
  use_mode integer,
  user_id character(50)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE rx_u_log
  OWNER TO accordance;
  
CREATE TABLE user_m
(
  user_id character(512),
  user_pwd character(512),
  user_name character(512),
  user_gp character(512),
  user_pwr integer,
  user_change integer,
  user_dept character(32),
  user_section character(32),
  CONSTRAINT user_m_user_id_key UNIQUE (user_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE user_m
  OWNER TO accordance;

insert into user_m (user_id, user_pwd, user_pwr) values ('admin','1qaz2wsx', 99 );
insert into user_m (user_id, user_pwd, user_pwr) values ('op1','op1', 2 ) ;
insert into user_m (user_id, user_pwd, user_pwr) values ('view','view', 1 );
insert into user_m (user_id, user_pwd, user_pwr) values ('RCM','RCM', 3 );
insert into user_m (user_id, user_pwd, user_pwr) values ('DB','DB', 98 );

CREATE TABLE web_set
(
  web_name character(256),
  web_ip character(256),
  web_port character(256),
  web_path character(256),
  web_16w character(10),
  web_16h character(10),
  web_w character(10),
  web_h character(10)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE web_set
  OWNER TO accordance;
insert into web_set (web_name, web_ip, web_port, web_path, web_16w, web_16h, web_w, web_h) values ('accordance','127.0.0.1','80', 'C:/inetpub/wwwroot/', '320', '240', '800', '600'  );

CREATE TABLE rcvm_table
(
  rcvm_id character(16),
  rcvm_ip character(32),
  rcvm_port integer,
  rcvm_pwd character(16),
  rcvm_power integer,
  rcvm_name character(32),
  rcvm_local character(32),
  rcvm_mac character(32),
  rcvm_path character(256),
  rcvm_time_ms character(32)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE rcvm_table
  OWNER TO accordance;
  
CREATE TABLE kvm_table
(
  kvm_id character(16),
  kvm_ip character(32),
  kvm_port integer,
  kvm_pwd character(16),
  kvm_model character(32),
  kvm_name character(32),
  kvm_local character(32),
  rcvm_id character(16),
  rcvm_ip character(32),
  rcvm_path character(256),
  rcvm_port integer,
  kvm_mac character(32),
  kvm_https integer,
  tx_ip character(32),
  tickey_1 character(512),
  f_realvnc character(16),
  kvm_fab character(32),
  kvm_dept character(32),
  kvm_sect character(32),
  kvm_pg character(32),
  kvm_vender character(32),
  kvm_mc_group character(32),
  kvm_mc_model character(50),
  kvm_mc_ver character(50),
  kvm_active character(12),
  alarm_id character(50),
  RCM_ip character(32),
  RCM_port integer,
  RCM_channel integer,
	msmq_queue character(32),
	msmq_label character(32),
	msmq_queue_type character(32),
	msmq_queue_formatter character(32),
	alarm_time character(25),
	alarm_PID character(25),
	alarm_color character(25),
	asi_kvm_state character(25),
  CONSTRAINT kvm_table_kvm_name_key UNIQUE (kvm_name)

)
WITH (
  OIDS=FALSE
);
ALTER TABLE kvm_table
  OWNER TO accordance;

CREATE TABLE kvm_svm_table
(
  kvm_ip character(32),
	kvm_connect integer,
	kvm_scaling integer,
	kvm_cursor integer,
	kvm_format integer,
  kvm_quality character(5),
  kvm_snaphot character(5),
  kvm_timeout character(5),
  kvm_restart character(5),
  kvm_ocr_enable integer,
  kvm_ocr_file character(250),
  kvm_ocr_interval integer,
  kvm_ocr_times integer,
  kvm_ocr_x   character(10),
  kvm_ocr_y   character(10),
  kvm_ocr_w   character(10),
  kvm_ocr_h   character(10),
  kvm_ocr_word   character(10),
  kvm_ocr_color   character(10),
  kvm_conn_retry   character(10),
  kvm_ocrs_enable   character(10),
  kvm_ocrs_key   character(10),
  kvm_io_port   character(10)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE kvm_svm_table
  OWNER TO accordance;

  
CREATE TABLE user_index
(
	user_id character(16) ,
	rcvm_id character(16) ,
	rcvm_ip character(32) ,
	rcvm_port integer,
	rcvm_power integer,
	kvm_id character(16) ,
	kvm_ip character(32) ,
	kvm_port integer,
	kvm_power integer ,
	kvm_show integer ,
	kvm_gp character(32), 
	use_lyout integer 
)
WITH (
  OIDS=FALSE
);
ALTER TABLE user_index
  OWNER TO accordance;
  
CREATE TABLE ocr_table
(
  kvm_ip character(50),
  starttime character(25),
  lasttime character(25),
  t0 character(100),
  t1 character(100),
  t2 character(100),
  t3 character(100),
  t4 character(100),
  t5 character(100),
  t6 character(100),
  t7 character(100),
  t8 character(100),
  t9 character(100),
  t10 character(100),
  t11 character(100),
  t12 character(100),
  t13 character(100),
  t14 character(100),
  t15 character(100),
  t16 character(100),
  t17 character(100),
  t18 character(100),
  t19 character(100),
  t20 character(100),
  t21 character(100),
  t22 character(100),
  t23 character(100),
  t24 character(100),
  t25 character(100),
  t26 character(100),
  t27 character(100),
  t28 character(100),
  t29 character(100),
  t30 character(100),
  t31 character(100),
  t32 character(100),
  t33 character(100),
  t34 character(100),
  t35 character(100),
  t36 character(100),
  t37 character(100),
  t38 character(100),
  t39 character(100),
  t40 character(100),
  t41 character(100),
  t42 character(100),
  t43 character(100),
  t44 character(100),
  t45 character(100),
  t46 character(100),
  t47 character(100),
  t48 character(100),
  t49 character(100),
  t50 character(100),
  t51 character(100),
  t52 character(100),
  t53 character(100),
  t54 character(100),
  t55 character(100),
  t56 character(100),
  t57 character(100),
  t58 character(100),
  t59 character(100),
  t60 character(100),
  t61 character(100),
  t62 character(100),
  t63 character(100),
  t64 character(100),
  t65 character(100),
  t66 character(100),
  t67 character(100),
  t68 character(100),
  t69 character(100),
  t70 character(100),
  t71 character(100),
  t72 character(100),
  t73 character(100),
  t74 character(100),
  t75 character(100),
  t76 character(100),
  t77 character(100),
  t78 character(100),
  t79 character(100),
  t80 character(100),
  t81 character(100),
  t82 character(100),
  t83 character(100),
  t84 character(100),
  t85 character(100),
  t86 character(100),
  t87 character(100),
  t88 character(100),
  t89 character(100),
  t90 character(100),
  t91 character(100),
  t92 character(100),
  t93 character(100),
  t94 character(100),
  t95 character(100),
  t96 character(100),
  t97 character(100),
  t98 character(100),
  t99 character(100),
  t100 character(100),
  t101 character(100),
  t102 character(100),
  t103 character(100),
  t104 character(100),
  t105 character(100),
  t106 character(100),
  t107 character(100),
  t108 character(100),
  t109 character(100),
  t110 character(100),
  t111 character(100),
  t112 character(100),
  t113 character(100),
  t114 character(100),
  t115 character(100),
  t116 character(100),
  t117 character(100),
  t118 character(100),
  t119 character(100),
  t120 character(100),
  t121 character(100),
  t122 character(100),
  t123 character(100),
  t124 character(100),
  t125 character(100),
  t126 character(100),
  t127 character(100),
  t128 character(100),
  t129 character(100),
  t130 character(100),
  t140 character(100),
  t141 character(100),
  t142 character(100),
  t143 character(100),
  t144 character(100),
  t145 character(100),
  t146 character(100),
  t147 character(100),
  t148 character(100),
  t149 character(100),
  t150 character(100),
  t151 character(100),
  t152 character(100),
  t153 character(100),
  t154 character(100),
  t155 character(100),
  t156 character(100),
  t157 character(100),
  t158 character(100),
  t159 character(100),
  t160 character(100),
  t161 character(100),
  t162 character(100),
  t163 character(100),
  t164 character(100),
  t165 character(100),
  t166 character(100),
  t167 character(100),
  t168 character(100),
  t169 character(100),
  t170 character(100),
  t171 character(100),
  t172 character(100),
  t173 character(100),
  t174 character(100),
  t175 character(100),
  t176 character(100),
  t177 character(100),
  t178 character(100),
  t179 character(100),
  t180 character(100),
  t181 character(100),
  t182 character(100),
  t183 character(100),
  t184 character(100),
  t185 character(100),
  t186 character(100),
  t187 character(100),
  t188 character(100),
  t189 character(100),
  t190 character(100),
  t191 character(100),
  t192 character(100),
  t193 character(100),
  t194 character(100),
  t195 character(100),
  t196 character(100),
  t197 character(100),
  t198 character(100),
  t199 character(100),
  t200 character(100)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE ocr_table
  OWNER TO accordance;

CREATE TABLE respice_table
(
  recipe character(50),
  id character(25),
  name character(25),
  def_value character(25),
  max_value character(25),
  min_value character(25)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE respice_table
  OWNER TO accordance;

CREATE TABLE Datatable
(
  MachineID character(50),
  IP character(50),
  RecipeName character(50),
  ProgramID character(50),
  Values1 character(50),
  UpdateTime character(50),
  Order1 integer,
  InsertTime character(50),
  FinishTime character(50)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE Datatable
  OWNER TO accordance;

CREATE TABLE log_table
(
  "time" character(50),
  MachineID character(50),
  Values_0 character(50),
  Values_1 character(50),
  Values_2 character(50),
  Values_3 character(50),
  Values_4 character(50),
  Values_5 character(50),
  Values_6 character(50),
  Values_7 character(50),
  Values_8 character(50),
  Values_9 character(50),
  Values_10 character(50),
  Values_11 character(50),
  Values_12 character(50),
  Values_13 character(50),
  Values_14 character(50),
  Values_15 character(50),
  Values_16 character(50),
  Values_17 character(50),
  Values_18 character(50),
  Values_19 character(50),
  Values_20 character(50),
  Values_21 character(50),
  Values_22 character(50),
  Values_23 character(50),
  Values_24 character(50),
  Values_25 character(50),
  Values_26 character(50),
  Values_27 character(50),
  Values_28 character(50),
  Values_29 character(50),
  Values_30 character(50),
  Values_31 character(50),
  Values_32 character(50),
  Values_33 character(50),
  Values_34 character(50),
  Values_35 character(50),
  Values_36 character(50),
  Values_37 character(50),
  Values_38 character(50),
  Values_39 character(50),
  Values_40 character(50),
  Values_41 character(50),
  Values_42 character(50),
  Values_43 character(50),
  Values_44 character(50),
  Values_45 character(50),
  Values_46 character(50),
  Values_47 character(50),
  Values_48 character(50),
  Values_49 character(50),
  Values_50 character(50),
  Values_51 character(50),
  Values_52 character(50),
  Values_53 character(50),
  Values_54 character(50),
  Values_55 character(50),
  Values_56 character(50),
  Values_57 character(50),
  Values_58 character(50),
  Values_59 character(50),
  Values_60 character(50),
  Values_61 character(50),
  Values_62 character(50),
  Values_63 character(50),
  Values_64 character(50),
  Values_65 character(50),
  Values_66 character(50),
  Values_67 character(50),
  Values_68 character(50),
  Values_69 character(50),
  Values_70 character(50),
  Values_71 character(50),
  Values_72 character(50),
  Values_73 character(50),
  Values_74 character(50),
  Values_75 character(50),
  Values_76 character(50),
  Values_77 character(50),
  Values_78 character(50),
  Values_79 character(50),
  Values_80 character(50),
  Values_81 character(50),
  Values_82 character(50),
  Values_83 character(50),
  Values_84 character(50),
  Values_85 character(50),
  Values_86 character(50),
  Values_87 character(50),
  Values_88 character(50),
  Values_89 character(50),
  Values_90 character(50),
  Values_91 character(50),
  Values_92 character(50),
  Values_93 character(50),
  Values_94 character(50),
  Values_95 character(50),
  Values_96 character(50),
  Values_97 character(50),
  Values_98 character(50),
  Values_99 character(50),
  Values_100 character(50),
  Values_101 character(50),
  Values_102 character(50),
  Values_103 character(50),
  Values_104 character(50),
  Values_105 character(50),
  Values_106 character(50),
  Values_107 character(50),
  Values_108 character(50),
  Values_109 character(50),
  Values_110 character(50),
  Values_111 character(50),
  Values_112 character(50),
  Values_113 character(50),
  Values_114 character(50),
  Values_115 character(50),
  Values_116 character(50),
  Values_117 character(50),
  Values_118 character(50),
  Values_119 character(50),
  Values_120 character(50),
  Values_121 character(50),
  Values_122 character(50),
  Values_123 character(50),
  Values_124 character(50),
  Values_125 character(50),
  Values_126 character(50),
  Values_127 character(50),
  Values_128 character(50),
  Values_129 character(50),
  Values_130 character(50),
  Values_131 character(50),
  Values_132 character(50),
  Values_133 character(50),
  Values_134 character(50),
  Values_135 character(50),
  Values_136 character(50),
  Values_137 character(50),
  Values_138 character(50),
  Values_139 character(50),
  Values_140 character(50),
  Values_141 character(50),
  Values_142 character(50),
  Values_143 character(50),
  Values_144 character(50),
  Values_145 character(50),
  Values_146 character(50),
  Values_147 character(50),
  Values_148 character(50),
  Values_149 character(50),
  Values_150 character(50),
  Values_151 character(50),
  Values_152 character(50),
  Values_153 character(50),
  Values_154 character(50),
  Values_155 character(50),
  Values_156 character(50),
  Values_157 character(50),
  Values_158 character(50),
  Values_159 character(50),
  Values_160 character(50),
  Values_161 character(50),
  Values_162 character(50),
  Values_163 character(50),
  Values_164 character(50),
  Values_165 character(50),
  Values_166 character(50),
  Values_167 character(50),
  Values_168 character(50),
  Values_169 character(50),
  Values_170 character(50),
  Values_171 character(50),
  Values_172 character(50),
  Values_173 character(50),
  Values_174 character(50),
  Values_175 character(50),
  Values_176 character(50),
  Values_177 character(50),
  Values_178 character(50),
  Values_179 character(50),
  Values_180 character(50),
  Values_181 character(50),
  Values_182 character(50),
  Values_183 character(50),
  Values_184 character(50),
  Values_185 character(50),
  Values_186 character(50),
  Values_187 character(50),
  Values_188 character(50),
  Values_189 character(50),
  Values_190 character(50),
  Values_191 character(50),
  Values_192 character(50),
  Values_193 character(50),
  Values_194 character(50),
  Values_195 character(50),
  Values_196 character(50),
  Values_197 character(50),
  Values_198 character(50),
  Values_199 character(50),
  Values_200 character(50),
	"Job No" character(50) ,
	"Pressure Control_Setpoint" character(50) ,
	"Pressure Control_Actual" character(50) ,
	"CF4_SETPT" character(50) ,
	"CF4_ACTUAL" character(50) ,
	"O2_SETPT" character(50) ,
	"O2_ACTUAL" character(50) ,
	"AR_SETPT" character(50) ,
	"AR_ACTUAL" character(50) ,
	"N2_SETPT" character(50) ,
	"N2_ACTUAL" character(50) ,
	"OTH_SETPT" character(50) ,
	"OTH_ACTUAL" character(50) ,
	"TOTAL:_SETPT" character(50) ,
	"TOTAL:_ACTUAL" character(50) ,
	"RF Generator_Setpoint" character(50) ,
	"RF Generator_ACTUAL" character(50) ,
	"Tru-Temp_SETPT" character(50) ,
	"Tru-Temp_ACTUAL" character(50) ,
	"ADWLW_SETPT" character(50) ,
	"ADWLW_ACTUAL" character(50) ,
	"N2_FLOW_OK" character(50) ,
	"DOOR_CLOSED" character(50) ,
	"DRY_PUMP_ON" character(50) ,
	"OK_TO_START" character(50) ,
	"VACUUM" character(50) ,
	"COOLING" character(50) ,
	"PURGE" character(50) ,
	"VAC_BREAK" character(50) ,
	"AIR_ACTUAL" character(50) ,
	"TOTAL_FLOW_ACTUAL" character(50) ,
	"PROCESS_TIME" character(50) ,
	"SEGMENT_No" character(50) ,
	"RF_TIME" character(50) ,
	"POWER_ACTUAL" character(50) ,
	"PRESSUER_ACTUAL" character(50) ,
	"BLOWERSPEED_ACTUAL" character(50) ,
	"TEMPERATURE_ACTUAL" character(50) ,
	"AUTO_CYCLES" character(50) ,
	"TIME_TO_EOP" character(50) ,
	"LOT_NUMBER" character(50) ,
	"RECIPE_NAME" character(50) ,
	"PANEL_SIZE" character(50) ,
	"THICKNESS" character(50) ,
	"No_OF_PANELS" character(50) ,
	"NOTE_TO_LOG" character(50) 
)
WITH (
  OIDS=FALSE
);
ALTER TABLE log_table
  OWNER TO accordance;

CREATE TABLE Machine_State
(
  kvm_ip character(50),
  starttime character(25),
  sstatus character(25),
  MachineID character(50),
  State character(10),
  UpdateTime character(50),
  Group1 character(10),
  IP character(20),
  Reason character(50),
  message character(255)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE Machine_State
  OWNER TO accordance;

CREATE TABLE RecipeList
(
  MachineID character(50),
  RecipeName character(50),
  Order1 integer
)
WITH (
  OIDS=FALSE
);
ALTER TABLE RecipeList
  OWNER TO accordance;

CREATE TABLE ma_state_log
(
  machineid character(50),
  lasttime character(50),
  message character(250)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE ma_state_log
  OWNER TO accordance;

CREATE TABLE alarm_spt_m
(
  mc_vender character(50),
  mc_model character(50),
  mc_ver character(50),
  alarm_id character(50),
  alarm_name character(250),
  spt_file character(250),
  spt_sece_ini character(250),
  temp_file character(250)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE alarm_spt_m
  OWNER TO accordance;

CREATE TABLE kvm_security_table
(
  kvm_id character(16),
  kvm_ip character(32),
  kvm_port integer,
  tickey_1 character(512)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE  kvm_security_table
  OWNER TO accordance;

CREATE TABLE kvm_parameter_table
(
  kvm_ip character(32),
  kvm_port integer,
  kvm_parameter_name character(16),
  kvm_parameter_value character(512)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE  kvm_parameter_table
  OWNER TO accordance;


CREATE TABLE kvm_list_test
(
	kvm_name character(32),
	kvm_ip character(32)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE  kvm_list_test
  OWNER TO accordance;
