<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_kvm_group.php" method="post">  
		<table cellpadding="1" border="1">
			<tr>
				<td><?php echo _('Fab\'s');?></td>
				<td><?php echo _('Dept');?></td>
				<td><?php echo _('Section');?></td>
				<td><?php echo _('Local');?></td>
				<td><?php echo _('Process Group');?></td>
				<td><?php echo _('Vender');?></td>
				<td><?php echo _('Model');?></td>
				<td><?php echo _('Tool Name');?></td>
				<td><?php echo _('SVM');?></td>
				<td><?php echo _('IP Address');?></td>
				<td><?php echo _('KVM port');?></td>
				<td><?php echo _('KVM mode');?></td>
				<td><?php echo _('TX adder');?></td>
				<td><?php echo _('single mouse');?></td>
				<td><?php echo _('KVM group (SMT)');?></td>
				<td><?php echo _('Edit');?></td>
				<td><?php echo _('Advanced');?></td>
				<td><?php echo _('Delete');?></td>
				<td><?php echo _('Real-time image file');?></td>
				<td><?php echo _('Clear image');?></td>
			</tr>
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$sql = "select * from kvm_table where kvm_mc_group='only' or kvm_mc_group = '' or kvm_mc_group is null order by kvm_mc_group asc, kvm_ip asc ";
	$result = pg_exec($testDb,$sql );
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$kvm_ip = trim($info[1]);
		$kvm_port = trim($info[2]);

		$kvm_id = trim($info[0]);
		$kvm_pwd = trim($info[3]);
		$tx_ip = trim($info[13]);
		$kvm_model = trim($info[4]);
		
		$mc_fab = trim($info[16]);
		$mc_dept = trim($info[17]);
		$mc_sect = trim($info[18]);
		$mc_gp = trim($info[19]);
		$mc_vender = trim($info[20]);
		$kvm_sm = trim($info[15]);
		$KVM_gp = trim($info[21]);

		$mc_local = trim($info[6]);
		$mc_model = trim($info[22]);
		$mc_name = trim($info[5]);
		$svm = trim($info[8]);
		$svm_path = trim($info[9]);
		
		switch ($kvm_model)
		{
		case "0":
		  $kvm_model = "SpiderDuo";
		  break;  
		case "1":
		  $kvm_model = "Adder";
		  break;
		case "2":
		  $kvm_model = "Infinity";
		  break;
		case "3":
		  $kvm_model = "CAT5016IP";
		  break;
		case "4":
		  $kvm_model = "CAT4024IP";
		  break;
		case "5":
		  $kvm_model = "SpiderOther";
		  break;
		case "6":
		  $kvm_model = "EXT_APP";
		  break;
		case "7":
		  $kvm_model = "IHSE_KVM";
		  break;
		case "8":
		  $kvm_model = "WEB_CGI";
		  break;
		case "9":
		  $kvm_model = "RTSP_CGI";
		  break;
		
		}
		//$kvm_file = trim($info[1]);
		echo "<tr><td>$mc_fab</td><td>$mc_dept</td><td>$mc_sect</td><td>$mc_local</td><td>$mc_gp</td><td>$mc_vender</td><td>$mc_model</td><td>$mc_name</td><td>$svm</td>";
		echo "<td>$kvm_ip</td><td>$kvm_port</td><td>$kvm_model</td><td>$tx_ip</td><td>$kvm_sm</td><td>$KVM_gp</td>";
		//if( strcmp( $user, "admin") )
		{
			echo "<td><a href=\"kvm_list_add.php?delid=$kvm_ip&delide=$kvm_port\" >edit</a></td>";
			echo "<td><a href=\"kvm_list_adv_add.php?delid=$kvm_ip&delide=$kvm_port\" >edit</a></td>";
			echo "<td><a href=\"set_del_kvm.php?delid=$kvm_ip&delide=$kvm_port\" >delete</a></td>";
		}
		
		$sql = "select * from tx_table where kvm_ip='".$kvm_ip."p".$kvm_port."' ";
		//echo $sql;
		$result1 = pg_exec($testDb,$sql );
		$numrows1 = pg_num_rows($result1);
		if($numrows1 > 0)
		{
			$info1=pg_fetch_array($result1);
			$file_id = trim($info1[1]);
			echo "<td>$file_id</td><td><a href=\"set_del_kvmc.php?delid=$kvm_ip&delide=$kvm_port\" >delete</a></td>";
		}
		else
		{
			echo "<td></td><td></td>";
		}
		echo "</tr>";
	}
	$KVM_gp_old = $KVM_gp;	
	
	$sql = "select * from kvm_table where kvm_mc_group!='only' and kvm_mc_group != '' and kvm_mc_group is not null  order by kvm_mc_group asc, kvm_ip asc ";
	$result = pg_exec($testDb,$sql );
	$numrows = pg_num_rows($result);
	
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$kvm_ip = trim($info[1]);
		$kvm_port = trim($info[2]);

		$kvm_id = trim($info[0]);
		$kvm_pwd = trim($info[3]);
		$tx_ip = trim($info[13]);
		$kvm_model = trim($info[4]);
		
		$mc_fab = trim($info[16]);
		$mc_dept = trim($info[17]);
		$mc_sect = trim($info[18]);
		$mc_gp = trim($info[19]);
		$mc_vender = trim($info[20]);
		$kvm_sm = trim($info[15]);
		$KVM_gp = trim($info[21]);

		$kvm_local = trim($info[6]);
		$mc_model = trim($info[22]);
		$mc_name = trim($info[5]);
		$svm = trim($info[8]);
		$svm_path = trim($info[9]);
		
		switch ($kvm_model)
		{
		case "0":
		  $kvm_model = "SpiderDuo";
		  break;  
		case "1":
		  $kvm_model = "Adder";
		  break;
		case "2":
		  $kvm_model = "Infinity";
		  break;
		case "3":
		  $kvm_model = "CAT5016IP";
		  break;
		case "4":
		  $kvm_model = "CAT4024IP";
		  break;
		case "5":
		  $kvm_model = "SpiderOther";
		  break;
		case "6":
		  $kvm_model = "EXT_APP";
		  break;
		case "7":
		  $kvm_model = "IHSE_KVM";
		  break;
		case "8":
		  $kvm_model = "WEB_CGI";
		  break;
		case "9":
		  $kvm_model = "RTSP_CGI";
		  break;
		
		}
		if ($KVM_gp_old != $KVM_gp)
		{
			echo "<tr><td colspan='19' style='height:10px'></td></tr>";
			
			$sql = "select * from kvm_table where kvm_mc_group='$KVM_gp' ";
			$resultt = pg_exec($testDb,$sql );
			$numrowst = pg_num_rows($resultt);
			echo "<tr><td rowspan=$numrowst>$mc_fab</td><td rowspan=$numrowst>$mc_dept</td><td rowspan=$numrowst>$mc_sect</td><td rowspan=$numrowst>$kvm_local</td><td rowspan=$numrowst>$mc_gp</td><td rowspan=$numrowst>$mc_vender</td><td rowspan=$numrowst>$mc_model</td>";
			echo "<td>$mc_name</td><td>$svm</td>";
			echo "<td>$kvm_ip</td><td>$kvm_port</td><td>$kvm_model</td><td>$tx_ip</td><td>$kvm_sm</td><td rowspan=$numrowst>$KVM_gp</td>";
		}
		else
		{
			echo "<tr><td>$mc_name</td><td>$svm</td>";
			echo "<td>$kvm_ip</td><td>$kvm_port</td><td>$kvm_model</td><td>$tx_ip</td><td>$kvm_sm</td>";
		}
		//$kvm_file = trim($info[1]);
		//if( strcmp( $user, "admin") )
		if ($KVM_gp_old != $KVM_gp)
		{
			echo "<td rowspan=$numrowst><a href=\"kvm_list_add_two.php?delid=$kvm_ip&delide=$kvm_port&kvm_gp=$KVM_gp\" >edit</a></td>";
			echo "<td rowspan=$numrowst><a href=\"kvm_list_adv_add_two.php?delid=$kvm_ip&delide=$kvm_port&kvm_gp=$KVM_gp\" >edit</a></td>";
			echo "<td rowspan=$numrowst><a href=\"set_del_kvm_two.php?delid=$kvm_ip&delide=$kvm_port&kvm_gp=$KVM_gp\" >delete</a></td>";
		}
		$KVM_gp_old = $KVM_gp;	
		
		$sql = "select * from tx_table where kvm_ip='".$kvm_ip."p".$kvm_port."' ";
		//echo $sql;
		$result1 = pg_exec($testDb,$sql );
		$numrows1 = pg_num_rows($result1);
		if($numrows1 > 0)
		{
			$info1=pg_fetch_array($result1);
			$file_id = trim($info1[1]);
			echo "<td>$file_id</td><td><a href=\"set_del_kvmc.php?delid=$kvm_ip&delide=$kvm_port\" >delete</a></td>";
		}
		else
		{
			echo "<td></td><td></td>";
		}
		
		echo "</tr>";
	}
	pg_close($testDb); 
	//echo "<frame name=\"main\" src=\"page16_a.php?web_ip=$web_ip&web_port=$web_port&web_path=$web_path&page_w=$web_w&page_h=$web_h\" scrolling=\"auto\" target=\"_self\">"; 
}
?> 
		</table> 
		<br>
		    <?php 
					include_once("web_conf.php");
					$testDb=pg_connect($DBase_INI);
					
					$sql = "select * from kvm_table where kvm_mc_group='only' order by kvm_mc_group asc, kvm_ip asc";
					$result = pg_exec($testDb, $sql);
					$numrows = pg_num_rows($result);
					for($i=0;$i<$numrows;$i++)
					{
						$info=pg_fetch_array($result);
						$kvm_ip = trim($info[1]);
						$kvm_port = trim($info[2]);
						$mc_name = trim($info[5]);
						$KVM_gp = trim($info[21]);
						echo "<input type= checkbox value=$kvm_ip name=kvm[]>$kvm_ip - $mc_name - $KVM_gp<br>";
					}
					
					$sql = "select * from kvm_table where kvm_mc_group!='only' order by kvm_mc_group asc, kvm_ip asc";
					$result = pg_exec($testDb, $sql);
					$numrows = pg_num_rows($result);
					for($i=0;$i<$numrows;$i++)
					{
						$info=pg_fetch_array($result);
						$kvm_ip = trim($info[1]);
						$kvm_port = trim($info[2]);
						$mc_name = trim($info[5]);
						$KVM_gp = trim($info[21]);
						echo "<input type= checkbox value=$kvm_ip name=kvm[]>$kvm_ip - $mc_name - $KVM_gp<br>";
					}
				?>
		<br>
	<table><tr><td><?php echo _('kvm group (SMT)');?></td><td><input type="text" id="kvm_gp" name="kvm_gp" ></td></tr></table>
		<br>
		<br>
		<input type="submit" value="<?php echo _('Submit');?>">
	
	</form>
  </body>
</html>
