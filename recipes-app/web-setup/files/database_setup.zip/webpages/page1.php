<HTML>
<HEAD>
</HEAD>
<?php
include_once("web_conf.php");
    session_start();
    $user_id = $_SESSION['user_id'];
?>
<script>
    window.onload = function() {
      setInterval(get_image, <?php echo "$img_reflash" ?>);
    };

    window.onerror = function() {
      setInterval(get_image, <?php echo "$img_reflash" ?>);
    };
   
    function get_image() {
<?php
//include_once("web_conf.php");
	$KVMIP =$_GET['kvm_ip'];
	$webIP =$_GET['web_ip'];
	$webPort =$_GET['web_port'];
	$webPath =$_GET['web_path'];
	$pageW =$_GET['page_w'];
	$pageH =$_GET['page_h'];
	
	echo "var image_url0 = 'http://$webIP:$webPort/downloadfile.php?ip=$KVMIP&path=$webPath';\n";
  echo "var playback_image0 = document.getElementById('myimage0');\n";
  echo "playback_image0.src = image_url0 + '&' + Math.random();\n";
  echo "playback_image0.width = '$pageW';\n";
  echo "playback_image0.height = '$pageH';\n";
?>
    }
</script>
<body>
	<table>
		<tr>
<?php

	//echo "<td><table><tr><td>$filetest</td></tr><tr><td><img src='http://$webIP:$webPort/$KVMIP/screenshot.jpg' id=myimage$i  width=$pageW height=$pageH>";
	echo "<td><table><tr><td>$filetest</td></tr><tr><td><img src='http://$webIP:$webPort/downloadfile.php?ip=$KVMIP&path=$webPath' id=myimage$i  width=$pageW height=$pageH>";

	$kvm_ip = explode("p",$KVMIP);
	echo "<td><div><img id=myimage0></div></a></td>";
?>
		</tr>
	</table>
</body>
