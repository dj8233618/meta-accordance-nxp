<?php
include_once("web_conf.php");
$delid = $_GET['delid'];
$delide = $_GET['delide'];
include_once("languages/languages.php"); //�ޤJ�y���]�w���
//require_once('syslog.php');
//$delid = $_GET['delid'];
//$delide = $_GET['delide'];
		$rcvm_ip = "";
		$rcvm_port = "80";
		$rcvm_local = "local";
		$rcvm_name = "svm";
		$rcvm_path = "C:/inetpub/wwwroot/";
		$rcvm_id = "admin";
		$rcvm_pwd = "000000";
		$rcvm_power = "0";
		$rcvm_mac = "0";
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from rcvm_table where rcvm_ip='$delid' and rcvm_port='$delide'");
//echo  "select * from rcvm_table where rcvm_ip='$delid' and rcvm_port='$delide'---";
	if ($result) 
	{
//echo "===";
		$numrows = pg_num_rows($result);
		for ($i = 0; $i < $numrows; $i++) 
		{
			$info=pg_fetch_array($result);
			$rcvm_ip = trim($info[1]);
			$rcvm_port = trim($info[2]);
			$rcvm_name = trim($info[5]);
			$rcvm_local = trim($info[6]);
			$rcvm_path = trim($info[8]);
			$rcvm_id = trim($info[0]);
			$rcvm_pwd = trim($info[3]);
			$rcvm_power = trim($info[4]);
			$rcvm_mac = trim($info[7]);
		}
	}
	pg_close($testDb); 
}
?>	
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
  <form action="svm_new.php" method="post">
      <table >
      	<tr>
      		<td> <?php echo _('svm_name');?> </td>
      		<td> <input type="text" name=rcvm_name value="<?php echo $rcvm_name ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('svm_local');?> </td>
      		<td> <input type="text" name=rcvm_local value="<?php echo $rcvm_local ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('svm_ip');?> </td>
      		<td> <input type="text" name=rcvm_ip value="<?php echo $rcvm_ip ?>" > </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('svm_port');?> </td>
      		<td> <input type="text" name=rcvm_port value="<?php echo $rcvm_port ?>" > </td>
      	</tr>
       	<tr>
      		<td> <?php echo _('svm_id');?> </td>
      		<td> <input type="text" name=rcvm_id value="<?php echo $rcvm_id ?>" > </td>
      	</tr>
     	<tr>
      		<td> <?php echo _('svm_pwd');?> </td>
      		<td> <input type="text" name=rcvm_pwd value="<?php echo $rcvm_pwd ?>" > </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('svm_power');?> </td>
      		<td> <input type="text" name=rcvm_power value="<?php echo $rcvm_power ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('svm_mac');?> </td>
      		<td> <input type="text" name=rcvm_mac value="<?php echo $rcvm_mac ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('svm_path');?></td>
      		<td> <input type="text" name=rcvm_path value="<?php echo $rcvm_path ?>" > </td>
      	</tr>
        <tr>
      		<td> <input type="submit" value="<?php echo _('Submit');?>" > </td>
      	</tr> 	
      </table>
  </form>
  </body>
</html>
