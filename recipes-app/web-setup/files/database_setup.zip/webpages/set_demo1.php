<?php
include_once("web_conf.php");
//require_once('syslog.php');
$machineid = $_POST['machineid'];
$kvm_ip = $_POST['kvm_ip'];
$recipe = $_POST['recipe'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$today = Date("H:i:s");
	
	$sql="insert into datatable (machineid,ip,recipename,programid,values1,order1,inserttime) values ('".$machineid."','".$kvm_ip."','".$recipe."','1','".$recipe."',1,'".$today."')"; 
	$result = pg_exec($testDb, $sql);
	
	//echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	$sql1="insert into datatable (machineid,ip,recipename,programid,values1,order1,inserttime) values ('".$machineid."','".$kvm_ip."','".$recipe."','1','none',2,'".$today."')"; 
	//echo $sql1;
	$result = pg_exec($testDb, $sql1);
	pg_close($testDb); 
}

?>