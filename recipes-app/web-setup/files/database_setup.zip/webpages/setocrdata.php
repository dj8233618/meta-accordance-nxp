<?php
	//$myMode =$_GET['mode'];
	$myIP =$_GET['ip'];
	$mytable =$_GET['table'];
	$myvalue =$_GET['value'];
	//-------------------------------------------------------------------- 
	//filename:class.php 
	//summary: access�ƾڮw�ާ@�� 
	//   �ϥνd�ҡG 
	//include_once("odbC.php"); 
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	//if($mytable == '1')
	
	$imgfile = $access->ocr_getinfo_one($ocr_table,$mytable,$myvalue);
	if(!$imgfile )
	{
		echo "insert";
		$access->ocr_insert($ocr_table,$mytable,$myvalue,$myIP);
//include_once("web_conf.php");
$testDb=pg_connect("host=localhost port=5432 dbname=svm user=accordance password=1qaz2wsx"); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$today = Date("Y/m/d H:i:s");
	
			$sql="update machine_State set starttime='".$today."' , sstatus='10' where kvm_ip='".$myIP."'";
	//$sql = "updata ma_state_log set ( machineid, lasttime, message) VALUES ('".$myIP."','".$today."' ,'10');";
	//echo $sql;
	$result = pg_exec($testDb, $sql);
	$sql = "INSERT INTO ma_state_log ( machineid, lasttime, message) VALUES ('".$myIP."','".$today."' ,'10');";
	//echo $sql;
	$result = pg_exec($testDb, $sql);
	pg_close($testDb); 
}
	}
	//else
	//{
	//	echo "updata";
	//	$access->updateinfo($table,$field,$myIP,$set,$myFile);
	//}
	$access->close();
	
?>