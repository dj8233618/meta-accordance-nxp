<?php
	//$myMode =$_GET['mode'];
	$myIP =$_GET['ip'];
	$myvalue =$_GET['io'];
	
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	//if($mytable == '1')
	
	$imgfile = $access->getmachine_one($machine_s,$field,$myIP);
	if(!$imgfile )
	{
		//echo "insert";
		$access->machine_insert($machine_s,$myIP,$myvalue);
	}
	else
	{
		echo "updata";
		$field2 = "sstatus" ;
		$imgfile = $access->getmachine_two($machine_s,$field,$myIP, $field2,$myvalue);
		if(!$imgfile )
		{
			$access->updateinfo_machine($machine_s,$myIP,$myvalue);
			
			//include_once("web_conf.php");
			$testDb=pg_connect("host=localhost port=5432 dbname=svm user=accordance password=1qaz2wsx"); 
			if($testDb == FALSE)
			{
				echo "connect errorww";
			}
			else
			{
				$today = Date("Y/m/d H:i:s");
				
				$sql = "INSERT INTO ma_state_log ( machineid, lasttime, message) VALUES ('".$myIP."','".$today."' ,'".$myvalue."');";
				//echo $sql;
				$result = pg_exec($testDb, $sql);
				pg_close($testDb); 
			}
		}
	}
	$access->close();
?>