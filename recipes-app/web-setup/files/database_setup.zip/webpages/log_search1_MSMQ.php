<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
session_start();
$FacList = $_SESSION['FacList'];
$ConList = $_SESSION['ConList'];
$FacChoose = $_SESSION['FacChoose'];

$factory = $_POST['factory'];
$user = $_POST['user'];
$start_date = $_POST['start_date'];
$start_date = $start_date.(" 00:00:00");
$end_date = $_POST['end_date'];
$end_date = $end_date.(" 23:59:59");
$userIP = $_POST['userIP'];
?>
<html>
<head>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">

<?php 
include_once("web_conf.php");

echo (_('Factory:').$factory);
echo ("<br>");
echo (_('KVM').$user);
echo ("<br>");
echo (_('Start:').$start_date);
echo ("<br>");
echo (_('End:').$end_date);
echo ("<br>");
echo (_('alarm ID:').$userIP);
echo ("<br>");
echo ("<br>");
?>
</head>
<body> 
<?php echo _('Please choose Alarm active');?>
<form name="input" action="log_search2_MSMQ.php" method="post">
		<select id="ControlIP" name="ControlIP" onchange="">
			<option value ="All"> All </option>
            <?php 
                $count = 0;
                $record = array();
                while($count<count($ConList))
                {
                    $count++;
                    if ($count!= $FacChoose[0] && $FacChoose[0] > 0)
                        continue;
                    $j = $count-1;
                    $DBase_INI = "host= $ConList[$j] port=5432 dbname=svm user=accordance password=1qaz2wsx";
                    $sql = "select * from alarm_spt_log orderm by alarm_active";
                    //if($user != "All" && $userIP =="All")
                    //    $sql = "select view_ip from rx_u_log where user_id = '$user'";
                    //if($user == "All" && $userIP !="All")
                    //    $sql = "select view_ip from rx_u_log where rx_ip = '$userIP'";
                    //if($user != "All" && $userIP != "All")
                    //    $sql = "select view_ip from rx_u_log where user_id = '$user' and rx_ip = '$userIP'";
                    $testDb=pg_connect($DBase_INI);
                    $resultCustomized=pg_exec($testDb,$sql);
                    $arrCustomized = pg_fetch_all($resultCustomized);
                    $length= sizeof($arrCustomized);
                
                    $view_ip = array();
                    for($i=0 ; $i<$length ; $i++)
                    {
                        $view_ip[$arrCustomized[$i]["alarm_active"]]= $arrCustomized[$i]["alarm_active"];
                    }
                
                    $view_ipKey = array_keys($view_ip);
                    sort($view_ip);
                    $view_ipSize = sizeof($view_ipKey);
                    for($j=0 ; $j<$view_ipSize ; $j++)
                    {              
                        if(trim($view_ipKey[$j])=="login")
                            $view_ipKey[$j] = $userIP;
                        if(trim($view_ipKey[$j])=="logout")
                            $view_ipKey[$j] = $userIP;
                        if(strpos($view_ipKey[$j],"p")!=false)
                            $view_ipKey[$j] = substr($view_ipKey[$j], 0 ,stripos($view_ipKey[$j],"p"));
                        if(strpos($view_ipKey[$j],"-")!=false)
                            $view_ipKey[$j] = substr($view_ipKey[$j], 0 ,stripos($view_ipKey[$j],"-"));
                                        
                                        
                        if(!in_array(trim($view_ipKey[$j]), $record) && trim($view_ipKey[$j]) !="")
                        {
                            if($view_ipKey[$j]=="All")
                                continue;
                                array_push($record,trim($view_ipKey[$j]));
                            echo "<option value ='$view_ipKey[$j]'>$view_ipKey[$j]</option>";
                        }
                    }
                }
            ?>
		</select>
<input type="submit" value="OK">
</form>
        <?php 
        echo ("<a href=\"log_search_MSMQ_factory.php\">")?> <?php echo _('Reset');?> <?php echo "</a>";?>
        <table border=1 cellpadding=4>
        <tr><td><?php echo _('Tool Name');?></td><td><?php echo _('RCM IP');?></td><td><?php echo _('RCM channel');?></td><td><?php echo _('alarm active');?></td><td><?php echo _('alarm id');?></td><td><?php echo _('alarm time');?></td><td><?php echo _('spt file');?></td><td><?php echo _('user');?></td><td><?php echo _('Factory');?></td></tr>
        <?php 
        $count = 0;
        while($count<count($ConList))
            {
                $count++;
                if ($count!= $FacChoose[0] && $FacChoose[0] > 0)
                    continue;
                
                $j = $count-1;
                $DBase_INI = "host= $ConList[$j] port=5432 dbname=svm user=accordance password=1qaz2wsx";
                $testDb=pg_connect($DBase_INI); 
            
                if($testDb == FALSE)
                {
            	    echo "connect error";
                }
                else
                {
                    $sql = "select * from alarm_spt_log where (to_timestamp(alarm_time,'yyyy/MM/dd hh24:mi:ss')) between (to_timestamp('$start_date','yyyy/MM/dd hh24:mi:ss')) and (to_timestamp('$end_date','yyyy/MM/dd hh24:mi:ss'))";
                    
                    if($user == "All" && $userIP == "All")
                        $sql = $sql;
                    if($user != "All" && $userIP == "All")
                        $sql = $sql." and kvm_name = '$user'";
                    if($user == "All" && $userIP != "All")
                        $sql = $sql." and alarm_id = '$userIP'";
                    if($user != "All" && $userIP != "All")
                        $sql = $sql." and kvm_name = '$user' and alarm_id = '$userIP'";
                    //echo "$sql";   
                    $result = pg_exec($testDb, $sql);
                
                /*    $result = pg_exec($testDb, "select rx_u_log.*, kvm_table.kvm_name,rcvm_table.rcvm_name "
                        + "from rx_u_log "
                        + "left join rcvm_table "
                        + "on rx_u_log.rx_ip = rcvm_table.rcvm_ip "
                        + "left join kvm_table "
                        + "on rx_u_log.rx_ip = kvm_table.kvm_ip "
                        + "where (to_timestamp(changtime,'yyyy/MM/dd hh24:mi:ss')) "
                        + "between (to_timestamp('$start_date','yyyy/MM/dd hh24:mi:ss')) "
                        + "and (to_timestamp('$end_date','yyyy/MM/dd hh24:mi:ss')) ")
                        + "and user_id ='$user'";
                */
                    
                    $numrows = pg_num_rows($result);
                    $skip = false;
        
                    for($i=0;$i<$numrows;$i++)
                    {
                        $info=pg_fetch_array($result);
                        if ($skip == true)
                        {
                            $skip = false;
                            continue;
                        }
                        $test0= trim($info[0]);
                        $test1= trim($info[3]);
                        $test2= trim($info[4]);
                        $test3= trim($info[5]);
                        $test4= trim($info[6]);
                        $test5= trim($info[7]);
                        $test6= trim($info[8]);
                        $test7= trim($info[9]);
                        $count_2 = $count-1;
                        echo "<tr><td>$test0</td><td>$test1</td><td>$test2</td><td>$test3</td><td>$test4</td><td>$test5</td><td>$test6</td><td>$test7</td><td>$FacList[$count_2]</td>";
                        echo "</tr>";
                    }
                    pg_close($testDb);
                }
            }
            echo "</table>";
        ?>
        
        <?php 
        session_start();
            $_SESSION['factory'] = $factory;
            $_SESSION['user'] = $user;
            $_SESSION['start_date'] = $start_date;
            $_SESSION['end_date'] = $end_date;
            $_SESSION['userIP'] = $userIP;
        ?>
</body>
</html>
















