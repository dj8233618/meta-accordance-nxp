<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<meta charset="utf-8">
<body>
<?php echo _('Manage Surface');?><!-- �޲z���� -->
<br>
<a href="kvm_extern_list.php" target="main" ><?php echo _('KVM Ext Setting ');?></a><br> <!-- kvm �N�޳]�w -->
<br>
<br>
<a href="Alarm_spt_list.php" target="main" ><?php echo _('Substitute script list');?></a><br> <!-- �N�޸}�� �C�� -->
<br>
<a href="Alarm_spt_list_add.php" target="main" ><?php echo _('[Warning|Action] corresponds to the proxy script');?></a><br> <!-- [ĵ�i|�ʧ@]���� �N�޸}�� -->
<br>
<br>
<a href="log_search_MSMQ_factory.php" target="main" ><?php echo _('Log Searching');?></a><br> <!-- log�d�� -->
<br>
<!-- <a href="group_mg.php" target="main" >�s�W�޲z</a><br> -->
<!-- �s�զC�� -->
<a href="demo_1.php" target="main" >Demo 1</a><br>
<a href="demo_2.php" target="main" >Demo 2</a><br>
<br>
</body>
</html>