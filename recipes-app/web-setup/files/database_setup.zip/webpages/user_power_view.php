<html>
<head>
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="user_power_delete.php" method="post">  
		<select id="user" name="user">
			<option value="op1">op1</option>
			<option value="op2">op2</option>
			<option value="op3">op3</option>
		</select>
		<br>

		<br>
		<input type="submit" value="check">
	</form>
  </body>
</html>