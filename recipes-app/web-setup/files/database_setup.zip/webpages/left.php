<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<?php echo _('KVM management');?><br>
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user_id = $_GET['user_id'];
//$password = $_POST['pw'];
session_start();
$user_id = $_SESSION['user_id'];
$testDb=pg_connect($DBase_INI);
echo "$user_id<br>"; 
//echo "---";
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from web_set ");
	$numrows = pg_num_rows($result);
	if( $numrows )
	{
		//echo "SUCCESS!!";
		$info=pg_fetch_array($result);
		$webIP1 = trim($info[1]);
		$webPort1 = trim($info[2]);
		$webPath1 = trim($info[3]);
		$web_16w = trim($info[4]);
		$web_16h = trim($info[5]);
		$web_w = trim($info[6]);
		$web_h = trim($info[7]);
	}
	//pg_close($testDb); 
	echo "<a target=\"main\" href=\"page16.php?web_ip=$webIP1&web_port=$webPort1&web_path=$webPath1&page_w=$web_16w&page_h=$web_16h\" >show all kvm</a><br>"; 
	
	$result2 = pg_exec($testDb, "select * from user_index where user_id ='$user_id' order by kvm_ip asc ");
    $numrows2 = pg_num_rows($result2);
	for ($i = 0; $i < $numrows2; $i++) 
	{
		$info2=pg_fetch_array($result2);
		$fileip = trim($info2[6]);
		
		$result1 = pg_exec($testDb, "select * from kvm_table where kvm_ip = '$fileip' ");
    $numrows1 = pg_num_rows($result1);
		if( $numrows1 > 0)
		{
			$info1=pg_fetch_array($result1);
			$file= trim($info1[1]).'p'.trim($info1[2]);
			//$webPath=trim($info1[9]);
			$webIP=trim($info1[8]);
			//$webPort=$info1[10];
//echo "$webIP<br>"; 
			
			$result3 = pg_exec($testDb, "select * from rcvm_table where rcvm_ip = '$webIP' ");
	    $numrows3 = pg_num_rows($result3);
			if( $numrows3> 0)
			{
				$info3=pg_fetch_array($result3);
				$webPath=trim($info3[8]);
				$webPort=$info3[2];
//echo "$webPath<br>==="; 
//echo "$webPort<br>==="; 
			}
		}
		echo "<a target=\"main\" href=\"page1.php?kvm_ip=$file&web_ip=$webIP&web_port=$webPort&web_path=$webPath&page_w=$web_w&page_h=$web_h\" >$file</a><br>"; 
	}
	
	pg_close($testDb); 
	//session_end();
}
?>    

<br><br>
</body>
</html>