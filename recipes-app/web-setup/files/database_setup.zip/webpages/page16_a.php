<?php
session_start();
$user_id = $_SESSION['user_id'];
?>
<HTML>
<HEAD>
</HEAD>
<?php
include_once("web_conf.php");
?>
<script>
    window.onload = function() {
      setInterval(get_image, <?php echo "$img_reflash" ?>);
    };

    window.onerror = function() {
      setInterval(get_image, <?php echo "$img_reflash" ?>);
    };
   
    function get_image() {
<?php
//include_once("web_conf.php");
	//$user_id = $_GET['user_id'];
	$webIP1 =$_GET['web_ip'];
	$webPort1 =$_GET['web_port'];
	$webPath1 =$_GET['web_path'];
	$pageW =$_GET['page_w'];
	$pageH =$_GET['page_h'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result2 = pg_exec($testDb, "select * from user_index where user_id = '$user_id' order by kvm_gp asc, kvm_ip asc ");
    $numrows2 = pg_num_rows($result2);

	for ($i = 0; $i < $numrows2; $i++) 
	{
		$info2=pg_fetch_array($result2);
		$fileip = trim($info2[6]);
		//$fileport = trim($info[7]);
		//$filetest = $file.'p'.$fileport;
		
		$result1 = pg_exec($testDb, "select * from kvm_table where kvm_ip = '$fileip' ");
    $numrows1 = pg_num_rows($result1);
		if( $numrows1 > 0)
		{
			$info1=pg_fetch_array($result1);
			$file= trim($info1[1]).'p'.trim($info1[2]);
			//$webPath=trim($info1[9]);
			$webIP=trim($info1[8]);
			//$webPort=$info1[10];
//echo "$webIP<br>"; 
			
			$result3 = pg_exec($testDb, "select * from rcvm_table where rcvm_ip = '$webIP' ");
	    $numrows3 = pg_num_rows($result3);
			if( $numrows3> 0)
			{
				$info3=pg_fetch_array($result3);
				$webPath=trim($info3[8]);
				$webPort=$info3[2];
//echo "$webPath<br>==="; 
//echo "$webPort<br>==="; 
			}
		}
		
		switch($i)
		{
		case 0:
			echo "var image_url0 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image0 = document.getElementById('myimage0');\n";
	    echo "playback_image0.src = image_url0 + '&' + Math.random();\n";
	    echo "playback_image0.width = '$pageW';\n";
	    echo "playback_image0.height = '$pageH';\n";
	    break;
		case 1:
			echo "var image_url1 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image1 = document.getElementById('myimage1');\n";
	    echo "playback_image1.src = image_url1 + '&' + Math.random();\n";
	    echo "playback_image1.width = '$pageW';\n";
	    echo "playback_image1.height = '$pageH';\n";
	    break;
		case 2:
			echo "var image_url2 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image2 = document.getElementById('myimage2');\n";
	    echo "playback_image2.src = image_url2 + '&' + Math.random();\n";
	    echo "playback_image2.width = '$pageW';\n";
	    echo "playback_image2.height = '$pageH';\n";
	    break;
		case 3:
			echo "var image_url3 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image3 = document.getElementById('myimage3');\n";
	    echo "playback_image3.src = image_url3 + '&' + Math.random();\n";
	    echo "playback_image3.width = '$pageW';\n";
	    echo "playback_image3.height = '$pageH';\n";
	    break;
		case 4:
			echo "var image_url4 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image4 = document.getElementById('myimage4');\n";
	    echo "playback_image4.src = image_url4 + '&' + Math.random();\n";
	    echo "playback_image4.width = '$pageW';\n";
	    echo "playback_image4.height = '$pageH';\n";
	    break;
		case 5:
			echo "var image_url5 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image5 = document.getElementById('myimage5');\n";
	    echo "playback_image5.src = image_url5 + '&' + Math.random();\n";
	    echo "playback_image5.width = '$pageW';\n";
	    echo "playback_image5.height = '$pageH';\n";
	    break;
		case 6:
			echo "var image_url6 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image6 = document.getElementById('myimage6');\n";
	    echo "playback_image6.src = image_url6 + '&' + Math.random();\n";
	    echo "playback_image6.width = '$pageW';\n";
	    echo "playback_image6.height = '$pageH';\n";
	    break;
		case 7:
			echo "var image_url7 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image7 = document.getElementById('myimage7');\n";
	    echo "playback_image7.src = image_url7 + '&' + Math.random();\n";
	    echo "playback_image7.width = '$pageW';\n";
	    echo "playback_image7.height = '$pageH';\n";
	    break;
		case 8:
			echo "var image_url8 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image8 = document.getElementById('myimage8');\n";
	    echo "playback_image8.src = image_url8 + '&' + Math.random();\n";
	    echo "playback_image8.width = '$pageW';\n";
	    echo "playback_image8.height = '$pageH';\n";
	    break;
		case 9:
			echo "var image_url9 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image9 = document.getElementById('myimage9');\n";
	    echo "playback_image9.src = image_url9 + '&' + Math.random();\n";
	    echo "playback_image9.width = '$pageW';\n";
	    echo "playback_image9.height = '$pageH';\n";
	    break;
		case 10:
			echo "var image_url10 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image10 = document.getElementById('myimage10');\n";
	    echo "playback_image10.src = image_url10 + '&' + Math.random();\n";
	    echo "playback_image10.width = '$pageW';\n";
	    echo "playback_image10.height = '$pageH';\n";
	    break;
		case 11:
			echo "var image_url11 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image11 = document.getElementById('myimage11');\n";
	    echo "playback_image11.src = image_url11 + '&' + Math.random();\n";
	    echo "playback_image11.width = '$pageW';\n";
	    echo "playback_image11.height = '$pageH';\n";
	    break;
		case 12:
			echo "var image_url12 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image12 = document.getElementById('myimage12');\n";
	    echo "playback_image12.src = image_url12 + '&' + Math.random();\n";
	    echo "playback_image12.width = '$pageW';\n";
	    echo "playback_image12.height = '$pageH';\n";
	    break;
		case 13:
			echo "var image_url13 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image13 = document.getElementById('myimage13');\n";
	    echo "playback_image13.src = image_url13 + '&' + Math.random();\n";
	    echo "playback_image13.width = '$pageW';\n";
	    echo "playback_image13.height = '$pageH';\n";
	    break;
		case 14:
			echo "var image_url14 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image14 = document.getElementById('myimage14');\n";
	    echo "playback_image14.src = image_url14 + '&' + Math.random();\n";
	    echo "playback_image14.width = '$pageW';\n";
	    echo "playback_image14.height = '$pageH';\n";
	    break;
		case 15:
			echo "var image_url15 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image15 = document.getElementById('myimage15');\n";
	    echo "playback_image15.src = image_url15 + '&' + Math.random();\n";
	    echo "playback_image15.width = '$pageW';\n";
	    echo "playback_image15.height = '$pageH';\n";
	    break;
		case 16:
			echo "var image_url16 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image16 = document.getElementById('myimage16');\n";
	    echo "playback_image16.src = image_url16 + '&' + Math.random();\n";
	    echo "playback_image16.width = '$pageW';\n";
	    echo "playback_image16.height = '$pageH';\n";
	    break;
		case 17:
			echo "var image_url17 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image17 = document.getElementById('myimage17');\n";
	    echo "playback_image17.src = image_url17 + '&' + Math.random();\n";
	    echo "playback_image17.width = '$pageW';\n";
	    echo "playback_image17.height = '$pageH';\n";
	    break;
		case 18:
			echo "var image_url18 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image18 = document.getElementById('myimage18');\n";
	    echo "playback_image18.src = image_url18 + '&' + Math.random();\n";
	    echo "playback_image18.width = '$pageW';\n";
	    echo "playback_image18.height = '$pageH';\n";
	    break;
		case 19:
			echo "var image_url19 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image19 = document.getElementById('myimage19');\n";
	    echo "playback_image19.src = image_url19 + '&' + Math.random();\n";
	    echo "playback_image19.width = '$pageW';\n";
	    echo "playback_image19.height = '$pageH';\n";
	    break;
		case 20:
			echo "var image_url20 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image20 = document.getElementById('myimage20');\n";
	    echo "playback_image20.src = image_url20 + '&' + Math.random();\n";
	    echo "playback_image20.width = '$pageW';\n";
	    echo "playback_image20.height = '$pageH';\n";
	    break;
		case 21:
			echo "var image_url21 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image21 = document.getElementById('myimage21');\n";
	    echo "playback_image21.src = image_url21 + '&' + Math.random();\n";
	    echo "playback_image21.width = '$pageW';\n";
	    echo "playback_image21.height = '$pageH';\n";
	    break;
		case 22:
			echo "var image_url22 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image22 = document.getElementById('myimage22');\n";
	    echo "playback_image22.src = image_url22 + '&' + Math.random();\n";
	    echo "playback_image22.width = '$pageW';\n";
	    echo "playback_image22.height = '$pageH';\n";
	    break;
		case 23:
			echo "var image_url23 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image23 = document.getElementById('myimage23');\n";
	    echo "playback_image23.src = image_url23 + '&' + Math.random();\n";
	    echo "playback_image23.width = '$pageW';\n";
	    echo "playback_image23.height = '$pageH';\n";
	    break;
		case 24:
			echo "var image_url24 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image24 = document.getElementById('myimage24');\n";
	    echo "playback_image24.src = image_url24 + '&' + Math.random();\n";
	    echo "playback_image24.width = '$pageW';\n";
	    echo "playback_image24.height = '$pageH';\n";
	    break;
		case 25:
			echo "var image_url25 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image25 = document.getElementById('myimage25');\n";
	    echo "playback_image25.src = image_url25 + '&' + Math.random();\n";
	    echo "playback_image25.width = '$pageW';\n";
	    echo "playback_image25.height = '$pageH';\n";
	    break;
		case 26:
			echo "var image_url26 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image26 = document.getElementById('myimage26');\n";
	    echo "playback_image26.src = image_url26 + '&' + Math.random();\n";
	    echo "playback_image26.width = '$pageW';\n";
	    echo "playback_image26.height = '$pageH';\n";
	    break;
		case 27:
			echo "var image_url27 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image27 = document.getElementById('myimage27');\n";
	    echo "playback_image27.src = image_url27 + '&' + Math.random();\n";
	    echo "playback_image27.width = '$pageW';\n";
	    echo "playback_image27.height = '$pageH';\n";
	    break;
		case 28:
			echo "var image_url28 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image28 = document.getElementById('myimage28');\n";
	    echo "playback_image28.src = image_url28 + '&' + Math.random();\n";
	    echo "playback_image28.width = '$pageW';\n";
	    echo "playback_image28.height = '$pageH';\n";
	    break;
		case 29:
			echo "var image_url29 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image29 = document.getElementById('myimage29');\n";
	    echo "playback_image29.src = image_url29 + '&' + Math.random();\n";
	    echo "playback_image29.width = '$pageW';\n";
	    echo "playback_image29.height = '$pageH';\n";
	    break;
		case 30:
			echo "var image_url30 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image30 = document.getElementById('myimage30');\n";
	    echo "playback_image30.src = image_url30 + '&' + Math.random();\n";
	    echo "playback_image30.width = '$pageW';\n";
	    echo "playback_image30.height = '$pageH';\n";
	    break;
		case 31:
			echo "var image_url31 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image31 = document.getElementById('myimage31');\n";
	    echo "playback_image31.src = image_url31 + '&' + Math.random();\n";
	    echo "playback_image31.width = '$pageW';\n";
	    echo "playback_image31.height = '$pageH';\n";
	    break;
		case 32:
			echo "var image_url32 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image32 = document.getElementById('myimage32');\n";
	    echo "playback_image32.src = image_url32 + '&' + Math.random();\n";
	    echo "playback_image32.width = '$pageW';\n";
	    echo "playback_image32.height = '$pageH';\n";
	    break;
		case 33:
			echo "var image_url33 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image33 = document.getElementById('myimage33');\n";
	    echo "playback_image33.src = image_url33 + '&' + Math.random();\n";
	    echo "playback_image33.width = '$pageW';\n";
	    echo "playback_image33.height = '$pageH';\n";
	    break;
		case 34:
			echo "var image_url34 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image34 = document.getElementById('myimage34');\n";
	    echo "playback_image34.src = image_url34 + '&' + Math.random();\n";
	    echo "playback_image34.width = '$pageW';\n";
	    echo "playback_image34.height = '$pageH';\n";
	    break;
		case 35:
			echo "var image_url35 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image35 = document.getElementById('myimage35');\n";
	    echo "playback_image35.src = image_url35 + '&' + Math.random();\n";
	    echo "playback_image35.width = '$pageW';\n";
	    echo "playback_image35.height = '$pageH';\n";
	    break;
		case 36:
			echo "var image_url36 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image36 = document.getElementById('myimage36');\n";
	    echo "playback_image36.src = image_url36 + '&' + Math.random();\n";
	    echo "playback_image36.width = '$pageW';\n";
	    echo "playback_image36.height = '$pageH';\n";
	    break;
		case 37:
			echo "var image_url37 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image37 = document.getElementById('myimage37');\n";
	    echo "playback_image37.src = image_url37 + '&' + Math.random();\n";
	    echo "playback_image37.width = '$pageW';\n";
	    echo "playback_image37.height = '$pageH';\n";
	    break;
		case 38:
			echo "var image_url38 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image38 = document.getElementById('myimage38');\n";
	    echo "playback_image38.src = image_url38 + '&' + Math.random();\n";
	    echo "playback_image38.width = '$pageW';\n";
	    echo "playback_image38.height = '$pageH';\n";
	    break;
		case 39:
			echo "var image_url39 = 'http://$webIP:$webPort/downloadfile.php?ip=$file&path=$webPath';\n";
	    echo "var playback_image39 = document.getElementById('myimage39');\n";
	    echo "playback_image39.src = image_url39 + '&' + Math.random();\n";
	    echo "playback_image39.width = '$pageW';\n";
	    echo "playback_image39.height = '$pageH';\n";
	    break;
  	}

	}
	//pg_close($testDb); 
}
?>
}
</script>

<body>


<!-- <meta http-equiv="refresh" content="2"> -->
<table>
 <tr>
 	<td>
 		<?php echo $numrows2 ; ?>
 	</td>
 </tr>
 <tr>
<?php

    $result = pg_exec($testDb, "select * from user_index where user_id = '$user_id' order by kvm_ip asc ");
    $numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$file = trim($info[6]);
	
		$fileport = trim($info[7]);
		echo "";
		//$filetest = $file;
		$filetest = $file.'p'.$fileport;
		//$filedir = 'C:\inetpub\wwwroot\\'.$filetest;
		$filedir = $webPath1.$filetest;
		$filesnames = scandir($filedir);
		rsort($filesnames);
 		foreach ($filesnames as $name) {
 		    $aurl= $name;
 		    break;
 		}
		$kvm_ip = $file;
		
		$jj = $i %$img_con;
    if ( $jj < 1)
    {
		  echo "</tr><tr>";
	  }
		//echo "<td><table><tr><td>$filetest</td></tr><tr><td><img src='http://$webIP:$webPort/$filetest/$aurl' id=myimage$i  width=$pageW height=$pageH>";
	  echo "<td><table><tr><td>$filetest</td></tr><tr><td><img src='http://$webIP:$webPort/downloadfile.php?ip=$filetest&path=$webPath' id=myimage$i  width=$pageW height=$pageH>";
		
		switch($i)
		{
		case 0:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage0></div></a></td></tr></table></td>";
			break;
		case 1:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage1></div></a></td></tr></table></td>";
			break;
		case 2:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage2></div></a></td></tr></table></td>";
			break;
		case 3:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage3></div></a></td></tr></table></td>";
			break;
		case 4:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage4></div></a></td></tr></table></td>";
			break;
		case 5:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage5></div></a></td></tr></table></td>";
			break;
		case 6:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage6></div></a></td></tr></table></td>";
			break;
		case 7:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage7></div></a></td></tr></table></td>";
			break;
		case 8:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage8></div></a></td></tr></table></td>";
			break;
		case 9:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage9></div></a></td></tr></table></td>";
			break;
		case 10:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage10></div></a></td></tr></table></td>";
			break;
		case 11:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage11></div></a></td></tr></table></td>";
			break;
		case 12:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage12></div></a></td></tr></table></td>";
			break;
		case 13:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage13></div></a></td></tr></table></td>";
			break;
		case 14:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage14></div></a></td></tr></table></td>";
			break;
		case 15:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage15></div></a></td></tr></table></td>";
			break;
		case 16:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage16></div></a></td></tr></table></td>";
			break;
		case 17:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage17></div></a></td></tr></table></td>";
			break;
		case 18:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage18></div></a></td></tr></table></td>";
			break;
		case 19:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage19></div></a></td></tr></table></td>";
			break;
		case 20:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage20></div></a></td></tr></table></td>";
			break;
		case 21:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage21></div></a></td></tr></table></td>";
			break;
		case 22:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage22></div></a></td></tr></table></td>";
			break;
		case 23:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage23></div></a></td></tr></table></td>";
			break;
		case 24:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage24></div></a></td></tr></table></td>";
			break;
		case 25:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage25></div></a></td></tr></table></td>";
			break;
		case 26:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage26></div></a></td></tr></table></td>";
			break;
		case 27:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage27></div></a></td></tr></table></td>";
			break;
		case 28:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage28></div></a></td></tr></table></td>";
			break;
		case 29:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage29></div></a></td></tr></table></td>";
			break;
		case 30:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage30></div></a></td></tr></table></td>";
			break;
		case 31:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage31></div></a></td></tr></table></td>";
			break;
		case 32:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage32></div></a></td></tr></table></td>";
			break;
		case 33:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage33></div></a></td></tr></table></td>";
			break;
		case 34:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage34></div></a></td></tr></table></td>";
			break;
		case 35:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage35></div></a></td></tr></table></td>";
			break;
		case 36:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage36></div></a></td></tr></table></td>";
			break;
		case 37:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage37></div></a></td></tr></table></td>";
			break;
		case 38:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage38></div></a></td></tr></table></td>";
			break;
		case 39:
			echo "<a href=\"http:\\\\$kvm_ip[0]\\java.vnc\" target=\"_new\"><div><img id=myimage39></div></a></td></tr></table></td>";
			break;
		}
		
	}
	
	pg_close($testDb); 
	
// 	var_dump($image);
// 	var_dump($file);
// 	var_dump($filedir);
// 	var_dump($aurl);
	
?>
</tr>
</table>
</body>
</HTML>