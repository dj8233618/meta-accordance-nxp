<?php
include_once("web_conf.php");
//require_once('syslog.php');
$kvm_ip = $_GET['delid'];
$kvm_port = $_GET['delide'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$sql = "delete from kvm_table where kvm_ip='$kvm_ip' and kvm_port='$kvm_port'";
	$result = pg_exec($testDb, $sql);
	
	$sql2 = "delete from user_index where kvm_ip='$kvm_ip' and kvm_port='$kvm_port'";
	$result = pg_exec($testDb, $sql2);
	
	$sql3 = "delete from kvm_svm_table where kvm_ip='$kvm_ip' ";
	$result = pg_exec($testDb, $sql3);
	
	$sql4 = "delete from tx_table where kvm_ip='".$kvm_ip."p".$kvm_port."' ";
	//echo $sql;
	$result = pg_exec($testDb, $sql4);
	
	echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	pg_close($testDb); 
}

?>