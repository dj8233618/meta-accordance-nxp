<?php
session_start();
$FacList = $_SESSION['FacList'];
$ConList = $_SESSION['ConList'];
$FacChoose = $_SESSION['FacChoose'];

$userid = $_POST["user"];
?>
<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<meta charset="utf-8">
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_user_machine_delete2.php" method="post"> 
  		<input type="hidden" name="userid" value="<?php echo $userid ?>"> <?php echo $userid ?> </td>
		<br>
		    <?php 
		    include_once("web_conf.php");
		    $testDb=pg_connect($DBase_INI);
		    if( $userid == "All")
		    {
			    $result = pg_exec($testDb, "select * from user_index where use_lyout is null order by user_id asc , kvm_gp asc");
			    $numrows = pg_num_rows($result);
			    echo "<table>";
			    for($i=0;$i<$numrows;$i++)
			    {
			        $info=pg_fetch_array($result);
			        $user_id = trim($info[0]);
			        $kvm_ip = trim($info[6]);
			        
			        
			        echo "<tr><td>$user_id </td><td> $kvm_ip </td><td>";
			        
			          if( strcmp( $user_id, "admin") )
			          {
			              echo "<a href=\"set_user_machine_delete.php?A=$user_id&B=$kvm_ip\" > delete</a>";
			          }
			        echo"<br>";
			        echo "</td></tr>";
			        
			    }
			    echo "</table>";
			    pg_close($testDb);
		    }
		    else
		    {
          $sql = "select * from user_index where  use_lyout is null and user_id ='$userid'order by kvm_gp asc ";
        	$result = pg_exec($testDb, $sql);
        	$numrows = pg_num_rows($result);
        	for($i=0;$i<$numrows;$i++)
        	{
        	    $info=pg_fetch_array($result);
			        $user_id = trim($info[0]);
			        $kvm_ip = trim($info[6]);
			        $kvm_id = trim($info[5]);
        	    echo "<input type= checkbox value=$kvm_ip name=kvm[]>$kvm_ip - $kvm_id<br>";
        	}
        	?>
		<br>
		<br>
        			<input type="submit" value="<?php echo _('delete');?>">
        	<?php		

        }
       ?>
	</form>
  </body>
</html>
