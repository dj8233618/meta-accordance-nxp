<?php 
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
		$kvm_ip = $_POST["kvm_ip"];
		$kvm_connect  = $_POST["kvm_connect"];
		$kvm_scaling  = $_POST["kvm_scaling"];
		$kvm_cursor  = $_POST["kvm_cursor"];
		$kvm_format  = $_POST["kvm_format"];
		$kvm_quality  = $_POST["kvm_quality"];
		$kvm_snaphot  = $_POST["kvm_snaphot"];
		$kvm_timeout  = $_POST["kvm_timeout"];
		$kvm_restart  = $_POST["kvm_restart"];
		$kvm_ocr_enable  = $_POST["kvm_ocr_enable"];
		$kvm_ocr_file  = $_POST["kvm_ocr_file"];
		$kvm_ocr_interval  = $_POST["kvm_ocr_interval"];
		$kvm_ocr_times  = $_POST["kvm_ocr_times"];
		$kvm_ocr_x = $_POST["kvm_ocr_x"];
		$kvm_ocr_y = $_POST["kvm_ocr_y"];
		$kvm_ocr_w = $_POST["kvm_ocr_w"];
		$kvm_ocr_h = $_POST["kvm_ocr_h"];
		$kvm_ocr_word = $_POST["kvm_ocr_word"];
		$kvm_ocr_color = $_POST["kvm_ocr_color"];
		$kvm_conn_retry = $_POST["kvm_conn_retry"];
		$kvm_ocrs_enable = $_POST["kvm_ocrs_enable"];
		$kvm_ocrs_key = $_POST["kvm_ocrs_key"];
		$kvm_io_port = $_POST["kvm_io_port"];
    
	if( $kvm_ip == "")
	{
    echo "KVM ip is null";
	}
	else
	{


    $sql = "SELECT * FROM kvm_svm_table where kvm_ip = '$kvm_ip' ";
 		//echo $sql;
 		
		$result1 = pg_exec($testDb, $sql);
    $numrows1 = pg_num_rows($result1);
    
    echo $numrows1;
    
		if( $numrows1 > 0)
		{
			$sql = "update kvm_svm_table set kvm_connect='$kvm_connect',kvm_scaling='$kvm_scaling',kvm_cursor='$kvm_cursor',kvm_format='$kvm_format',kvm_quality='$kvm_quality',kvm_snaphot='$kvm_snaphot',kvm_timeout='$kvm_timeout',kvm_restart='$kvm_restart',kvm_ocr_enable=$kvm_ocr_enable,kvm_ocr_file='$kvm_ocr_file',kvm_ocr_interval='$kvm_ocr_interval',kvm_ocr_times='$kvm_ocr_times',kvm_ocr_x='$kvm_ocr_x',kvm_ocr_y='$kvm_ocr_y',kvm_ocr_w='$kvm_ocr_w',kvm_ocr_h='$kvm_ocr_h',kvm_ocr_word='$kvm_ocr_word',kvm_ocr_color='$kvm_ocr_color',kvm_conn_retry='$kvm_conn_retry',kvm_ocrs_enable='$kvm_ocrs_enable',kvm_ocrs_key='$kvm_ocrs_key',kvm_io_port='$kvm_io_port' where kvm_ip='$kvm_ip' ";
			//echo "$sql<br>";
			echo "update<br>";
		}
		else
		{
    	$sql = "INSERT INTO kvm_svm_table (kvm_connect,kvm_scaling,kvm_cursor,kvm_format,kvm_quality,kvm_snaphot,kvm_timeout,kvm_restart,kvm_ocr_enable,kvm_ocr_file,kvm_ocr_interval,kvm_ocr_times,kvm_ocr_x,kvm_ocr_y,kvm_ocr_w,kvm_ocr_h,kvm_ocr_word,kvm_ocr_color,kvm_conn_retry,kvm_ocrs_enable,kvm_ocrs_key,kvm_io_port,kvm_ip);
    	$sql = $sql + VALUES ($kvm_connect,$kvm_scaling,$kvm_cursor,$kvm_format,'$kvm_quality','$kvm_snaphot','$kvm_timeout','$kvm_restart',$kvm_ocr_enable,'$kvm_ocr_file',$kvm_ocr_interval,$kvm_ocr_times,'$kvm_ocr_x','$kvm_ocr_y','$kvm_ocr_w','$kvm_ocr_h','$kvm_ocr_word','$kvm_ocr_color','$kvm_conn_retry','$kvm_ocrs_enable','$kvm_ocrs_key','$kvm_io_port','$kvm_ip')";
			//echo "insert<br>";
			//echo $sql;
    }
    $result = pg_exec($testDb, $sql);

    echo "connect success";
    //echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
    pg_close($testDb);
  }  
}

?>