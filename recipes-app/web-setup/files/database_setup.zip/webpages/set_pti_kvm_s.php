<?php
	//$myMode =$_GET['mode'];
	//http://127.0.0.1/set_pti_kvm_s.php?ip=192.168.1.101&io=3
	$myIP =$_GET['ip'];
	$myFile =$_GET['io'];
	//-------------------------------------------------------------------- 
	//filename:class.php 
	//summary: access�ƾڮw�ާ@�� 
	//   �ϥνd�ҡG 
	//include_once("odbC.php"); 
	include_once("pgsqln.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	//$imgfile = $access->getinfo_one($table,$field,$myIP,$set);
	//if(!$imgfile )
	//{
	//	echo "insert";
	//	$access->insert_io($table,$field,$myIP);
	//}
	//else
	{
		echo "updata";
		$access->updateinfo_io($pti_table,$pti_field,$myIP,$set_pti_io,$myFile);
	}
	$access->close();
	
?>