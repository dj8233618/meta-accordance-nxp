<?php 
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    $kvm_id = $_POST["kvm_id"];
    $kvm_ip = $_POST["kvm_ip"];
    $kvm_port = $_POST["kvm_port"];
    $kvm_pwd = $_POST["kvm_pwd"];
    $rcvm_ip = $_POST["rcvm_ip"];
    $kvm_sm = $_POST["kvm_sm"];
    $kvm_model = $_POST["kvm_model"];
    $tx_ip = $_POST["tx_ip"];
    
    $mc_fab = $_POST["mc_fab"];
    $mc_dept = $_POST["mc_dept"];
    $mc_sect = $_POST["mc_sect"];
    $kvm_local = $_POST["kvm_local"];
    $mc_pg = $_POST["mc_pg"];
    $mc_vender = $_POST["mc_vender"];
    $mc_model = $_POST["mc_model"];
    $mc_name = $_POST["mc_name"];
    $kvm_gp = $_POST["kvm_gp"];
    //var_dump($kvm_id);
    //var_dump($kvm_ip);
    //var_dump($kvm_port);
    //var_dump($kvm_pwd);
    //var_dump($rcvm_ip);
    //var_dump($rcvm_path);
    
	if( $kvm_ip == "")
	{
    echo "KVM ip is null";
	}
	else
	{
    var_dump($kvm_model);
    
			$result3 = pg_exec($testDb, "select * from rcvm_table where rcvm_ip = '$rcvm_ip' ");
	    $numrows3 = pg_num_rows($result3);
			if( $numrows3> 0)
			{
				$info3=pg_fetch_array($result3);
				$webPath=trim($info3[8]);
			}

    $sql = "select * from kvm_table where kvm_ip='$kvm_ip' and kvm_port='$kvm_port' ";
 		//echo $sql;
 		
		$result1 = pg_exec($testDb, $sql);
    $numrows1 = pg_num_rows($result1);
    
		if( $numrows1 > 0)
		{
			$sql = "update kvm_table set  kvm_mc_group='$kvm_gp' ,kvm_id='$kvm_id' ,kvm_pwd='$kvm_pwd' ,rcvm_ip='$rcvm_ip' ,kvm_fab='$mc_fab' ,kvm_dept='$mc_dept' ,kvm_sect='$mc_sect' ,kvm_pg='$mc_pg' ,kvm_vender='$mc_vender' ,kvm_local='$kvm_local',kvm_mc_model='$mc_model' ,kvm_name='$mc_name' ,f_realvnc='$kvm_sm' ,rcvm_path='$webPath',kvm_model='$kvm_model',kvm_https='0',tx_ip='$tx_ip' where kvm_ip='$kvm_ip' and kvm_port='$kvm_port' ";
			echo "$sql<br>";
			echo "update<br>";
		}
		else
		{
			$sss = "$mc_fab-$mc_name";
			//echo $sss;
    $sql = "insert into kvm_table (kvm_id,kvm_ip,kvm_port,kvm_pwd,rcvm_ip,rcvm_path,f_realvnc,kvm_fab,kvm_dept,kvm_sect,kvm_pg,kvm_vender,kvm_mc_model,kvm_local,kvm_name,kvm_model,kvm_https,tx_ip,kvm_mc_group) 
            select '$kvm_id','$kvm_ip','$kvm_port','$kvm_pwd','$rcvm_ip','$webPath','$kvm_sm','$mc_fab','$mc_dept','$mc_sect','$mc_pg','$mc_vender','$mc_model','$kvm_local','$sss','$kvm_model' ,'0','$tx_ip','$kvm_gp'
            where not exists (select * from kvm_table where kvm_id='$kvm_id' and kvm_ip='$kvm_ip' and kvm_port='$kvm_port' and kvm_pwd='$kvm_pwd' and rcvm_ip='$rcvm_ip' and rcvm_path='rcvm_path')";
			echo "insert<br>";
			//echo $sql;
    }
    $result = pg_exec($testDb, $sql);

    $sql = "SELECT * FROM kvm_svm_table where kvm_ip = '$kvm_ip' ";
 		//echo $sql;
 		
		$result1 = pg_exec($testDb, $sql);
    $numrows1 = pg_num_rows($result1);
    
    echo $numrows1;
    
		if( $numrows1 > 0)
		{
			$sql = "update kvm_svm_table set kvm_connect='2',kvm_scaling='7',kvm_cursor='5',kvm_format='0',kvm_quality='60',kvm_snaphot='49',kvm_timeout='3',kvm_restart='35',kvm_ocr_enable=0,kvm_ocr_file='NULL',kvm_ocr_interval='2',kvm_ocr_times='3' where kvm_ip='$kvm_ip'  ";
			//echo "$sql<br>";
			echo "update<br>";
		}
		else
		{
    	$sql = "INSERT INTO kvm_svm_table (kvm_connect,kvm_scaling,kvm_cursor,kvm_format,kvm_quality,kvm_snaphot,kvm_timeout,kvm_restart,kvm_ocr_enable,kvm_ocr_file,kvm_ocr_interval,kvm_ocr_times,kvm_ip) VALUES ('2','7','5',0,'60','49','3','35',0,'NULL','2','3','$kvm_ip')";
			echo "insert<br>";
			//echo $sql;
    }
    $result = pg_exec($testDb, $sql);

    echo "connect success";
    echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
    pg_close($testDb);
  }  
}

?>