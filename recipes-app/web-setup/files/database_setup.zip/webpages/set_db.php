<?php
	$dbip = $_POST['dbip'];
	$bdport = $_POST['dbport'];
	$bdname = $_POST['dbname'];
	$dbusr = $_POST['dbuser'];
	$dbpwd = $_POST['dbpwd'];
	$img_rf = $_POST['img_rf'];
	$img_con = $_POST['img_con'];

	$root = $_SERVER [ 'DOCUMENT_ROOT' ];
	//echo $root
	$fp = fopen ( "$root/web_conf.php" , 'w' );
	fwrite( $fp , '<?php'.PHP_EOL );
	fwrite( $fp , '   $DBase_INI = "host='.$dbip.' port='.$bdport.' dbname='.$bdname.' user='.$dbusr.' password='.$dbpwd.'" ;'.PHP_EOL );
	fwrite( $fp , '   $img_reflash='.$img_rf.' ;'.PHP_EOL );
	fwrite( $fp , '   $img_con='.$img_con.' ;'.PHP_EOL );
	fwrite( $fp , '?>' );
	fclose( $fp );
/*	
	$fp1 = fopen ( "$root/web_conf.php" , 'r' );
while( $lineData=fgets($fp1) )
{
	  $stra = strstr($lineData,"host=");
    if( strlen($stra) >0 )
    {
			 	$Arr=explode(" ",$stra);
				foreach ($Arr as $value )
				{
					$Arr1=explode("=",$value);
					foreach ($Arr1 as $value1 )
					{
						echo $value1."<br>";
						if( $value1 == "host")
						{
							$dbip=$Arr1[1];
						}
						if( $value1 == "port")
						{
							$dbport=$Arr1[1];
						}
						if( $value1 == "dbname")
						{
							$dbname=$Arr1[1];
						}
						if( $value1 == "user")
						{
							$dbuser=$Arr1[1];
						}
						if( $value1 == "password")
						{
							$dbpwd=$Arr1[1];
						}
							
					}
				}
		}
  }
fclose($fp1);
echo $dbip;
*/
/*
	$userdata = fread($fp1,filesize("$root/web_conf.php"));
	//list($dbip, $bdport, $bdname,$dbusr,$dbpwd) = split ('[ ="] ', $userdata);
	//list($dbip, $bdport, $bdname,$dbusr,$dbpwd) = explode(" ",$userdata);
echo "----";
	echo $userdata;
	//$i =0;
	$Arr=explode(" ",$userdata);
	foreach ($Arr as $value )
	{
		echo $value;
	}
	fclose( $fp1 );
*/
?>