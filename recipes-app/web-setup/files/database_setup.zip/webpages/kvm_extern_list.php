<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_kvm_group.php" method="get">  
		<table cellpadding="1" border="1">
			<tr>
				<td><?php echo _('Tool Name');?></td>
				<td><?php echo _('Process Group');?></td>
				<td><?php echo _('Vender');?></td>
				<td><?php echo _('Model');?></td>
				<td><?php echo _('mc ver');?></td>
				<td><?php echo _('RCM IP');?></td>
				<td><?php echo _('RCM port');?></td>
				<td><?php echo _('RCM channel');?></td>
				<td><?php echo _('msmq_queue');?></td>
				<td><?php echo _('msmq_label');?></td>
				<td><?php echo _('msmq_queue_type');?></td>
				<td><?php echo _('msmq_queue_formatter');?></td>
				<td><?php echo _('Edit');?></td>
				<td><?php echo _('alarm ID');?></td>
				<td><?php echo _('Active');?></td>
			</tr>
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$sql = "select * from kvm_table order by kvm_mc_group asc, kvm_ip asc ";
	$result = pg_exec($testDb,$sql );
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$kvm_ip = trim($info[1]);
		$kvm_port = trim($info[2]);
		$kvm_name = trim($info[5]);
		$kvm_pg = trim($info[19]);
		$kvm_vender = trim($info[20]);
		$kvm_mc_model = trim($info[22]);
		$kvm_mc_ver  = trim($info[23]);
		$kvm_active  = trim($info[24]);
		$alarm_id  = trim($info[25]);
		$RCM_ip  = trim($info[26]);
		$RCM_port  = trim($info[27]);
		$RCM_channel  = trim($info[28]);
		$msmq_queue  = trim($info[29]);
		$msmq_label  = trim($info[30]);
		$msmq_queue_type  = trim($info[31]);
		$msmq_queue_formatter  = trim($info[32]);


		echo "<tr><td>$kvm_name</td><td>$kvm_pg</td><td>$kvm_vender</td><td>$kvm_mc_model</td><td>$kvm_mc_ver</td><td>$RCM_ip</td><td>$RCM_port</td><td>$RCM_channel</td>";
		echo "<td>$msmq_queue</td><td>$msmq_label</td><td>$msmq_queue_type</td><td>$msmq_queue_formatter</td>";
		echo "<td><a href=\"kvm_extern_list_add.php?kvm_ip=$kvm_ip&kvm_port=$kvm_port\" >edit</a></td>";
		echo "<td>$alarm_id</td><td>$kvm_active</td>";
		echo "</tr>";
	}
	pg_close($testDb); 
}
?> 
		</table>
	</form>
  </body>
</html>
