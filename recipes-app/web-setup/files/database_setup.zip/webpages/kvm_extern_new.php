<?php 
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    $kvm_ip = $_POST["kvm_ip"];
    $kvm_port = $_POST["kvm_port"];
    
		$kvm_pg = $_POST["kvm_pg"];
		$kvm_vender = $_POST["kvm_vender"];
		$kvm_mc_model = $_POST["kvm_mc_model"];
		$kvm_mc_ver  = $_POST["kvm_mc_ver"];
		$kvm_active  = $_POST["kvm_active"];
		$alarm_id  = $_POST["alarm_id"];
		$RCM_ip  = $_POST["RCM_ip"];
		$RCM_port  = $_POST["RCM_port"];
		$RCM_channel  = $_POST["RCM_channel"];
		$msmq_queue  = $_POST["msmq_queue"];
		$msmq_label  = $_POST["msmq_label"];
		$msmq_queue_type  = $_POST["msmq_queue_type"];
		$msmq_queue_formatter  = $_POST["msmq_queue_formatter"];
    
	if( $kvm_ip == "")
	{
    echo "KVM ip is null";
	}
	else
	{
    var_dump($kvm_model);
    
			$result3 = pg_exec($testDb, "select * from rcvm_table where rcvm_ip = '$rcvm_ip' ");
	    $numrows3 = pg_num_rows($result3);
			if( $numrows3> 0)
			{
				$info3=pg_fetch_array($result3);
				$webPath=trim($info3[8]);
			}

    $sql = "select * from kvm_table where kvm_ip='$kvm_ip' and kvm_port='$kvm_port' ";
 		//echo $sql;
 		
		$result1 = pg_exec($testDb, $sql);
    $numrows1 = pg_num_rows($result1);
    
		if( $numrows1 > 0)
		{
			$sql = "update kvm_table set msmq_queue='$msmq_queue', msmq_label='$msmq_label', msmq_queue_type='$msmq_queue_type', msmq_queue_formatter='$msmq_queue_formatter', kvm_pg='$kvm_pg' ,kvm_vender='$kvm_vender' ,kvm_mc_model='$kvm_mc_model' ,kvm_mc_ver='$kvm_mc_ver' ,RCM_ip='$RCM_ip' ,RCM_port='$RCM_port' ,RCM_channel='$RCM_channel' where kvm_ip='$kvm_ip' and kvm_port='$kvm_port' ";
			echo "$sql<br>";
			echo "update<br>";
		}
    $result = pg_exec($testDb, $sql);


    echo "connect success";
    echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
    pg_close($testDb);
  }  
}

?>