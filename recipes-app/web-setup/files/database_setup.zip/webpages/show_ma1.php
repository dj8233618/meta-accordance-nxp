<HTML>
<HEAD>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta http-equiv="ReFresh" content="5;URL=show_ma1.php">
</HEAD>

<script>
    window.onload = function() {
      setInterval(get_image, 1000);
    };

    window.onerror = function() {
      setInterval(get_image, 1000);
    };
    function get_image() {
<?php
 	$today = Date("Y/m/d H:i:s");
  include_once("web_conf.php");
	$KVMIP ="192.168.55.13";
	$webIP ="192.168.55.21";
	$webPort ="80";
	$webPath ="C:/inetpub/wwwroot/";
	$pageW ="320";
	$pageH ="240";
	
	//echo "var image_url0 = 'http://$webIP:$webPort/downloadfile.php?ip=$KVMIP&path=$webPath';\n";
  //echo "var playback_image0 = document.getElementById('myimage0');\n";
  //echo "playback_image0.src = image_url0 + '&' + Math.random();\n";
  //echo "playback_image0.width = '$pageW';\n";
  //echo "playback_image0.height = '$pageH';\n";
	
	$testDb=pg_connect($DBase_INI); 
	if($testDb == FALSE)
	{
		echo "connect error";
	}
	else
	{
	  
		$result = pg_exec($testDb, "select * from machine_state where kvm_ip = '1'");
		$numrows = pg_num_rows($result);
		if( $numrows )
		{
			$info=pg_fetch_array($result,0);
			$web_ip = trim($info[1]);
			$web_port = trim($info[2]);
			$machineid = trim($info[3]);
			$web_16w = trim($info[4]);
			$web_16h = trim($info[5]);
			$web_w = trim($info[6]);
			$web_h = trim($info[7]);
			$web_h1 = trim($info[8]);
			$message = trim($info[9]);
		}
		pg_close($testDb); 
	}
?>
    }
</script>
<body>
	<table>
		<tr>
			<td>Today<?php echo $today ?></td> 
		</tr>
		<tr>
			<td><div><img id=myimage0></div></td>
		</tr>
		<tr>
			<td><?php echo $machineid ?></td> 
		</tr>
		<tr>
			<td><?php echo $message ?></td>
		</tr>
		<tr>
			<td><div><img id=myimage0></div></td>
		</tr>
	</table>
	<hr>
	<table>
		<tr>
<?php
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from ocr_table where kvm_ip = '".$machineid."' ");
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$kvm_ip = trim($info[0]);
		$t1 = trim($info[1]);
		
		for ($j = 1; $j < 200; $j++) 
		//if( strcmp( $user, "admin") )
		{
			$value1 = trim($info[$j]);
			if( $value1 != "")
			{
				echo "<td>$value1<td>";
			}
		}
		echo "</tr>";
	}
	pg_close($testDb); 
	//echo "<frame name=\"main\" src=\"page16_a.php?web_ip=$web_ip&web_port=$web_port&web_path=$web_path&page_w=$web_w&page_h=$web_h\" scrolling=\"auto\" target=\"_self\">"; 
}
?>
	</table>
</body>
