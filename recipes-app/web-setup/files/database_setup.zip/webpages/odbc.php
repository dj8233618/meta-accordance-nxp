<?php
//-------------------------------------------------------------------- 
//filename:class.php 
//summary: access�ƾڮw�ާ@�� 
//   �ϥνd�ҡG 
//$databasepath="database.mdb"; 
//$dbusername=""; 
//$dbpassword=""; 
//include_once("class.php"); 
//$access=new access($databasepath,$dbusername,$dbpassword); 
//<p style="padding:6px;background:#FFF;">
//-------------------------------------------------------------------- 
  $dbserver="localhost\\SQLEXPRESS";
  $dbdebase="OCR";
	$databasepath="svm.mdb"; 
	$dbusername="sa"; 
	$dbpassword="1qaz2wsx"; 
	$table="TX_Table";
	$field="KVM_IP";
	$set="TX_IP";
	class access 
	{ 
		var $databasepath,$constr,$dbusername,$dbpassword,$link,$dbserver,$dbdebase; 
		//function access($databasepath,$dbusername,$dbpassword) // for mdb
	  //{ 
		//	$this->databasepath=$databasepath; 
		//	$this->username=$dbusername; 
		//	$this->password=$dbpassword; 
		//	$this->connect(); 
		//} 

		function access($dbserver,$dbdebase,$dbusername,$dbpassword)  // for msSQL
		{ 
			$this->dbserver=$dbserver; 
			$this->dbdebase=$dbdebase; 
			$this->username=$dbusername; 
			$this->password=$dbpassword; 
			$this->connectMSSQL(); 
		} 

		function connect() 
		{ 
			$this->constr="driver={microsoft access driver (*.mdb)}; dbq=" . realpath($this->databasepath);
			$this->link = @odbc_connect($this->constr,$this->username,$this->password); 
			//$sql = "insert into TX_Table (KVM_IP, TX_IP) values ('192.168.1.1','1111')";
			if($this->link == FALSE)
			{
				echo $this->constr;
				echo "link  error";
			}
			//$err =@odbc_exec($this->link,$sql);
			//if($err == FALSE)
			//{
			//	echo $sql;
			//	echo "link  error";
			//}
			return $this->link; 
			//if($this->link) echo "���ߧA,�ƾڮw�s�����\!"; 
			//else echo "�ƾڮw�s������!"; 
		} 
		
		function connectMSSQL() 
		{ 
			//$this->constr="Driver={SQL Server Native Client 10.0};Server=localhost\\SQLEXPRESS;Batabase=OCR;";
			$this->constr="Driver={SQL Server Native Client 10.0};Server=".$this->dbserver.";Batabase=".$this->dbdebase.";";

			$this->link = @odbc_connect($this->constr,$this->username,$this->password); 
			//$sql = "insert into TX_Table (KVM_IP, TX_IP) values ('192.168.1.1','1111')";
			if($this->link == FALSE)
			{
				echo $this->constr;
				echo "link  error";
			}
			return $this->link; 
		} 
		
		function query($sql) 
		{ 
			return @odbc_exec($this->link,$sql); 
		} 
		
		function first_array($sql) 
		{ 
			return odbc_fetch_array($this->query($sql)); 
		} 
		
		function fetch_row($query) 
		{ 
			return odbc_fetch_row($query); 
		} 
		
		function total_num($sql)//���o�O���`�� 
		{ 
			return odbc_num_rows($this->query($sql)); 
		} 
		
		function close()//�����ƾڮw�s����� 
		{   
			odbc_close($this->link); 
		} 
		
		function insert($table,$field,$myIP)//���J�O����� 
		{ 
			$sql="insert into ".$table." (".$field.",TX_IP) values ('".$myIP."','screenshot.jpg')"; 
			//echo $sql;
			$this->query($sql); 
		} 
		
		function getinfo_one($table,$field,$id,$set)//���o�����O���ԲӫH�� 
		{ 
			$sql="select ".$set." from ".$table." where ".$field."='".$id."'"; 
			$query=$this->query($sql); 
			if($this->fetch_row($query)) 
			{ 
					$info=odbc_result($query,1); 
					//echo $info;
			} 
			return $info; 
		} 
		
		function getinfo($table,$field,$id,$cbnum)//���o�����O���ԲӫH�� 
		{ 
			$sql="select * from ".$table." where ".$field."=".$id.""; 
			$query=$this->query($sql); 
			if($this->fetch_row($query)) 
			{ 
				for ($i=1;$i<$cbnum;$i++) 
				{ 
					$info[$i]=odbc_result($query,$i); 
				} 
			} 
			return $info; 
		} 
		
		function getlist($table,$field,$cbnum,$condition,$sort="order by id desc")//���o�O���C��   
		{ 
			$sql="select * from ".$table." ".$condition." ".$sort; 
			$query=$this->query($sql); 
			$i=0; 
			while ($this->fetch_row($query))
			{ 
				$recordlist[$i]=getinfo($table,$field,odbc_result($query,1),$cbnum); 
				$i++; 
			} 
			return $recordlist; 
		} 
		
		function getfieldlist($table,$field,$fieldnum,$condition="",$sort="")//���o�O���C�� 
		{ 
			$sql="select ".$field." from ".$table." ".$condition." ".$sort; 
			$query=$this->query($sql); 
			$i=0; 
			while ($this->fetch_row($query))
			{ 
				for ($j=0;$j<$fieldnum;$j++) 
				{ 
					$info[$j]=odbc_result($query,$j+1); 
				}   
				$rdlist[$i]=$info; 
				$i++; 
			} 
			return $rdlist; 
		} 
		
		function updateinfo($table,$field,$myIP,$set,$myFile)//��s�O�� 
		{ 
			$sql="update ".$table." set ".$set."='".$myFile."' where ".$field."='".$myIP."'"; 
			$this->query($sql); 
		} 
		
		function deleteinfo($table,$field,$id)//�R���O�� 
		{ 
			$sql="delete from ".$table." where ".$field."=".$id; 
			$this->query($sql); 
		} 
		
		function deleterecord($table,$condition)//�R�����w���󪺰O�� 
		{ 
			$sql="delete from ".$table." where ".$condition; 
			$this->query($sql); 
		} 
		
		function getcondrecord($table,$condition="")// ���o���w���󪺰O���� 
		{ 
			$sql="select count(*) as num from ".$table." ".$condition; 
			$query=$this->query($sql); 
			$this->fetch_row($query); 
			$num=odbc_result($query,1); 
			return $num;           
		} 
	} 
?>
