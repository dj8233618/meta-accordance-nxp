<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$kvm_ip = $_GET['kvm_ip'];
$kvm_port = $_GET['kvm_port'];

		$kvm_name = "";
		$kvm_pg = "";
		$kvm_vender = "";
		$kvm_mc_model = "";
		$kvm_mc_ver  = "";
		$kvm_active  = "";
		$alarm_id  = "";
		$RCM_ip  = "";
		$RCM_port  = "";
		$RCM_channel  = "";
		$msmq_queue  = "";
		$msmq_label  = "";
		$msmq_queue_type  = "";
		$msmq_queue_formatter  = "";
		
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$sql = "select * from kvm_table  where kvm_ip='".$kvm_ip."' and kvm_port=' ".$kvm_port."' ";
	//echo $sql;
	$result = pg_exec($testDb,$sql );
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		
		$kvm_name = trim($info[5]);
		$kvm_pg = trim($info[19]);
		$kvm_vender = trim($info[20]);
		$kvm_mc_model = trim($info[22]);
		$kvm_mc_ver  = trim($info[23]);
		$kvm_active  = trim($info[24]);
		$alarm_id  = trim($info[25]);
		$RCM_ip  = trim($info[26]);
		$RCM_port  = trim($info[27]);
		$RCM_channel  = trim($info[28]);
		$msmq_queue  = trim($info[29]);
		$msmq_label  = trim($info[30]);
		$msmq_queue_type  = trim($info[31]);
		$msmq_queue_formatter  = trim($info[32]);
	}
	pg_close($testDb); 
}
?>
<html>
<head>
<meta charset="utf-8">
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
  <form action="kvm_extern_new.php" method="post">
     	 <input type="hidden" name=kvm_ip value="<?php echo $kvm_ip ?>"> 
     	 <input type="hidden" name=kvm_port value="<?php echo $kvm_port ?>"> 
       <table >
      	<tr>
					<td><?php echo _('Tool Name');?></td>
      		<td><?php echo $kvm_name ?> </td>
      	</tr>
      	<tr>
					<td><?php echo _('Group');?></td>
      		<td> <input type="text" name=kvm_pg value="<?php echo $kvm_pg ?>"> </td>
      	</tr>
      	<tr>
					<td><?php echo _('Vender');?></td>
      		<td> <input type="text" name=kvm_vender value="<?php echo $kvm_vender ?>"> </td>
      	</tr>
      	<tr>
					<td><?php echo _('Model');?></td>
      		<td> <input type="text" name=kvm_mc_model value="<?php echo $kvm_mc_model ?>"> </td>
      	</tr>
      	<tr>
					<td><?php echo _('mc ver');?></td>
      		<td> <input type="text" name=kvm_mc_ver value="<?php echo $kvm_mc_ver ?>"> </td>
      	</tr>
      	<tr>
					<td><?php echo _('RCM IP');?></td>
      		<td> <input type="text" name=RCM_ip value="<?php echo $RCM_ip ?>"> </td>
      	</tr>
      	<tr>
					<td><?php echo _('RCM port');?></td>
      		<td> <input type="text" name=RCM_port value="<?php echo $RCM_port ?>"> </td>
      	</tr>
      	<tr>
					<td><?php echo _('RCM channel');?></td>
      		<td> <input type="text" name=RCM_channel value="<?php echo $RCM_channel ?>"> </td>
      	</tr>
      	<tr>
					<td><?php echo _('msmq_queue');?></td>
      		<td> <input type="text" name=msmq_queue value="<?php echo $msmq_queue ?>"> </td>
      	</tr>
      	<tr>
					<td><?php echo _('msmq_label');?></td>
      		<td> <input type="text" name=msmq_label value="<?php echo $msmq_label ?>"> </td>
      	</tr>
      	<tr>
					<td><?php echo _('msmq_queue_type');?></td>
      		<td> <input type="text" name=msmq_queue_type value="<?php echo $msmq_queue_type ?>"> </td>
      	</tr>
      	<tr>
					<td><?php echo _('msmq_queue_formatter');?></td>
      		<td> <input type="text" name=msmq_queue_formatter value="<?php echo $msmq_queue_formatter ?>"> </td>
      	</tr>
      	<tr>
      	</tr>
        <tr>
      		<td> <input type="submit" value="<?php echo _('Submit');?>" > </td>
      	</tr> 	
      </table>
  </form>
  </body>
</html>