<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_svm_machine.php" method="post">  
		<select id="user" name="svm">
        	<?php 
        	include_once("web_conf.php");
        	$testDb=pg_connect($DBase_INI);
        	$sql = "select * from rcvm_table order by rcvm_ip asc";
        	$result = pg_exec($testDb, $sql);
        	$numrows = pg_num_rows($result);
        	for($i=0;$i<$numrows;$i++)
        	{
        	    $info=pg_fetch_array($result);
        	    $rcvm_ip = trim($info[1]);
        	    if($rcvm_ip!=null)
        	    {
        	       echo "<option value=$rcvm_ip>$rcvm_ip</option>";
        	
        	    }
        	}
            ?>
		</select>
		<br>
		    <?php 
		    include_once("web_conf.php");
		    $testDb=pg_connect($DBase_INI);
        	$sql = "select * from kvm_table order by kvm_ip asc";
        	$result = pg_exec($testDb, $sql);
        	//$numrows = pg_num_rows($result);
        	$numrows = pg_num_rows($result);
        	for($i=0;$i<$numrows;$i++)
        	{
        	    $info=pg_fetch_array($result);
        	    $kvm_ip = trim($info[1]);
        	    $kvm_port = trim($info[2]);

        	    echo "<input type= checkbox value=$kvm_ip name=kvm[]>$kvm_ip";
        	    echo "&nbsp;&nbsp;&nbsp;$kvm_port<br>";
        	}
            ?>
		<br>
		<br>
		<input type="submit" value="<?php echo _('Submit');?>">
	</form>
  </body>
</html>
