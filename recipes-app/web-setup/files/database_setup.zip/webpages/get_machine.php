<?php
	//$myMode =$_GET['mode'];
	$myIP =$_GET['ip'];
	//$mytable =$_GET['table'];
	//$myvalue =$_GET['value'];
	//-------------------------------------------------------------------- 
	//filename:class.php 
	//summary: access�ƾڮw�ާ@�� 
	//   �ϥνd�ҡG 
	//include_once("odbC.php"); 
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	//if($mytable == '1')
	
	$imgfile = $access->getmachine_one($machine_s,$field,$myIP);
	if($imgfile )
	{
		echo $imgfile;
		//$access->ocr_insert($machine_s,$mytable,$myvalue,$myIP);
	}
	else
		echo "0";
	$access->close();
	
?>