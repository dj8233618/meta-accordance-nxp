<?php
include_once("web_conf.php");
//require_once('syslog.php');
$userid = $_GET['usernmae'];
$userpwd = $_GET['userpwd'];
$userpwr = $_GET['userpwr'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$sql = "update user_m set user_pwd = '$userpwd', user_pwr = $userpwr where user_id = '$userid' ";
	//echo $sql;
	$result = pg_exec($testDb, $sql);
	//echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	pg_close($testDb); 
}

?>