<?php
	$myIP =$_GET['ip'];
	$myPath =$_GET['path'];
	//include_once("odbc.php"); 
		//echo "-----";
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	if($access )
	{
		//echo "-----";
		$access->connect();
		$filename = $access->getinfo_one($table,$field,$myIP,$set);
	    //$filename = FALSE;
		//var_dump($filename);
		//echo $filename;
		//echo $myPath;
		$access->close();
		
		if( $filename )
		{
			if ( $myPath)
			{
			    
				$myFile = $myPath."/".$myIP."/".$filename;
			}
			else
			{
			    
				$myFile = "/".$myIP."/".$filename;
			}
		}
		else
		{
			if ( $myPath)
			{
				$myFile = $myPath."/black.jpg";
			}
			else
			{
				$myFile = "/black.jpg";
			}
		}
 		//echo $myFile;
		$myFile1 = trim($myFile);
 		//echo $myFile1;
 		//echo $myFile1."<br>----";
 	        //echo filesize($filename)."<br>";
 	        //echo filesize($myFile1)."<br>";
 		//echo realpath($myFile1)."<br>";
 		//echo filesize(realpath($myFile1))."<br>";
 		$mm_type="image/jpeg";
		
		//echo filesize($myFile1);
		
 		header("Cache-Control: public, must-revalidate");
 		header("Pragma: hack"); // WTF? oh well, it works...
 		header("Content-Type: ".$mm_type);
 		header("file-name: ".$myFile1);
 		header("Content-Length: ".(filesize($myFile1)) );
 		readfile(realpath($myFile1));
 		
	}
?>