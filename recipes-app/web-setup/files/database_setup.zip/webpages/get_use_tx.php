<?php
	//$myMode =$_GET['mode'];
	//$myIP =$_GET['ip'];
	$myFile =$_GET['kvm_vnc'];
	//-------------------------------------------------------------------- 
	//filename:class.php 
	//summary: access�ƾڮw�ާ@�� 
	//   �ϥνd�ҡG 
	//include_once("odbc.php"); 
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	$imgfile = $access->getinfo_one("rx_table","view_ip",$myFile,"view_ip");
	if(!$imgfile )
	{
		echo "no";
	}
	else
	{
		echo "yes";
	}
	$access->close();
	
?>