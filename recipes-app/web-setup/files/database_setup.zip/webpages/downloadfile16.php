<?php
	$myIP =$_GET['ip'];
	$myPath =$_GET['path'];
	$mychannel =$_GET['channel'];
	//include_once("odbc.php"); 
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	if($access)
	{
		$access->connect();
		$filename = $access->getinfo_one_m($table_m,$field,$myIP,$set,$mychannel);
		$access->close();
		//echo $filename;
		if( $filename )
		{
			if ( $myPath)
			{
				$myFile = $myPath."/".$myIP."/".$filename;
			}
			else
			{
				$myFile = "/".$myIP."/".$filename;
			}
		}
		else
		{
			if ( $myPath)
			{
				$myFile = $myPath."/black.jpg";
			}
			else
			{
				$myFile = "/black.jpg";
			}
		}
		$myFile1 = trim($myFile);
		//echo $myFile1."<br>----";
		//echo filesize($myFile1)."<br>";
		//echo realpath($myFile1)."<br>";
		//echo filesize(realpath($myFile1))."<br>";
		$mm_type="image/jpeg";
		
		header("Cache-Control: public, must-revalidate");
		header("Pragma: hack"); // WTF? oh well, it works...
		header("Content-Type: ".$mm_type);
		header("file-name: ".$myFile1);
		header("Content-Length: ".(filesize($myFile1)) );
		readfile(realpath($myFile1));
	}
?>