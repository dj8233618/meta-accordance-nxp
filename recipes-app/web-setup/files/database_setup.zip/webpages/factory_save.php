<html>
<head>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<?php 
    $factory_list = $_POST['factory_list'];
    $factory_list_html = htmlentities(trim($factory_list), ENT_QUOTES,"utf-8");
    $factory_list_html = nl2br($factory_list);
    $arr = explode("/n", $factory_list)
?>
</head>
	<body> 
<?php 
    $file_path = "db_list.txt";
    if(file_exists($file_path))
    {
        $file = fopen($file_path,"w");
        fwrite($file, $factory_list);
        fclose($file);
    }
    echo ("<script>document.location.href=\"factory_edit.php\";</script>");
?>
	
	</body>
</html>