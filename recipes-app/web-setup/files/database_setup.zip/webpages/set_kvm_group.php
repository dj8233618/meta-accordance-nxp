<?php
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    
    $kvm_gp = $_POST["kvm_gp"];
    $kvm = $_POST["kvm"];
    $length =sizeof($kvm);
    /*
    $sql_web = "select web_ip from web_set";
    $result_web = pg_exec($testDb, $sql_web);
    $info_web=pg_fetch_array($result_web);
    $web_ip = trim($info_web[0]);
    */
    echo "connect ok1";
    echo $kvm_gp;
    echo $kvm;
    
    for($i=0;$i<$length;$i++)
    {   
        $numrows1++;
        $temp = $kvm[$i];
        echo "$temp";
        echo "<br>";
        $sql_port = "select kvm_port from kvm_table where kvm_ip='$temp'";
        $result_port = pg_exec($testDb, $sql_port);
        $info=pg_fetch_array($result_port);
        $kvm_port=trim($info[0]);
			  $sql = "update kvm_table set kvm_mc_group='$kvm_gp' where kvm_ip='$temp' and kvm_port='$kvm_port' ";
        echo $sql;
        $result = pg_exec($testDb, $sql);
    }
    echo "connect success";
    
    echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
    pg_close($testDb);
}

?>