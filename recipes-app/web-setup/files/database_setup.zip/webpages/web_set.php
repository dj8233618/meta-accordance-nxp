<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from web_set ");
	//$numrows = pg_num_rows($result);
	$numrows = pg_num_rows($result);
	if( $numrows )
	{
		$info=pg_fetch_array($result,0);
		$web_ip = trim($info[1]);
		$web_port = trim($info[2]);
		$web_path = trim($info[3]);
		$web_16w = trim($info[4]);
		$web_16h = trim($info[5]);
		$web_w = trim($info[6]);
		$web_h = trim($info[7]);
	}
	pg_close($testDb); 
	//echo "<frame name=\"main\" src=\"page16_a.php?web_ip=$web_ip&web_port=$web_port&web_path=$web_path&page_w=$web_w&page_h=$web_h\" scrolling=\"auto\" target=\"_self\">"; 
}
?> 
	<form name="input" action="set_web.php" method="post">  
		<table>
			<tr>
				<td>
					<?php echo _('Web IP');?>
				</td>
				<td>
					<input type="text" name="webip" value="<?php echo $web_ip ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('Web Port');?>
				</td>
				<td>
					<input type="text" name="webport" value="<?php echo $web_port ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('Web real path');?>
				</td>
				<td>
					<input type="text" name="webpath" value="<?php echo $web_path ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('16x16 w');?>
				</td>
				<td>
					<input type="text" name="web16w" value="<?php echo $web_16w ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('16x16 h');?>
				</td>
				<td>
					<input type="text" name="web16h" value="<?php echo $web_16h ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('one w');?>
				</td>
				<td>
					<input type="text" name="webw" value="<?php echo $web_w ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('one h');?>
				</td>
				<td>
					<input type="text" name="webh" value="<?php echo $web_h ?>">  
				</td>
			</tr>
		</table> 
		<input type="submit" value="<?php echo _('Submit');?>">
	</form>
  </body>
</html>
