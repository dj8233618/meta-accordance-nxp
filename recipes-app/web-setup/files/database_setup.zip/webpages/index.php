<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
</head>
<body>
<form name="form" method="post" action="login.php">

	<table align="center">
		<tr>
			<td align="center">
				<big><big><big>RCVM Web System</big></big></big>
			</td>
		</tr>
			<td align="center">
				<big><?php echo _('Remote Connect System');?></big>
			</td>
		</tr>
		<tr>
			<td>
				<table>
					<tr>
						<td>
							<?php echo _('Account:');?>
						</td>
						<td>
							<input type="text" name="id" />
						</td>
					</tr>
					<tr>
						<td>
							<?php echo _('Password:');?>
						</td>
						<td>
							<input type="password" name="pw" />
						</td>
					</tr>
				</table>
			</td>
		<tr>
			<td align="center">
				<input type="submit" name="button" value=<?php echo _('Login');?> />
			</td>
		</tr>
		<tr>
			<table align="center">
			<td>
				<a href="setlang.php?lang=zh_TW"><?php echo _('Traditional Chinese'); ?></a>
			</td>
			<td>
				&nbsp;&nbsp;&nbsp;
			</td>
			<td>
				<a href="setlang.php?lang=zh_CN"><?php echo _('Simplified Chinese'); ?></a>
			</td>
			<td>
				&nbsp;&nbsp;&nbsp;
			</td>
			<td>
				<a href="setlang.php?lang=en_US"><?php echo _('English'); ?></a>
			</td>
			</table>
		</tr>
	</table>
</form>
</body>
</html>
