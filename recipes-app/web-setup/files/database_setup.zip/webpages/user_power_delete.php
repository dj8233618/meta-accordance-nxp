<?php
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    
    $userid = $_POST["user"];
    $result = pg_exec($testDb, "select * from user_index order by user_id asc ");
    $numrows = pg_num_rows($result);
    echo "<table>";
    for($i=0;$i<$numrows;$i++)
    {
        $info=pg_fetch_array($result);
        $user_id = trim($info[0]);
        $kvm_ip = trim($info[6]);
        
        
        echo "<tr><td>$user_id </td><td> $kvm_ip </td><td>";
        
          if( strcmp( $user_id, "admin") )
          {
              echo "<a href=\"set_user_machine_delete.php?A=$user_id&B=$kvm_ip\" > delete</a>";
          }
        echo"<br>";
        echo "</td></tr>";
        
    }
    echo "</table>";
    pg_close($testDb);
}

?>