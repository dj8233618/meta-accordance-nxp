<?php
include_once("web_conf.php");
//require_once('syslog.php');
$kvm_ip = $_GET['delid'];
$kvm_port = $_GET['delide'];
$kvm_gp = $_GET['kvm_gp'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$sql = "select * from kvm_table where kvm_mc_group='$kvm_gp'";
	$result = pg_exec($testDb,$sql );
	$numrows = pg_num_rows($result);
	
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$kvm_ip = trim($info[1]);
		$kvm_port = trim($info[2]);
		
		$sql3 = "delete from kvm_svm_table where kvm_ip='$kvm_ip' ";
		$result = pg_exec($testDb, $sql3);
		
		$sql4 = "delete from tx_table where kvm_ip='".$kvm_ip."p".$kvm_port."' ";
		//echo $sql;
		$result = pg_exec($testDb, $sql4);
	}	
	$sql = "delete from kvm_table where kvm_mc_group='$kvm_gp'";
	$result = pg_exec($testDb, $sql);
	
	$sql2 = "delete from user_index where kvm_gp='$kvm_gp'";
	$result = pg_exec($testDb, $sql2);
	
	echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	pg_close($testDb); 
}

?>