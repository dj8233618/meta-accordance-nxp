<?php
include_once("web_conf.php");
//require_once('syslog.php');
$user = $_POST['id'];
$password = $_POST['pw'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error<br>";
	if (($user == "admin") && ($password == "1qaz2wsx"))
	{
		echo '<meta http-equiv=REFRESH CONTENT=1;url=main_db.php>';
	}
	else
	{
		echo "id or password error";
	}
}
else
{
	$result = pg_exec($testDb, "select * from user_m where user_id = '$user' and user_pwd = '$password' ");
	$numrows = pg_num_rows($result);
	session_start();
	$_SESSION['user_id'] = $user;
	if( $numrows )
	{
		echo "SUCCESS!!";
		$info=pg_fetch_array($result);
		$file = trim($info[4]);
		//echo $file ;
		switch($file)
		{
			case 1: //view
				{
					echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
				}
				break;
			case 2: //op
				{
					echo '<meta http-equiv=REFRESH CONTENT=1;url=main2.php>';
				}
				break;
			case 3: // 3: change recipe
				{
					echo '<meta http-equiv=REFRESH CONTENT=1;url=main4.php>';
				}
				break;
			case 98: //User manage
				{
					echo '<meta http-equiv=REFRESH CONTENT=1;url=main5.php>';
				}
				break;
			case 99: //admin
				{
					echo '<meta http-equiv=REFRESH CONTENT=1;url=main3.php>';
				}
				break;
		}
		//if( $file == 1 ) //view
		//{ 
		//	echo '<meta http-equiv=REFRESH CONTENT=1;url=main.php>';
		//}
		//else
		//{
		//	if( $file == 99 )  //admin
		//	{ 
		//		echo '<meta http-equiv=REFRESH CONTENT=1;url=main3.php>';
		//	}
		//	else
		//	{
		//		if( $file == 2 ) // op
		//		{ 
		//			echo '<meta http-equiv=REFRESH CONTENT=1;url=main2.php>';
		//		}
		//		else  // 3: change recipe
		//		{
		//			echo '<meta http-equiv=REFRESH CONTENT=1;url=main4.php>';
		//		}
		//	}
		//}
	}
	else
	{
		echo "Fail!!";
		echo '<meta http-equiv=REFRESH CONTENT=1;url=index.php>';
	}
	pg_close($testDb); 
}
#$user="stanley";
#$password="1qaz2wsx";
//$domain = "test.com.tw";
//$ldap_server = "192.168.1.200";

//$ds=ldap_connect($ldap_server)or die("�L�k�s���� $domain");
//$dn=$user."@".$domain;
//@$ldapbind=ldap_bind($ds,$dn,$password);
//	if($ldapbind)
//	{
//  		echo "SUCCESS!!";
      //$syslog = new Syslog();
      //$syslog->SetFacility(23);
      //$syslog->SetSeverity(7);
      //$syslog->SetHostname('WEB');
      //$log_mess = "login success!!! user : ".$user;
      //$syslog->SetMsg($log_mess);
      //#$syslog->SetMsg("login Success!!!");
      //$syslog->SetServer('192.168.1.200');
      //$syslog->Send();
//  		echo '<meta http-equiv=REFRESH CONTENT=1;url=main.asp>';
//	}else
//	{
//  		echo "Fail!!";
      //$syslog = new Syslog();
      //$syslog->SetFacility(23);
      //$syslog->SetSeverity(7);
      //$syslog->SetHostname('WEB');
      //$log_mess = "login Fail!!! user : ".$user;
      //$syslog->SetMsg($log_mess);
      //#$syslog->SetMsg("login Fail!!!");
      //$syslog->SetServer('192.168.1.200');
      //$syslog->Send();
  		//echo '<meta http-equiv=REFRESH CONTENT=1;url=index.php>';
	//}

?>