<?php
include_once("web_conf.php");
//require_once('syslog.php');
$machineid = $_POST['machineid'];
$kvm_ip = $_POST['kvm_ip'];
$recipe = $_POST['recipe'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$today = Date("Y/m/d H:i:s");
	
	//$sql="insert into datatable (machineid,ip,recipename,programid,values1,order1,inserttime) values ('test2','10.0.3.108','".$recipe."','1','".$recipe."',1,'".$today."')"; 
	$sql="insert into datatable (machineid,ip,recipename,programid,values1,order1,inserttime) values ('".$machineid."','".$kvm_ip."','".$recipe."','1','".$recipe."',1,'".$today."')"; 
	$result = pg_exec($testDb, $sql);
	
	//$sql1="insert into datatable (machineid,ip,recipename,programid,values1,order1,inserttime) values ('test2','10.0.3.108','".$recipe."','1','none',2,'".$today."')"; 
	$sql1="insert into datatable (machineid,ip,recipename,programid,values1,order1,inserttime) values ('".$machineid."','".$kvm_ip."','".$recipe."','1','none',2,'".$today."')"; 
	//echo $sql1;
	$result = pg_exec($testDb, $sql1);
	pg_close($testDb); 
}

?>