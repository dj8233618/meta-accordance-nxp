<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$delid = $_GET['delid'];
$delide = $_GET['delide'];
		$kvm_ip = "";
		$kvm_port = "5900";
		$kem_local ="";
		$kvm_id = "admin";
		$kvm_pwd = "000000";
		$tx_ip = "";
		$kvm_model = "";
		$kvm_gp ="only";
		$mc_fab = "ACC";
		$mc_dept = "";
		$mc_sect = "";
		$mc_gp = "";
		$mc_vender = "";
		$mc_sm = "";

		$mc_model = "";
		$mc_name = "";
		$svm = "";
		$svm_path = "";
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$sql = "select * from kvm_table  where kvm_ip='".$delid."' and kvm_port=' ".$delide."' ";
	//echo $sql;
	$result = pg_exec($testDb,$sql );
	if ($result) 
	{
		$numrows = pg_num_rows($result);
		for ($i = 0; $i < $numrows; $i++) 
		{
			$info=pg_fetch_array($result);
			$kvm_ip = trim($info[1]);
			$kvm_port = trim($info[2]);

			$kvm_id = trim($info[0]);
			$kvm_pwd = trim($info[3]);
			$tx_ip = trim($info[13]);
			$kvm_model = trim($info[4]);
			$kvm_gp = trim($info[21]);
			
			$mc_fab = trim($info[16]);
			$mc_dept = trim($info[17]);
			$mc_sect = trim($info[18]);
			$mc_gp = trim($info[19]);
			$mc_vender = trim($info[20]);
			$mc_sm = trim($info[15]);
			
			$kvm_local = trim($info[6]);
			$mc_model = trim($info[22]);
			$mc_name = trim($info[5]);
			$svm = trim($info[8]);
			$svm_path = trim($info[9]);
		}
	}
	pg_close($testDb); 
}
?>
<html>
<head>
<meta charset="utf-8">
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
  <form action="kvm_new.php" method="post">
      <table >
      	<tr>
      		<td> <?php echo _('Fab');?> </td>
      		<td> <input type="text" name=mc_fab value="<?php echo $mc_fab ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('Dept');?> </td>
      		<td> <input type="text" name=mc_dept value="<?php echo $mc_dept ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('Section');?> </td>
      		<td> <input type="text" name=mc_sect value="<?php echo $mc_sect ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('Local');?> </td>
      		<td> <input type="text" name=kvm_local value="<?php echo $kvm_local ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('Process Group');?> </td>
      		<td> <input type="text" name=mc_pg value="<?php echo $mc_gp ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('Vender');?> </td>
      		<td> <input type="text" name=mc_vender value="<?php echo $mc_vender ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('device Model');?> </td>
      		<td> <input type="text" name=mc_model value="<?php echo $mc_model ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('Tool Name');?> </td>
      		<td> <input type="text" name=mc_name value="<?php echo $mc_name ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm model ');?></td>
      		<td>
						<select name="kvm_model">
<?php 
						if($kvm_model == "0")
						{
							echo '<option value="0" selected="selected">SpiderDuo</option>';
						}
						else
						{
							echo '<option value="0">SpiderDuo</option>';
						}
						if($kvm_model == "1")
						{
							echo '<option value="1" selected="selected">Adder</option>';
						}
						else
						{
							echo '<option value="1">Adder</option>';
						}
						if($kvm_model == "2")
						{
							echo '<option value="2" selected="selected">Infinity</option>';
						}
						else
						{
							echo '<option value="2">Infinity</option>';
						}
						if($kvm_model == "3")
						{
							echo '<option value="3" selected="selected">CAT5016IP</option>';
						}
						else
						{
							echo '<option value="3">CAT5016IP</option>';
						}
						if($kvm_model == "4")
						{
							echo '<option value="4" selected="selected">CAT4024IP</option>';
						}
						else
						{
							echo '<option value="4">CAT4024IP</option>';
						}
						if($kvm_model == "5")
						{
							echo '<option value="5" selected="selected">SpiderOther</option>';
						}
						else
						{
							echo '<option value="5">SpiderOther</option>';
						}
						if($kvm_model == "6")
						{
							echo '<option value="6" selected="selected">EXT_APP</option>';
						}
						else
						{
							echo '<option value="6">EXT_APP</option>';
						}
						if($kvm_model == "7")
						{
							echo '<option value="7" selected="selected">IHSE_KVM</option>';
						}
						else
						{
							echo '<option value="7">IHSE_KVM</option>';
						}
						if($kvm_model == "8")
						{
							echo '<option value="8" selected="selected">WEB_CGI</option>';
						}
						else
						{
							echo '<option value="8">WEB_CGI</option>';
						}
						if($kvm_model == "9")
						{
							echo '<option value="9" selected="selected">RTSP_CGI</option>';
						}
						else
						{
							echo '<option value="9">RTSP_CGI</option>';
						}
?>
						<!--
						    <option value="0">SpiderDuo</option>
						    <option value="1">Adder</option>
						    <option value="2">Infinity</option>
						    <option value="3">CAT5016IP</option>
						    <option value="4">CAT4024IP</option>
						    <option value="5">SpiderOther</option>
						    <option value="6">EXT_APP</option>
						    <option value="7">IHSE_KVM</option> 
						    <option value="8">WEB_CGI</option> 
						    <option value="9">RTSP_CGI</option> 
						-->
						</select>
				</td>
      	</tr>
      	<tr>
      	<tr>
      		<td> <?php echo _('kvm_ip');?> </td>
      		<td> <input type="text" name=kvm_ip value="<?php echo $kvm_ip ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_port');?> </td>
      		<td> <input type="text" name=kvm_port value="<?php echo $kvm_port ?>"> </td>
      	</tr>
       	<tr>
      		<td> <?php echo _('kvm_id');?> </td>
      		<td> <input type="text" name=kvm_id value="<?php echo $kvm_id ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm_pwd');?> </td>
      		<td> <input type="text" name=kvm_pwd value="<?php echo $kvm_pwd ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('TX IP : model infinity');?> </td>
      		<td> <input type="text" name=tx_ip value="<?php echo $tx_ip ?>"> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('kvm group SMT');?> </td>
      		<td> <input type="hidden" name=kvm_gp value="<?php echo $kvm_gp ?>"> <?php echo $kvm_gp ?> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('real mouse');?> </td>
      		<td> 
						 		<select id="Single mouse mode" name=kvm_sm>
					 			<?php 
					 				if( $mc_sm == 0)
					 				{ 
							 			echo "<option value=0 selected=selected>0</option>";
							 			echo "<option value=1>1</option>";
							 			echo "<option value=2>2</option>";
							 		}
							 		elseif( $mc_sm == 0)
					 				{ 
							 			echo "<option value=0>0</option>";
							 			echo "<option value=1 selected=selected>1</option>";
							 			echo "<option value=2>2</option>";
							 		}
							 		else
					 				{ 
							 			echo "<option value=0>0</option>";
							 			echo "<option value=1>1</option>";
							 			echo "<option value=2 selected=selected>2</option>";
							 		}
								?> 		
								</select>
      		</td>
      	</tr>
      	<tr>
      		<td> <?php echo _('rcvm_ip');?> </td>
      		<td> 
						 		<select id="rcvm_ip" name=rcvm_ip>
						        	<?php 
						        	include_once("web_conf.php");
						        	$testDb=pg_connect($DBase_INI);
						        	$sql = "select * from rcvm_table order by rcvm_ip asc";
						        	$result = pg_exec($testDb, $sql);
						        	$numrows = pg_num_rows($result);
						        	for($i=0;$i<$numrows;$i++)
						        	{
						        	    $info=pg_fetch_array($result);
						        	    $rcvm_ip = trim($info[1]);
						        	    if($rcvm_ip!=null)
						        	    {
						        	    	 if( $rcvm_ip == $svm)
						        	    	 {
						        	       	 echo "<option value=$rcvm_ip selected=selected>$rcvm_ip</option>";
						        	       }
						        	       else
						        	       {
						        	         echo "<option value=$rcvm_ip>$rcvm_ip</option>";
						        	       }
						        	
						        	    }
						        	}
						          ?>
								</select>
     		</td>
      	</tr>
        <tr>
      		<td> <input type="submit" value="<?php echo _('Submit');?>" > </td>
      	</tr> 	
      </table>
  </form>
  </body>
</html>