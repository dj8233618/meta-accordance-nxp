<?php
	//$myMode =$_GET['mode'];
	$myIP =$_GET['ip'];
	$myFile =$_GET['file'];
	//-------------------------------------------------------------------- 
	//filename:class.php 
	//summary: access�ƾڮw�ާ@�� 
	//   �ϥνd�ҡG 
	//include_once("odbC.php"); 
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	if($access)
	{
		$access->connect();
		$imgfile = $access->getinfo_one($table,$field,$myIP,$set);
		if(!$imgfile )
		{
			//echo "insert";
			$access->insert($table,$field,$myIP);
		}
		else
		{
			//echo "updata";
			$access->updateinfo($table,$field,$myIP,$set,$myFile);
		}
	$access->close();
	}
	
?>