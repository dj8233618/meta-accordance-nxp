<?php
include_once("web_conf.php");
$rcvm_ip = $_GET['A'];
$kvm_ip = $_GET['B'];
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    $rcvm_ip_new = "";
    $sql = "update kvm_table set rcvm_ip ='$rcvm_ip_new' where rcvm_ip='$rcvm_ip' and kvm_ip='$kvm_ip'";
    $result = pg_exec($testDb, $sql);
    
    $sql_power_del = "delete from user_index where rcvm_ip='$rcvm_ip' and kvm_ip='$kvm_ip'";
    $result = pg_exec($testDb, $sql_power_del);
    
    echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
    pg_close($testDb); 
}

?>