<html>
<head>
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<frameset framespacing="1" border="1" cols="*" frameborder="1">
  <frameset rows="200,*">
    <frame name="up" target="down" src="demo_ma1.php" scrolling="no" noresize>
    <frame name="down" src="show_ma1.php" scrolling="auto" target="_self">
  </frameset>
  <noframes>
  <body>
  <p>This webpage uses the frame , but your browser does not support . </p>
  </body>
  </noframes>
</frameset>
</html>
