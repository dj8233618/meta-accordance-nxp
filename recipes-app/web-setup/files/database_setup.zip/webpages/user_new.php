<?php
//$userid = $_GET['delid'];
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<meta charset="utf-8">
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$userid = $_GET['delid'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$user_gp="8D";
	$result = pg_exec($testDb, "select * from user_m where user_id='$userid' ");
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$user_dept = trim($info[6]);
		$user_sect = trim($info[7]);
		$user_name = trim($info[2]);
		$user_gp = trim($info[3]);
		$user_id = trim($info[0]);
		$user_pwd = trim($info[1]);
		$user_pwr = trim($info[4]);
	}
	pg_close($testDb); 
}
?>
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_new_user.php" method="post">  
		<table>
			<tr>
				<td>
					<?php echo _('Fab\'s');?>
				</td>
				<td>
					<input type="text" name="Feds" value="<?php echo $user_gp ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('Dept.');?>
				</td>
				<td>
					<input type="text" name="Dept" value="<?php echo $user_dept ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('Section');?>
				</td>
				<td>
					<input type="text" name="Section" value="<?php echo $user_sect ?>" >  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('User ID');?>
				</td>
				<td>
					<input type="text" name="userid" value="<?php echo $user_id ?>" >  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('Name');?>
				</td>
				<td>
					<input type="text" name="usernmae" value="<?php echo $user_name ?>" >  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('password');?>
				</td>
				<td>
					<input type="text" name="userpwd" value="<?php echo $user_pwd ?>" >  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('User Pwd');?>
				</td>
				<td>
					<input type="radio" name="userpwr" value="1" checked> <?php echo _('view');?> <br>  
					<input type="radio" name="userpwr" value="2" > <?php echo _('op');?> <br>  
					<input type="radio" name="userpwr" value="3" > <?php echo _('RCM Setup');?> <br>  
					<input type="radio" name="userpwr" value="98" > <?php echo _('User manage');?> <br>  
					<input type="radio" name="userpwr" value="99" > <?php echo _('admin');?> <br>  
				</td>
			</tr>
		</table> 
		<input type="submit" value="<?php echo _('Submit');?>">
		
	</form>
  </body>
</html>
