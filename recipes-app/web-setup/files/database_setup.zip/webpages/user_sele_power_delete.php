<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>

  	<?php echo _('Choose User');?> <!-- �п�ܨϥΪ̡G -->
	<form name="input" action="user_power_delete2.php" method="post">  
		<select id="factory" name="user" onchange="">
        	<?php 
  	       echo "<option value=All>All</option>";
        	include_once("web_conf.php");
        	$testDb=pg_connect($DBase_INI);
        	$sql = "select * from user_m order by user_id asc";
        	$result = pg_exec($testDb, $sql);
        	$numrows = pg_num_rows($result);
        	for($i=0;$i<$numrows;$i++)
        	{
        	    $info=pg_fetch_array($result);
        	    $user_id = trim($info[0]);
        	    if($user_id!="admin")
        	    {
        	       echo "<option value=$user_id>$user_id</option>";
        	
        	    }
        	}
            ?>
        </select>
        <?php 
            session_start();
            $_SESSION['FacList'] = $FacList;
            $_SESSION['ConList'] = $ConList;
            $_SESSION['FacChoose'] = $FacChoose;
        ?>
        <input type="submit" value="<?php echo _('OK');?>">
	</form>
  </body>
</html>
