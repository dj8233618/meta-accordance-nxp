<?php
	//$myMode =$_GET['mode'];
	//$myIP =$_GET['ip'];
	$myFile =$_GET['kvm_vnc'];
	$myrx =$_GET['kvm_rx'];
	$user_id =$_GET['user_id'];
	$use_mode =$_GET['use_mode'];
	//-------------------------------------------------------------------- 
	//filename:class.php 
	//summary: access�ƾڮw�ާ@�� 
	//   �ϥνd�ҡG 
	//include_once("odbc.php"); 
	//include_once("pgsql.php"); 
	//$access=new access($databasepath,$dbusername,$dbpassword); 
	//$imgfile = $access->updateinfo("rx_table","rx_ip",$myrx,"view_ip",$myFile);
	//$access->close();
include_once("web_conf.php");
if($myrx <> "127.0.0.1")
{
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$today = Date("Y/m/d H:i:s");
	
	$sql = "INSERT INTO rx_u_log ( rx_ip, changtime, view_ip,use_mode, user_id) VALUES ('".$myrx."','".$today."' ,'".$myFile."', '10', '".$user_id."');";
	//echo $sql;
	$result = pg_exec($testDb, $sql);
	pg_close($testDb); 
}
}
?>