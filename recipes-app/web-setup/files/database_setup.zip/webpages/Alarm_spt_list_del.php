<?php
include_once("web_conf.php");
//require_once('syslog.php');
		$mc_vender = $_GET['mc_vender'];
		$mc_model = $_GET['mc_model'];
		$mc_ver = $_GET['mc_ver'];
		$alarm_id = $_GET['alarm_id'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$sql = "delete from alarm_spt_m where  mc_vender='$mc_vender' and mc_model='$mc_model' and mc_ver='$mc_ver' and alarm_id='$alarm_id' ";
	//echo $sql;
	$result = pg_exec($testDb, $sql);
	echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	pg_close($testDb); 
}

?>