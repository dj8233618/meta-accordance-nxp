<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_kvm_group.php" method="post">
      <table>
      	<tr>
      		<td> <?php echo _('Lot ID');?> </td>
      		<td> <input type="text" name="txt_lotid" value="AT0015" /> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('txt_name_2');?> </td>
      		<td> <input type="text" name="txt_name_1" value="MA_Name" /> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('txt_name_2');?> </td>
      		<td> <input type="text" name="txt_name_2" value="MA_Test" /></td>
      	</tr>
      	<tr>
      		<td> <?php echo _('txt_num');?> </td>
      		<td> <input type="text" name="txt_num" value="2" /></td>
      	</tr>
      	<tr>
      		<td> <?php echo _('txt_recipe');?> </td>
      		<td> <input type="text" name="txt_recipe" value="TCM_TEST"  /> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('txt_x_num');?> </td>
      		<td> <input type="text" name="txt_x_num" value="20" /> </td>
      	</tr>
      	<tr>
      		<td> <?php echo _('txt_y_num');?> </td>
      		<td> <input type="text" name="txt_y_num" value="20" /></td>
      	</tr>
      </table>
  </form>
  </body>
</html>