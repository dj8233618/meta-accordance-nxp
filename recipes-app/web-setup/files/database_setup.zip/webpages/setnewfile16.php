<?php
	//$myMode =$_GET['mode'];
	$myIP =$_GET['ip'];
	$myFile =$_GET['file'];
	$mychannel =$_GET['channel'];
	//-------------------------------------------------------------------- 
	//filename:class.php 
	//summary: access�ƾڮw�ާ@�� 
	//   �ϥνd�ҡG 
	//include_once("odbC.php"); 
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	$imgfile = $access->getinfo_one_m($table_m,$field,$myIP,$set,$mychannel);
	if(!$imgfile )
	{
		echo "insert";
		$access->insert_m($table_m,$field,$myIP,$mychannel);
	}
	else
	{
		echo "updata";
		$access->updateinfo_m($table_m,$field,$myIP,$set,$myFile,$mychannel);
	}
	$access->close();
	
?>