<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_del_kvm.php" method="get">  
		<table cellpadding="1" border="1">
			<tr>
				<td><?php echo _('Svm name');?></td>
				<td><?php echo _('Local');?></td>
				<td><?php echo _('Web IP');?></td>
				<td><?php echo _('Web port');?></td>
				<td><?php echo _('User ID');?></td>
				<td><?php echo _('User password');?></td>
				<td><?php echo _('Web path');?></td>
				<td><?php echo _('BackUp');?></td>
				<td><?php echo _('Active time');?></td>
				<td><?php echo _('Pro time');?></td>
				<td><?php echo _('Edit');?></td>
				<td><?php echo _('Delete');?></td>
			</tr>
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from rcvm_table order by rcvm_ip asc ");
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$rcvm_ip = trim($info[1]);
		$rcvm_port = trim($info[2]);
		$rcvm_name = trim($info[5]);
		$rcvm_local = trim($info[6]);
		$rcvm_path = trim($info[8]);
		$rcvm_id = trim($info[0]);
		$rcvm_pwd = trim($info[3]);
		$rcvm_power = trim($info[4]);
		$rcvm_now = trim($info[7]);
		$rcvm_old = trim($info[9]);
		echo "<tr><td>$rcvm_name</td><td>$rcvm_local</td><td>$rcvm_ip</td><td>$rcvm_port</td><td>$rcvm_id</td><td>$rcvm_pwd</td><td>$rcvm_path</td><td>$rcvm_power</td></td><td>$rcvm_now</td><td>$rcvm_old</td><td>";
		//if( strcmp( $user, "admin") )
		{
			echo "<a href=\"svm_list_add.php?delid=$rcvm_ip&delide=$rcvm_port\" >"?><?php echo _('edit');?><?php echo"</a></td><td>";
			echo "<a href=\"set_del_svm.php?delid=$rcvm_ip&delide=$rcvm_port\" >"?><?php echo _('delete');?><?php echo "</a>";?>
		<?php
		}
		echo "</td></tr>";
	}
	pg_close($testDb); 
	//echo "<frame name=\"main\" src=\"page16_a.php?web_ip=$web_ip&web_port=$web_port&web_path=$web_path&page_w=$web_w&page_h=$web_h\" scrolling=\"auto\" target=\"_self\">"; 
}
?> 
		</table> 
	</form>
  </body>
</html>
