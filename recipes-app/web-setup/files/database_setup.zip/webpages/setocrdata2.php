<?php
	//$myMode =$_GET['mode'];
	$myIP =$_GET['ip'];
	$mytable =$_GET['table'];
	$myvalue =$_GET['value'];
	$mytkey =$_GET['tkey'];
	//-------------------------------------------------------------------- 
	//filename:class.php 
	//summary: access�ƾڮw�ާ@�� 
	//   �ϥνd�ҡG 
	//include_once("odbC.php"); 
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	//if($mytable == '1')
	
	//$imgfile = $access->getinfo_one($ocr_table,$field,$myIP,$set);
	//if(!$imgfile )
	//{
	//	echo "insert";
	//	$access->ocr_insert($ocr_table,$mytable,$myvalue,$myIP);
	//}
	//else
	//{
		//echo $myIP;
		//echo $mytable;
		//echo $myvalue;
		//echo $mytkey;
		echo "updata";
		$access->ocr_updateinfo($ocr_table,$mytable,$myvalue,$myIP,$mytkey);
	//}
	$access->close();
	
?>