<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
      <table>
      	<tr>
      		<td> <?php echo _('Lot ID');?> </td>
      		<td> <input type="text" name="txt_lotid"  value="AT0003"  /> </td>
      	</tr>
      </table>
  </body>
</html>