<html>
<head>
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<?php
 	$today = Date("Y/m/d H:i:s");
  include_once("web_conf.php");
	
	$testDb=pg_connect($DBase_INI); 
	if($testDb == FALSE)
	{
		echo "connect error";
	}
	else
	{
	  
		$result = pg_exec($testDb, "select * from machine_state where kvm_ip = '1'");
		$numrows = pg_num_rows($result);
		if( $numrows )
		{
			$info=pg_fetch_array($result,0);
			$web_ip = trim($info[1]);
			$web_port = trim($info[2]);
			$machineid = trim($info[3]);
			$web_16w = trim($info[4]);
			$web_16h = trim($info[5]);
			$web_w = trim($info[6]);
			$kvm_ip = trim($info[7]);
			$web_h1 = trim($info[8]);
			$message = trim($info[9]);
		}
		pg_close($testDb); 
	}
?>
</head>
  <body>
	<form name="input" action="set_demo1.php" method="post">  
		<table>
			<tr>
				<td>
					<input type="hidden" name="machineid" value="<?php echo $machineid ?>"><?php echo $machineid ?> 
				</td>
				<td>
					<input type="hidden" name="kvm_ip" value="<?php echo $kvm_ip ?>"><?php echo $kvm_ip ?> 
				</td>
			</tr>
			<tr>
				<td>
					 recipe name 
				</td>
				<td>
					<input type="text" name="recipe" value="">  
				</td>
			</tr>
		</table> 
		<input type="submit" value="Submit">
	</form>
  </body>
</html>
