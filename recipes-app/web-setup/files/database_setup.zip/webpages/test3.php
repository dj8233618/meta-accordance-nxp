<?php
//$testDb=odbc_connect("Driver={SQL Server Native Client 10.0};Server=localhost\\SQLEXPRESS;Batabase=OCR;","sa","1qaz2wsx"); 
//if($testDb == FALSE)
//{
//	echo "connect error";
//}
//else
//{
//	echo "connect ok";
//}
	include_once("odbc.php"); 
	//echo "connect ok";
	//include_once("pgsql.php"); 
	$access=new access($dbserver,$dbdebase,$dbusername,$dbpassword); 
	if($access->link == TRUE )
  {
		$result = $access->query($testDb, "select * from Datatable");
		echo "connect ok";
	  $numrows = odbc_num_rows($result);
		//echo "connect ok 1";
	  echo "<p>link = $dbdebase<br>  result = $result<br>  numrows = $numrows</p>";
	}
	else
	{
		echo "connect error";
	}
	$access->close();
?>