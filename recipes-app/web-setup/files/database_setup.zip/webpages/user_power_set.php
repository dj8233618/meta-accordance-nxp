<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_user_machine.php" method="post">  
		<select id="user" name="user">
        	<?php 
        	include_once("web_conf.php");
        	$testDb=pg_connect($DBase_INI);
        	$sql = "select * from user_m order by user_id asc";
        	$result = pg_exec($testDb, $sql);
        	$numrows = pg_num_rows($result);
        	for($i=0;$i<$numrows;$i++)
        	{
        	    $info=pg_fetch_array($result);
        	    $user_id = trim($info[0]);
        	    if($user_id!="admin")
        	    {
        	       echo "<option value=$user_id>$user_id</option>";
        	
        	    }
        	}
            ?>
		</select>
		<br>
		    <?php 
		    include_once("web_conf.php");
		    $testDb=pg_connect($DBase_INI);

				$sql = "select * from kvm_table where kvm_mc_group='only' order by kvm_mc_group asc, kvm_ip asc";
      	//$sql = "select * from kvm_table order by kvm_ip asc";
      	$result = pg_exec($testDb, $sql);
      	$numrows = pg_num_rows($result);
      	for($i=0;$i<$numrows;$i++)
      	{
      	    $info=pg_fetch_array($result);
      	    $kvm_ip = trim($info[1]);
      	    $kvm_port = trim($info[2]);
						$mc_name = trim($info[5]);
      	    echo "<input type=checkbox value=$kvm_ip name=kvm[]>$kvm_ip - $mc_name<br>";
      	}
      	
				$sql = "select * from kvm_table where kvm_mc_group!='only' order by kvm_mc_group asc, kvm_ip asc";
				$result = pg_exec($testDb, $sql);
				$numrows = pg_num_rows($result);
				for($i=0;$i<$numrows;$i++)
				{
					$info=pg_fetch_array($result);
					$kvm_ip = trim($info[1]);
					$kvm_port = trim($info[2]);
					$mc_name = trim($info[5]);
     	    echo "<input type=checkbox value=$kvm_ip name=kvm[]>$kvm_ip - $mc_name<br>";
				}
        ?>
		<br>
		<br>
		<input type="submit" value="<?php echo _('Submit');?>">
	</form>
  </body>
</html>
