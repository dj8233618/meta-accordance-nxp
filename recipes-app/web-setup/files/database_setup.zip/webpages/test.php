<?php
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	//$query = "insert into tx_table (kvm_ip,tx_ip) values ('10.0.2.6','test.jpg')";  
	//echo $query;
	//$result = pg_exec($testDb,$query); 
	//if($result == FALSE)
	//{
	//	echo "connect error";
	//}
	//pg_close($testDb);  
	//echo "connect ok";
	$result = pg_exec($testDb, "select * from tx_table");
  //$numrows = pg_num_rows($result);
  $numrows = pg_num_rows($result);
  echo "<p>connect tx_table ok</p>";
}
	
?>