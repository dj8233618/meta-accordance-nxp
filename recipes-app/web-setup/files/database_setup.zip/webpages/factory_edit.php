<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body> 
  <form name="input" action="factory_save.php" method="post">
    <textarea name="factory_list" rows="40"cols="40">
<?php
        // Connection
        $ConList = array();
        // Factory
        $FacList= array();
        // Factory Choos List
        $FacChoose = array();
        
        // ���J db_txt �ëإ� Connection Pool List
        $file_path = "db_list.txt";
        if(file_exists($file_path))
        {
            $file_arr = file($file_path);
            for($i=0;$i<count($file_arr);$i++) //�v��Ū���ɮפ��e
            {
                $seperate = explode(";", $file_arr[$i]);
                array_push($FacList,$seperate[0]);
                array_push($ConList,$seperate[1]);
                array_push($FacChoose,$i+1);
                echo($file_arr[$i]);
            }
        }
?>
</textarea>
  <input type="submit" value="<?php echo _('SAVE');?>">
  </form>
  </body>
</html>