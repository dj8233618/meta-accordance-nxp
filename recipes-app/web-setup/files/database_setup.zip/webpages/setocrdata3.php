<?php
include_once("web_conf.php");
//require_once('syslog.php');
	$myIP =$_GET['ip'];
	$mytable =$_GET['table'];
	$myvalue =$_GET['value'];
	$mytkey =$_GET['tkey'];
$testDb=pg_connect($DBase_INI2); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	//$sql = "update user_m set user_pwd = '$userpwd', user_pwr = $userpwr where user_id = '$userid' ";
	$today = Date("Y/m/d H:i:s");
	$sql = "INSERT INTO tx_point_log ( view_ip, changtime, mytable, myvalue , panon_id) VALUES ('".$myIP."','".$today."' ,'".$mytable."','".$myvalue."','".$mytkey."');";
	//echo $sql;
	$result = pg_exec($testDb, $sql);
	//echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	pg_close($testDb); 
}

?>