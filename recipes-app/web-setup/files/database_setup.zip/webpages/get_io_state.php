<?php
	//$myIP =$_GET['ip'];
	//$myPath =$_GET['path'];
	//include_once("odbc.php"); 
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	if($access->link == TRUE )
	{
		$filename = $access->getio_one($table,$field);
		$access->close();
		//echo $filename;
		if( $filename )
		{
			$myFile = "<DBIP>".$filename."</DBIP>";
		}
		else
		{
			$myFile = "<DBIP>NULL</DBIP>";
		}
		echo $myFile;
	}
?>