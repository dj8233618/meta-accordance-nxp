<?php
include_once("web_conf.php");
//require_once('syslog.php');
$userfeds = $_POST['Feds'];
$userdept = $_POST['Dept'];
$usersectin = $_POST['Section'];
$username = $_POST['usernmae'];
$userid = $_POST['userid'];
$userpwd = $_POST['userpwd'];
$userpwr = $_POST['userpwr'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
    $sql = "select * from user_m where user_id='$userid' ";
 		//echo $sql;
 		
		$result1 = pg_exec($testDb, $sql);
    $numrows1 = pg_num_rows($result1);
    
		if( $numrows1 > 0)
		{
			$sql = "update user_m set user_pwd='$userpwd' , user_pwr=$userpwr , user_gp='$userfeds' , user_dept='$userdept' , user_section='$usersectin' , user_name='$username' , user_change=1 where user_id='$userid' ";
			//echo $sql;
			echo "update";
		}
		else
		{
			$sql = "insert into user_m (user_id, user_pwd, user_pwr,user_gp,user_dept,user_section,user_name, user_change) values ('$userid', '$userpwd', $userpwr,'$userfeds','$userdept','$usersectin','$username', 1)";
		}
	//echo $sql;
	$result = pg_exec($testDb, $sql);
	echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	pg_close($testDb); 
}

?>