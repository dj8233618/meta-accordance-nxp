<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
<?php
	$root = $_SERVER [ 'DOCUMENT_ROOT' ];
	//echo "$root ============";
	$fp1 = fopen ( "$root/web_conf.php" , 'r' );
	//$userdata = fread($fp1,filesize("$root/web_conf.php"));
	//echo "====================1";
	while( $lineData=fgets($fp1) )
	{
		//echo "====================2";
		$stra = strstr($lineData,"host=");
		if( strlen($stra) >0 )
		{
			$Arr=explode(" ",$stra);
			foreach ($Arr as $value )
			{
				$Arr1=explode("=",$value);
				foreach ($Arr1 as $value1 )
				{
					if( $value1 == "host")
					{
						$dbip=$Arr1[1];
					}
					if( $value1 == "port")
					{
						$dbport=$Arr1[1];
					}
					if( $value1 == "dbname")
					{
						$dbname=$Arr1[1];
					}
					if( $value1 == "user")
					{
						$dbuser=$Arr1[1];
					}
					if( $value1 == "password")
					{
						$dbpwd=$Arr1[1];
					}
				}
			}
		}
		$stra = strstr($lineData,"img_reflash=");
		if( strlen($stra) >0 )
		{
			$Arr=explode(" ",$stra);
			foreach ($Arr as $value )
			{
				$Arr1=explode("=",$value);
				foreach ($Arr1 as $value1 )
				{
					if( $value1 == "img_reflash")
					{
						$img_rf=$Arr1[1];
					}
				}
			}
		}
		$stra = strstr($lineData,"img_con=");
		if( strlen($stra) >0 )
		{
			$Arr=explode(" ",$stra);
			foreach ($Arr as $value )
			{
				$Arr1=explode("=",$value);
				foreach ($Arr1 as $value1 )
				{
					if( $value1 == "img_con")
					{
						$img_con=$Arr1[1];
					}
				}
			}
		}
	}
	
	/*
	fwrite( $fp1 , '<?php' );
	fwrite( $fp1 , '$DBase_INI = "host='.$dbip.' port='.$bdport.' dbname='.$bdname.' user='.$dbusr.' password='.$dbpwd.'"' );
	fwrite( $fp1 , '?>' );
	*/
	
	fclose( $fp1 );
	//echo "====================3$dbip";
?>
	<form name="input" action="set_db.php" method="post">  
		<table>
			<tr>
				<td>
					<?php echo _('DB host');?>
				</td>
				<td>
					<input type="text" name="dbip" value="<?php echo  $dbip; ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('DB port');?>
				</td>
				<td>
					<input type="text" name="dbport" value="<?php echo $dbport ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('dbname');?>
				</td>
				<td>
					<input type="text" name="dbname" value="<?php echo $dbname ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('user');?>
				</td>
				<td>
					<input type="text" name="dbuser" value="<?php echo $dbuser ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('password');?>
				</td>
				<td>
					<input type="text" name="dbpwd" value="<?php echo $dbpwd ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('image flash');?>
				</td>
				<td>
					<input type="text" name="img_rf" value="<?php echo $img_rf ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('image count');?>
				</td>
				<td>
					<input type="text" name="img_con" value="<?php echo $img_con ?>">  
				</td>
			</tr>
		</table> 
		<input type="submit" value="<?php echo _('Submit');?>">
	</form>
  </body>
</html>
