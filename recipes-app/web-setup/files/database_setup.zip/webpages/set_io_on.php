<?php
	//$myMode =$_GET['mode'];
	$myIP =$_GET['ip'];
	$myFile =$_GET['io'];
	//-------------------------------------------------------------------- 
	//filename:class.php 
	//summary: access�ƾڮw�ާ@�� 
	//   �ϥνd�ҡG 
	//include_once("odbc.php"); 
	include_once("pgsql.php"); 
	$access=new access($databasepath,$dbusername,$dbpassword); 
	$imgfile = $access->getinfo_one($table,$field,$myIP,"kvm_ip");
	//$imgfile = $access->getinfo_one($table,$field,$myIP,$set);
	if(!$imgfile )
	{
		echo "insert";
		$access->insert_io($table,$field,$myIP);
	}
	else
	{
		echo "updata";
		$access->updateinfo_io($table,$field,$myIP,$set_io,$myFile);
	}
	$access->close();
	
?>