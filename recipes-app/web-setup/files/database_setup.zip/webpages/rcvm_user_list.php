<?php
include_once("web_conf.php");
//$user = $_GET['id'];
//$password = $_GET['pw'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from user_m order by user_id asc ");
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$user_id = trim($info[0]);
		$user_pwd = trim($info[1]);
		$user_pwr = trim($info[2]);
		echo "<page><number>$i</number><id>$user_id</id><pwd>$user_pwd</pwd><pwr>$user_pwr</pwr></page>";
	}
	pg_close($testDb); 
}
?>