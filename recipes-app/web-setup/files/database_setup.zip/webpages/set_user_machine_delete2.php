<?php
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    
    $userid = $_POST["userid"];
    $kvm = $_POST["kvm"];
    $length =sizeof($kvm);
    
    for($i=0;$i<$length;$i++)
    {   
    	  $temp = $kvm[$i];
        $sql_port = "select * from user_index where kvm_ip='$temp'";
        $result_port = pg_exec($testDb, $sql_port);
        $info=pg_fetch_array($result_port);
        $kvm_gp = trim($info[10]);
        
				if($kvm_gp == "only" )
				{
	         $sql = "delete from user_index where user_id='$userid' and kvm_ip='$temp'";
            	echo $sql;
	         $result = pg_exec($testDb, $sql);
        }
        else
        {
	         $sql = "delete from user_index where user_id='$userid' and kvm_gp='$kvm_gp'";
            	echo $sql;
	         $result = pg_exec($testDb, $sql);
        }
    }
		$sql = "update user_m set user_change=1 where user_id='$userid' ";
    $result = pg_exec($testDb, $sql);
    echo "connect success";
    echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
    
    pg_close($testDb);
}

?>