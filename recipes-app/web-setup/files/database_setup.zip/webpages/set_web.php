<?php
include_once("web_conf.php");
//require_once('syslog.php');
$webip = $_POST['webip'];
$webport = $_POST['webport'];
$webpath = $_POST['webpath'];
$web16w = $_POST['web16w'];
$web16h = $_POST['web16h'];
$webw = $_POST['webw'];
$webh = $_POST['webh'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$sql = "update web_set set web_ip='$webip', web_port='$webport', web_path='$webpath', web_16w='$web16w', web_16h='$web16h', web_w='$webw', web_h='$webh'  where web_name='accordance'";
	//echo $sql;
	$result = pg_exec($testDb, $sql);
	echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	pg_close($testDb); 
}

   //$root = $_SERVER [ 'DOCUMENT_ROOT' ];
   //echo $root
   //$fp = fopen ( "$root/web_conf1.php" , 'w' );
   //fwrite( $fp , 'test' );
   //fclose( $fp );

?>