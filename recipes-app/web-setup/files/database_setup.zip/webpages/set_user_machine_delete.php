<?php
include_once("web_conf.php");
$user_id = $_GET['A'];
$kvm_ip = $_GET['B'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	
  $sql_port = "select * from user_index where kvm_ip='$kvm_ip'";
  $result_port = pg_exec($testDb, $sql_port);
  $info=pg_fetch_array($result_port);
  $kvm_gp = trim($info[10]);
  
	if($kvm_gp == "only" )
	{
     $sql = "delete from user_index where user_id='$user_id' and kvm_ip='$kvm_ip'";
      	//echo $sql;
     $result = pg_exec($testDb, $sql);
  }
  else
  {
     $sql = "delete from user_index where user_id='$user_id' and kvm_gp='$kvm_gp'";
      	//echo $sql;
     $result = pg_exec($testDb, $sql);
  }

	
	//$sql = "delete from user_index where user_id='$user_id' and kvm_ip='$kvm_ip'";
// 	echo $sql;
	//$result = pg_exec($testDb, $sql);
	
	$sql = "update user_m set user_change=1 where user_id='$userid' ";
  $result = pg_exec($testDb, $sql);
	
	echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
	pg_close($testDb); 
}

?>