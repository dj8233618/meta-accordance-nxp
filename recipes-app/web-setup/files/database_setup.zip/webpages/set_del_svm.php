<?php
include_once("web_conf.php");
//require_once('syslog.php');
$rcvm_ip = $_GET['delid'];
$rcvm_port = $_GET['delide'];
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    $sql = "delete from rcvm_table where rcvm_ip='$rcvm_ip' and rcvm_port='$rcvm_port'";
    $result = pg_exec($testDb, $sql);
    
    echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
    pg_close($testDb);
}

?>