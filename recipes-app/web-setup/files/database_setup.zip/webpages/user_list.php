<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_del_user.php" method="get">  
		<table cellpadding="1" border="1">
			<tr>
				<td><?php echo _('Fab\'s');?></td>
				<td><?php echo _('Dept.');?></td> 
				<td><?php echo _('Section');?></td>
				<td><?php echo _('User ID');?></td>
				<td><?php echo _('Name');?></td>
				<td><?php echo _('password');?></td>
				<td><?php echo _('Operator');?></td>
				<td><?php echo _('edit');?></td>
				<td><?php echo _('delete');?></td>
			</tr>
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from user_m order by user_id asc ");
	//$numrows = pg_num_rows($result);
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$user_dept = trim($info[6]);
		$user_sect = trim($info[7]);
		$user_name = trim($info[2]);
		$user_gp = trim($info[3]);
		$user_id = trim($info[0]);
		$user_pwd = trim($info[1]);
		$user_pwr = trim($info[4]);
		if($user_pwr==1)
		    $user_pwr_name="view";
		if($user_pwr==2)
		    $user_pwr_name="op";
		if($user_pwr==3)
		    $user_pwr_name="change recipe";
		if($user_pwr==98)
		    $user_pwr_name="User manage";
		if($user_pwr==99)
		    $user_pwr_name="admin";
		echo "<tr><td>$user_gp</td><td>$user_dept</td><td>$user_sect</td><td>$user_id</td><td>$user_name</td><td>$user_pwd</td><td>$user_pwr_name</td><td>";
		if( strcmp( $user_id, "admin") )
		{
			echo "<a href=\"user_new.php?delid=$user_id\" >"?><?php echo _('edit');?><?php echo"</a></td><td>";
			echo "<a href=\"set_del_user.php?delid=$user_id\" >"?><?php echo _('delete');?><?php echo "</a>";?>
		<?php 
		}
		echo "</td></tr>";
	}
	pg_close($testDb); 
	//echo "<frame name=\"main\" src=\"page16_a.php?web_ip=$web_ip&web_port=$web_port&web_path=$web_path&page_w=$web_w&page_h=$web_h\" scrolling=\"auto\" target=\"_self\">"; 
}
?> 
		</table> 
	</form>
  </body>
</html>
