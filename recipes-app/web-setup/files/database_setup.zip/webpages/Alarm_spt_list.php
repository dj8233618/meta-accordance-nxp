<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<title>Marketing system of the products</title>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="set_del_user.php" method="get">  
		<table cellpadding="1" border="1">
			<tr>
				<td><?php echo _('mc vender');?></td>
				<td><?php echo _('mc model');?></td> 
				<td><?php echo _('mc ver');?></td>
				<td><?php echo _('alarm ID');?></td>
				<td><?php echo _('alarm name');?></td>
				<td><?php echo _('spt_file');?></td>
				<td><?php echo _('Other');?></td>
				<td><?php echo _('other1');?></td>
				<td><?php echo _('edit');?></td>
				<td><?php echo _('delete');?></td>
			</tr>
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$result = pg_exec($testDb, "select * from alarm_spt_m order by mc_vender  asc, mc_model asc, mc_ver asc, alarm_id asc ");
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$mc_vender = trim($info[0]);
		$mc_model = trim($info[1]);
		$mc_ver = trim($info[2]);
		$alarm_id = trim($info[3]);
		$alarm_name = trim($info[4]);
		$spt_file = trim($info[5]);
		$spt_sece_ini  = trim($info[6]);
		$temp_file = trim($info[7]);

		echo "<tr><td>$mc_vender</td><td>$mc_model</td><td>$mc_ver</td><td>$alarm_id</td><td>$alarm_name</td><td>$spt_file</td><td>$spt_sece_ini</td><td>$temp_file</td><td>";
		if( strcmp( $user_id, "admin") )
		{
			echo "<a href=\"Alarm_spt_list_add.php?mc_vender=$mc_vender&mc_model=$mc_model&mc_ver=$mc_ver&alarm_id=$alarm_id\" >"?><?php echo _('edit');?><?php echo"</a></td><td>";
			echo "<a href=\"Alarm_spt_list_del.php?mc_vender=$mc_vender&mc_model=$mc_model&mc_ver=$mc_ver&alarm_id=$alarm_id\" >"?><?php echo _('delete');?><?php echo "</a>";?>
		<?php 
		}
		echo "</td></tr>";
	}
	pg_close($testDb); 
	//echo "<frame name=\"main\" src=\"page16_a.php?web_ip=$web_ip&web_port=$web_port&web_path=$web_path&page_w=$web_w&page_h=$web_h\" scrolling=\"auto\" target=\"_self\">"; 
}
?> 
		</table> 
	</form>
  </body>
</html>
