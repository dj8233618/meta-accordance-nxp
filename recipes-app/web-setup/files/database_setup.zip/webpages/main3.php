<html>
<head>
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<frameset framespacing="0" border="0" rows="*" frameborder="0">
  <frameset cols="150,*">
    <frame name="contents" target="main" src="left3.php" scrolling="no" noresize>
    <frame name="main" src="Black.php" scrolling="auto" target="_self">
  </frameset>
  <noframes>
  <body>
  <p>This webpage uses the frame , but your browser does not support . </p>
  </body>
  </noframes>
</frameset>
</html>
