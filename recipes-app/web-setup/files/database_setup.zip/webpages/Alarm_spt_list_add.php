<?php
include_once("languages/languages.php"); //�ޤJ�y���]�w���
?>
<html>
<head>
<meta charset="utf-8">
<?php
include_once("web_conf.php");
//require_once('syslog.php');
//$user = $_POST['id'];
//$password = $_POST['pw'];
		$mc_vender = $_GET['mc_vender'];
		$mc_model = $_GET['mc_model'];
		$mc_ver = $_GET['mc_ver'];
		$alarm_id = $_GET['alarm_id'];
$testDb=pg_connect($DBase_INI); 
if($testDb == FALSE)
{
	echo "connect error";
}
else
{
	$user_gp="8D";
	$result = pg_exec($testDb, "select * from alarm_spt_m where mc_vender='$mc_vender' and mc_model='$mc_model' and mc_ver='$mc_ver' and alarm_id='$alarm_id' ");
	$numrows = pg_num_rows($result);
	for ($i = 0; $i < $numrows; $i++) 
	{
		$info=pg_fetch_array($result);
		$mc_vender = trim($info[0]);
		$mc_model = trim($info[1]);
		$mc_ver = trim($info[2]);
		$alarm_id = trim($info[3]);
		$alarm_name = trim($info[4]);
		$spt_file = trim($info[5]);
		$spt_sece_ini  = trim($info[6]);
		$temp_file = trim($info[7]);
	}
	pg_close($testDb); 
}
?>
<title>Marketing system of the products</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
  <body>
	<form name="input" action="Alarm_spt_list_set.php" method="post">  
		<table>
			<tr>
				<td>
					<?php echo _('mc vender');?>
				</td>
				<td>
					<input type="text" name="mc_vender" value="<?php echo $mc_vender ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('mc model');?>
				</td>
				<td>
					<input type="text" name="mc_model" value="<?php echo $mc_model ?>">  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('mc ver');?>
				</td>
				<td>
					<input type="text" name="mc_ver" value="<?php echo $mc_ver ?>" >  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('alarm id');?>
				</td>
				<td>
					<input type="text" name="alarm_id" value="<?php echo $alarm_id ?>" >  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('alarm name');?>
				</td>
				<td>
					<input type="text" name="alarm_name" value="<?php echo $alarm_name ?>" >  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('spt file');?>
				</td>
				<td>
					<input type="text" name="spt_file" value="<?php echo $spt_file ?>" >  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('spt sece ini');?>
				</td>
				<td>
					<input type="text" name="spt_sece_ini" value="<?php echo $spt_sece_ini ?>" >  
				</td>
			</tr>
			<tr>
				<td>
					<?php echo _('temp file');?>
				</td>
				<td>
					<input type="text" name="temp_file" value="<?php echo $temp_file ?>" >  
				</td>
			</tr>
		</table> 
		<input type="submit" value="<?php echo _('Submit');?>">
		
	</form>
  </body>
</html>
