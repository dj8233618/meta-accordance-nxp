<?php 
include_once("languages/languages.php"); //�ޤJ�y���]�w���
session_start();
//$FacList = $_SESSION['FacList'];
$ConList = $_SESSION['ConList'];
$FacChoose = $_SESSION['FacChoose'];

$factory = $_POST['factory'];
$user = $_POST['user'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
?> 
<html>
<head>
<meta charset="utf-8">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">

</head>
  <body> 
	<form name="input" action="log_search1_MSMQ.php" method="post">
		<select id="factory" name="factory" onchange="">
            <option value ='<?=$factory?>'><?=$factory?> </option>
        </select>
        <br>
        <select id="user" name="user" onchange="">
            <option value='<?=$user?>' ><?=$user?></option>
        </select>
        <br>
        
        <label for="start"><?php echo _('Start:');?></label>
		<input type="date" id="start_date" name="start_date" value=<?=$start_date ?>>
		<label for="end"><?php echo _('End:');?></label>
		<input type="date" id="end_date" name="end_date" value=<?=$end_date ?>>
		<br>
		<br>
		<?php echo _('Please choose Alarm ID');?>
		<br>
		<select id="userIP" name="userIP" onchange="">
			<option value ="All"> All </option>
            <?php 
                $count = 0;
                $record = array();
                while($count<count($ConList))
                {
                    $count++;
                    if ($count!= $FacChoose[0] && $FacChoose[0] > 0)
                        continue;
                    $j = $count-1;
                    $DBase_INI = "host= $ConList[$j] port=5432 dbname=svm user=accordance password=1qaz2wsx";
                    $sql = "select * FROM alarm_spt_m  order by alarm_id";
                    //if($user != "All")
                    //    $sql = "select * FROM alarm_spt_m  where alarm_id = '$user'";
                        
                    //echo '$sql';    
                    $testDb=pg_connect($DBase_INI);
                    $resultCustomized=pg_exec($testDb,$sql);
                    $arrCustomized = pg_fetch_all($resultCustomized);
                    $length= sizeof($arrCustomized);
                
                    $userIP = array();
                    for($i=0 ; $i<$length ; $i++)
                    {
                        $userIP[$arrCustomized[$i]["alarm_id"]]= $arrCustomized[$i]["alarm_id"];
                    }
                
                    $userIPKey = array_keys($userIP);
                    sort($userIP);
                    $userIPSize = sizeof($userIPKey);
                    for($j=0 ; $j<$userIPSize ; $j++)
                    {                        
                        if(!in_array($userIPKey[$j], $record))
                        {
                            array_push($record,$userIPKey[$j]);
                            echo "<option value ='$userIPKey[$j]'>$userIPKey[$j]</option>";
                        }
                    }
                }
            ?>
        </select>
        <br>
        <input type="submit" value="<?php echo _('OK');?>">
	</form>
  </body>
</html>
