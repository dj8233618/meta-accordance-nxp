<?php
include_once("web_conf.php");
$testDb=pg_connect($DBase_INI);
if($testDb == FALSE)
{
    echo "connect error";
}
else
{
    
    $userid = $_POST["user"];
    $kvm = $_POST["kvm"];
    $length =sizeof($kvm);
    /*
    $sql_web = "select web_ip from web_set";
    $result_web = pg_exec($testDb, $sql_web);
    $info_web=pg_fetch_array($result_web);
    $web_ip = trim($info_web[0]);
    */
    $sql = "select * from user_index where user_id='$userid'";
    $result = pg_exec($testDb, $sql);
    $numrows1 = pg_num_rows($result);
    //echo $sql;
    echo "--";
    echo $length;
    echo "--<br>";
    for($i=0;$i<$length;$i++)
    {   
        $numrows1++;
        $temp = $kvm[$i];
        //echo "$temp";
        //echo "<br>";
        $sql_port = "select * from kvm_table where kvm_ip='$temp'";
        $result_port = pg_exec($testDb, $sql_port);
        $info=pg_fetch_array($result_port);
        //$kvm_name=trim($info[0]);
        
				$kvm_ip = trim($info[1]);
				$kvm_port = trim($info[2]);
		
				//$kvm_id = trim($info[0]);
				//$kvm_pwd = trim($info[3]);
				//$tx_ip = trim($info[13]);
				//$kvm_model = trim($info[4]);
				
				//$mc_fab = trim($info[16]);
				//$mc_dept = trim($info[17]);
				//$mc_sect = trim($info[18]);
				//$mc_gp = trim($info[19]);
				//$mc_vender = trim($info[20]);
				//$kvm_sm = trim($info[15]);
				$kvm_gp = trim($info[21]);
		
				//$mc_model = trim($info[6]);
				$kvm_name = trim($info[5]);
				//$svm = trim($info[8]);
				//$svm_path = trim($info[9]);
        
				if($kvm_gp == "only" )
				{
        	$sql = "insert into user_index (user_id,kvm_id,kvm_ip,kvm_port,kvm_power,kvm_gp,kvm_show) select '$userid','$kvm_name','$kvm_ip','$kvm_port','$numrows1','$kvm_gp','1' where not exists (select * from user_index where user_id='$userid' and kvm_id='$kvm_name' and kvm_ip='$kvm_ip')";
        	//echo $sql;
        	$result = pg_exec($testDb, $sql);
        }
        else
        {
        	$sql = "select * from kvm_table where kvm_mc_group='$kvm_gp' order by kvm_ip asc";
        	//echo "<br>";
        	//echo $sql;
        	//echo "<br>";
        	$result_2 = pg_exec($testDb, $sql);
        	$numrows_2 = pg_num_rows($result_2);
        	for($j=0;$j<$numrows_2;$j++)
        	{
      	    $info_2=pg_fetch_array($result_2);
		 				$kvm_ip = trim($info_2[1]);
						$kvm_port = trim($info_2[2]);
						$kvm_gp = trim($info_2[21]);
						$kvm_name = trim($info_2[5]);
							
        		$sql = "insert into user_index (user_id,kvm_id,kvm_ip,kvm_port,kvm_power,kvm_gp,kvm_show) select '$userid','$kvm_name','$kvm_ip','$kvm_port','$numrows1','$kvm_gp','1' where not exists (select * from user_index where user_id='$userid' and kvm_id='$kvm_name' and kvm_ip='$kvm_ip')";
	        	//echo $sql;
        	//echo "<br>";
	        	$result = pg_exec($testDb, $sql);
        	}
        }
    }
		$sql = "update user_m set user_change=1 where user_id='$userid' ";
    $result = pg_exec($testDb, $sql);
    echo "connect success";
    
    echo '<meta http-equiv=REFRESH CONTENT=1;url=Black.php>';
    pg_close($testDb);
}

?>
